#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

# Licensed to Modin Development Team under one or more contributor license agreements.
# See the NOTICE file distributed with this work for additional information regarding
# copyright ownership.  The Modin Development Team licenses this file to you under the
# Apache License, Version 2.0 (the "License"); you may not use this file except in
# compliance with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under
# the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific language
# governing permissions and limitations under the License.

# Code in this file may constitute partial or total reimplementation, or modification of
# existing code originally distributed by the Modin project, under the Apache License,
# Version 2.0.

import warnings
from typing import Optional

import pandas

from snowflake.snowpark.session import Session

__pandas_version__ = "1.5.3"

if pandas.__version__ != __pandas_version__:
    warnings.warn(
        f"The pandas version installed ({pandas.__version__}) does not match the supported pandas version in"
        + f" Modin ({__pandas_version__}). This may cause undesired side effects!",
        stacklevel=2,
    )

with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    from pandas import Float64Index  # noqa: F401
    from pandas import Int64Index  # noqa: F401
    from pandas import UInt64Index  # noqa: F401
    from pandas import datetime  # noqa: F401
    from pandas import describe_option  # noqa: F401
    from pandas import get_option  # noqa: F401
    from pandas import option_context  # noqa: F401
    from pandas import reset_option  # noqa: F401
    from pandas import (  # noqa: F401
        NA,
        ArrowDtype,
        BooleanDtype,
        Categorical,
        CategoricalDtype,
        CategoricalIndex,
        DateOffset,
        DatetimeIndex,
        DatetimeTZDtype,
        ExcelWriter,
        Flags,
        Float32Dtype,
        Float64Dtype,
        Grouper,
        Index,
        IndexSlice,
        Int8Dtype,
        Int16Dtype,
        Int32Dtype,
        Int64Dtype,
        Interval,
        IntervalDtype,
        IntervalIndex,
        MultiIndex,
        NamedAgg,
        NaT,
        Period,
        PeriodDtype,
        PeriodIndex,
        RangeIndex,
        SparseDtype,
        StringDtype,
        Timedelta,
        TimedeltaIndex,
        Timestamp,
        UInt8Dtype,
        UInt16Dtype,
        UInt32Dtype,
        UInt64Dtype,
        api,
        array,
        bdate_range,
        cut,
        date_range,
        eval,
        factorize,
        from_dummies,
        infer_freq,
        interval_range,
        options,
        period_range,
        set_eng_float_format,
        set_option,
        test,
        timedelta_range,
    )

# TODO: SNOW-851745 make sure add all Snowpark Pandas API general functions
from snowflake.snowpark.modin.pandas.frontend.general import (
    concat,
    crosstab,
    get_dummies,
    isna,
    lreshape,
    melt,
    merge,
    merge_asof,
    merge_ordered,
    pivot,
    pivot_table,
    qcut,
    to_datetime,
    to_numeric,
    to_timedelta,
    unique,
    value_counts,
    wide_to_long,
)
from snowflake.snowpark.modin.pandas.frontend.io import (
    ExcelFile,
    HDFStore,
    json_normalize,
    read_clipboard,
    read_csv,
    read_excel,
    read_feather,
    read_fwf,
    read_gbq,
    read_hdf,
    read_html,
    read_json,
    read_orc,
    read_parquet,
    read_pickle,
    read_sas,
    read_snowflake,
    read_spss,
    read_sql,
    read_sql_query,
    read_sql_table,
    read_stata,
    read_table,
    read_xml,
    to_pandas,
    to_pickle,
    to_snowflake,
    to_snowpark,
)
from snowflake.snowpark.modin.pandas.frontend.plotting import Plotting as plotting
from snowflake.snowpark.modin.pandas.frontend.snow_dataframe import (
    SnowparkPandasDataFrame as DataFrame,
)
from snowflake.snowpark.modin.pandas.frontend.snow_series import (
    SnowparkPandasSeries as Series,
)

__all__ = [  # noqa: F405
    "DataFrame",
    "Series",
    "read_csv",
    "read_parquet",
    "read_json",
    "read_html",
    "read_clipboard",
    "read_excel",
    "read_hdf",
    "read_feather",
    "read_stata",
    "read_sas",
    "read_pickle",
    "read_snowflake",
    "read_sql",
    "read_gbq",
    "read_table",
    "read_spss",
    "read_orc",
    "json_normalize",
    "concat",
    "eval",
    "cut",
    "factorize",
    "test",
    "qcut",
    "to_datetime",
    "get_dummies",
    "isna",
    "isnull",
    "merge",
    "pivot_table",
    "date_range",
    "Index",
    "MultiIndex",
    "Series",
    "bdate_range",
    "period_range",
    "DatetimeIndex",
    "to_timedelta",
    "set_eng_float_format",
    "options",
    "set_option",
    "CategoricalIndex",
    "Timedelta",
    "Timestamp",
    "NaT",
    "PeriodIndex",
    "Categorical",
    "__version__",
    "melt",
    "crosstab",
    "plotting",
    "Interval",
    "UInt8Dtype",
    "UInt16Dtype",
    "UInt32Dtype",
    "UInt64Dtype",
    "SparseDtype",
    "Int8Dtype",
    "Int16Dtype",
    "Int32Dtype",
    "Int64Dtype",
    "CategoricalDtype",
    "DatetimeTZDtype",
    "IntervalDtype",
    "PeriodDtype",
    "BooleanDtype",
    "StringDtype",
    "NA",
    "RangeIndex",
    "Int64Index",
    "UInt64Index",
    "Float64Index",
    "TimedeltaIndex",
    "IntervalIndex",
    "IndexSlice",
    "Grouper",
    "array",
    "Period",
    "show_versions",
    "DateOffset",
    "timedelta_range",
    "infer_freq",
    "interval_range",
    "ExcelWriter",
    "read_fwf",
    "read_sql_table",
    "read_sql_query",
    "ExcelFile",
    "to_pickle",
    "to_pandas",
    "to_snowpark",
    "to_snowflake",
    "HDFStore",
    "lreshape",
    "wide_to_long",
    "merge_asof",
    "merge_ordered",
    "notnull",
    "notna",
    "pivot",
    "to_numeric",
    "unique",
    "value_counts",
    "datetime",
    "NamedAgg",
    "api",
    "read_xml",
    "ArrowDtype",
    "Flags",
    "Float32Dtype",
    "Float64Dtype",
    "from_dummies",
]

del pandas
# del pandas, Parameter

#: The Snowpark session that Snowpark Pandas DataFrame/Series will use.
#: If it is not set, the session will be retrieved when there is only one active session
#: and an exception will be raised when there are multiple sessions.
session: Optional[Session] = None
