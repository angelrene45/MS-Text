#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
import json
import typing
from typing import Hashable, List, Union

import pandas as native_pd

from snowflake.snowpark._internal.analyzer.analyzer_utils import (
    quote_name_without_upper_casing,
)
from snowflake.snowpark.column import CaseExpr, Column as SnowparkColumn
from snowflake.snowpark.functions import (
    any_value,
    cast,
    coalesce,
    col,
    get,
    is_null,
    object_construct,
    parse_json,
    to_variant,
    when,
)
from snowflake.snowpark.modin.pandas.translation._internal.frame import (
    InternalFrame,
    OrderingColumn,
)
from snowflake.snowpark.modin.pandas.translation._internal.ordered_dataframe import (
    OrderedDataFrame,
)
from snowflake.snowpark.modin.pandas.translation._internal.utils import (
    INDEX_LABEL,
    LEVEL_LABEL,
    ROW_POSITION_COLUMN_LABEL,
    append_columns,
    generate_column_identifier_random_suffix,
    is_all_label_components_none,
    is_json_serializable_pandas_labels,
    pandas_lit,
    parse_object_construct_snowflake_quoted_identifier_and_extract_pandas_label,
    serialize_pandas_labels,
    unquote_name_if_quoted,
)
from snowflake.snowpark.modin.pandas.translation.default2pandas import DataFrameDefault
from snowflake.snowpark.types import ArrayType, MapType, StringType, VariantType

TRANSPOSE_INDEX = "TRANSPOSE_IDX"
# transpose value column used in unpivot
TRANSPOSE_VALUE_COLUMN = "TRANSPOSE_VAL"
TRANSPOSE_VALUE_COLUMN_FOR_SINGLE_ROW = '\'{"0":"NULL","row":0}\''
# transpose name column used in unpivot
TRANSPOSE_NAME_COLUMN = "TRANSPOSE_COL_NAME"
# transpose json parsed object name
TRANSPOSE_OBJ_NAME_COLUMN = "TRANSPOSE_OBJ_NAME"
ROW_KEY = "row"
# the value used to replace the NULL for unpivot columns
UNPIVOT_NULL_REPLACE_VALUE = "NULL_REPLACE"


class UnpivotResultInfo(typing.NamedTuple):
    """
    Structure that stores information about the unpivot result.

    Parameters
    ----------
    ordered_dataframe: OrderedDataFrame
        Resulting ordered dataframe.
    transpose_index_snowflake_identifier: str
        Transpose index column used in unpivot.
    new_transpose_value_quoted_identifier: str
        Transpose value column used in unpivot.
    transpose_name_quoted_snowflake_identifier: str
        Transpose name column used in unpivot.
    transpose_object_name_quoted_snowflake_identifier: str
        Transpose json parsed object column used in unpivot.
    """

    ordered_dataframe: OrderedDataFrame
    transpose_index_snowflake_identifier: str
    new_transpose_value_quoted_identifier: str
    transpose_name_quoted_snowflake_identifier: str
    transpose_object_name_quoted_snowflake_identifier: str


def transpose_empty_df(
    original_frame: InternalFrame,
) -> "SnowflakeQueryCompiler":  # type: ignore[name-defined] # noqa: F821
    from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
        SnowflakeQueryCompiler,
    )

    return SnowflakeQueryCompiler.from_pandas(
        native_pd.DataFrame(
            columns=original_frame.index_columns_index,
            index=original_frame.data_columns_index,
        )
    )


def prepare_and_unpivot_for_transpose(
    original_frame: InternalFrame,
    query_compiler: "SnowflakeQueryCompiler",  # type: ignore[name-defined] # noqa: F821
    is_single_row: bool = False,
) -> Union[UnpivotResultInfo, "SnowflakeQueryCompiler"]:  # type: ignore[name-defined] # noqa: F821
    """
    Performs the first steps required to transpose this QueryCompiler. This includes constructing a temporary index
    with position information, and then applying an unpivot operation.
    When is_single_row is true, the pandas label for the result column will be lost, and set to "None".

    Args:
        is_single_row: True when query_compiler holds a single row.

    Returns:
        SnowflakeQueryCompiler in case of fallback to pandas, or otherwise
        a list consisting of the unpivoted OrderedDataFrame and a group of quoted identifiers that are required for
        the following transpose steps of pivot and cleanup (or just cleanup).
    """
    # Check if the columns are all json serializable, if not, then go through fallback path.  The transpose approach
    # here requires json serializable labels because we use sql parse_json to split out row position and multi-level
    # index values as described below.
    # TODO (SNOW-886400) Multi-level non-json serializable pandas label not handled.
    if not is_json_serializable_pandas_labels(original_frame.data_column_pandas_labels):
        return DataFrameDefault.register(native_pd.DataFrame.transpose)(query_compiler)

    # Ensure there is a row position since preserving order is important for transpose.
    original_frame = original_frame.ensure_row_position_column()
    row_position_snowflake_quoted_identifier = (
        original_frame.row_position_snowflake_quoted_identifier
    )

    # Transpose is implemented with unpivot followed by pivot. However when the input dataframe is empty, there are two issues
    # 1) unpivot on empty table returns empty, which results in missing values in TRANSPOSE_NAME_COLUMN
    # 2) pivot values can not be empty.
    # In order to overcome these, we add a dummy row to ordered_dataframe with row position value -1 to make sure
    # there is always atleast one row in the table, and drop the dummy column associated with row position -1 after pivot.
    ordered_dataframe = original_frame.ordered_dataframe
    if not is_single_row:
        quoted_identifiers = (
            ordered_dataframe.projected_column_snowflake_quoted_identifiers
        )
        new_columns = []
        for identifier in quoted_identifiers:
            if identifier == row_position_snowflake_quoted_identifier:
                new_columns.append((pandas_lit(-1)).as_(identifier))
            else:
                # We use any_value to select any value in the dummy column to make sure its dtypes are
                # the same as the column in the original dataframe. This helps avoid type incompatibility
                # issues in union_all.
                new_columns.append(any_value(identifier).as_(identifier))
        dummy_df = ordered_dataframe.agg(new_columns)
        ordered_dataframe = ordered_dataframe.union_all(dummy_df)

    # The following two steps correspond to STEPS (1) and (2) in the four steps described in
    # SnowflakeQueryCompiler.transpose().

    # STEP 1) Construct a temporary index column that contains the original index with position, so for example if
    # there was a multi-level index ['name', 'score'] with index values ('alice', 9.5), ('bob', 8) this would
    # be serialized into a single column with values {"0":"alice","1":9.5,"row":0}, {"0":"bob","1":8,"row":1} where
    # the key refers to the relative index level and row refers to the row_position.
    index_object_construct_key_values = [
        pandas_lit(ROW_KEY),
        col(row_position_snowflake_quoted_identifier),
    ]
    for i, snowflake_quoted_identifier in enumerate(
        original_frame.index_column_snowflake_quoted_identifiers
    ):
        index_object_construct_key_values.append(pandas_lit(str(i)))
        index_object_construct_key_values.append(col(snowflake_quoted_identifier))

    transpose_index_snowflake_identifier = (
        original_frame.ordered_dataframe.generate_snowflake_quoted_identifiers(
            pandas_labels=[TRANSPOSE_INDEX],
        )[0]
    )

    normalize_transpose_select_list = [
        object_construct(*index_object_construct_key_values)
        .cast(StringType())
        .as_(transpose_index_snowflake_identifier)
    ]

    # For the remaining data columns, we need to also transpose the position since this information later need
    # to be mapped to the row_position to match expected ordering.  We do this by aliasing the column name to
    # include the column position.  For example, columns 'employed', 'kids' would be aliased to json array
    # [1, "employed"] and [2, "kids"] respectively.  Note that the unpivot columns must have same type across
    # all unpivot columns, so we also cast to variant here if not all data types of the data columns are the same.
    #
    # Also notice that SQL unpivot drops off the rows with NULL value after. For example, with following table
    #   EMPID   DEPT    JAN     FEB     MAR     APRIL
    #   1       elect   NULL    200     300     NULL_REPLACE
    # The result after unpivot using SELECT * FROM <table> UNPIVOT(sales FOR month IN (jan, feb, mar)) is
    #   EMPID   DEPT    MONTH       SALES
    #   1       elect   FEB         200
    #   1       elect   MAR         300
    #   1       elect   APRIL       NULL_REPLACE
    # As you can see, Row (1, elect, JAN, NULL) is not in the result. In order to perform transpose to perform
    # correctly, we replace NULLs in the unpivot column with UNPIVOT_NULL_REPLACE_VALUE to make sure the
    # rows with NULLs are retained after unpivot. Then replace the value back with NULLs based on the NULL
    # information in the original column.

    # If the original frame had *all* the same data types, then we can preserve this here otherwise
    # we need to default to variant.
    frame_data_type_map = original_frame.quoted_identifier_to_snowflake_type()
    original_data_types = {
        frame_data_type_map.get(snowflake_quoted_identifier)
        for snowflake_quoted_identifier in original_frame.data_column_snowflake_quoted_identifiers
    }
    output_data_type = (
        original_data_types.pop() if len(original_data_types) == 1 else VariantType()
    )
    # If the computed data type is ARRAY or MAP type, then we must convert it to VARIANT.
    # This is necessary to allow the PIVOT in step 3 to succeed; Snowflake disallows the MIN
    # aggregation over an array/map-type column, and does not support the ANY_VALUE aggregation
    # in a PIVOT statement.
    # Since pandas represents array types with the `object` dtype, which VARIANT is converted
    # to in post-processing, this does not cause any differences in behavior.
    if isinstance(output_data_type, (ArrayType, MapType)):
        output_data_type = VariantType()

    unpivot_columns = []
    for i, (pandas_label, snowflake_quoted_identifier) in enumerate(
        zip(
            original_frame.data_column_pandas_labels,
            original_frame.data_column_snowflake_quoted_identifiers,
        )
    ):
        # Generate a random suffix to avoid conflict if there is already label [i, pandas_label].
        # Since the serialized_name must be a valid json format, we add the suffix as an extra component
        # of the list, instead of de-conflict on top of the serialized_name. The suffix will be
        # automatically discarded during label extraction to get the correct label.
        serialized_name = quote_name_without_upper_casing(
            json.dumps([i, pandas_label, generate_column_identifier_random_suffix()])
        )
        normalize_transpose_select_list.append(
            # Replace NULLs in the column with value UNPIVOT_NULL_REPLACE_VALUE. The column is cast to
            # variant column first, so that we can replace NULLs with a value without considering the column
            # data type.
            coalesce(
                to_variant(snowflake_quoted_identifier),
                to_variant(pandas_lit(UNPIVOT_NULL_REPLACE_VALUE)),
            ).as_(serialized_name)
        )
        unpivot_columns.append(serialized_name)

    ordered_dataframe = ordered_dataframe.select(
        normalize_transpose_select_list
        + original_frame.data_column_snowflake_quoted_identifiers
    )

    # STEP 2) Perform an unpivot which flattens the original data columns into a single name and value rows
    # grouped by the temporary transpose index column.  In the earlier example, this would flatten the non-index
    # data into individual rows grouped by the index (TRANSPOSE_INDEX) which later becomes the transposed
    # column labels.
    (
        transpose_value_quoted_snowflake_identifier,
        transpose_name_quoted_snowflake_identifier,
        transpose_object_name_quoted_snowflake_identifier,
    ) = ordered_dataframe.generate_snowflake_quoted_identifiers(
        pandas_labels=[
            TRANSPOSE_VALUE_COLUMN,
            TRANSPOSE_NAME_COLUMN,
            TRANSPOSE_OBJ_NAME_COLUMN,
        ],
    )
    ordered_dataframe = ordered_dataframe.unpivot(
        transpose_value_quoted_snowflake_identifier,
        transpose_name_quoted_snowflake_identifier,
        unpivot_columns,
    )

    assert (
        len(original_frame.data_column_snowflake_quoted_identifiers) > 0
    ), "no data column to transpose"
    # Replace the null value back by checking if the value in the origin data column is null and also the
    # unpivot name column value is original data column name.
    # For example: with the above sales example, after replace the NULLs, the table become
    #   EMPID   DEPT    JAN             FEB     MAR     APRIL
    #   1       elect   NULL_REPLACE    200     300     NULL_REPLACE
    # after unpivot, we got
    #   EMPID   DEPT    JAN     FEB     MAR     APRIL           MONTH    SALES
    #   1       elect   NULL    200     300     NULL_REPLACE    JAN     NULL_REPLACE
    #   1       elect   NULL    200     300     NULL_REPLACE    FEB     200
    #   1       elect   NULL    200     300     NULL_REPLACE    MAR     300
    #   1       elect   NULL    200     300     NULL_REPLACE    APRIL   NULL_REPLACE
    # then we check condition (SALES == "NULL_REPLACE" and JAN == NULL and MONTH == 'JAN') or
    # (SALES == "NULL_REPLACE" and FEB == NULL and MONTH == 'FEB'),
    # or (SALES == "NULL_REPLACE" and MAR == NULL and MONTH == 'MAR'),
    # or (SALES == "NULL_REPLACE" and APRIL == NULL and MONTH == 'APRIL'),
    # if the condition is True, the corresponding value for SALES is replaced with NULL.
    # After replacement, it becomes
    #   EMPID   DEPT    JAN     FEB     MAR     APRIL           MONTH    SALES
    #   1       elect   NULL    200     300     NULL_REPLACE    JAN     NULL
    #   1       elect   NULL    200     300     NULL_REPLACE    FEB     200
    #   1       elect   NULL    200     300     NULL_REPLACE    MAR     300
    #   1       elect   NULL    200     300     NULL_REPLACE    APRIL   NULL_REPLACE
    case_conditions: List[SnowparkColumn] = []
    for origin_data_column, serialized_name in zip(
        original_frame.data_column_snowflake_quoted_identifiers, unpivot_columns
    ):
        unquoted_serialized_name = unquote_name_if_quoted(serialized_name)
        case_conditions.append(
            (
                col(transpose_value_quoted_snowflake_identifier)
                == pandas_lit(UNPIVOT_NULL_REPLACE_VALUE)
            )
            & is_null(origin_data_column)
            & (
                col(transpose_name_quoted_snowflake_identifier)
                == pandas_lit(unquoted_serialized_name)
            )
        )
    case_expr: CaseExpr = when(case_conditions[0], pandas_lit(None))
    for case_condition in case_conditions[1:]:
        case_expr = case_expr.when(case_condition, pandas_lit(None))

    # add otherwise clause
    case_column = case_expr.otherwise(col(transpose_value_quoted_snowflake_identifier))
    transpose_value_column = (
        TRANSPOSE_VALUE_COLUMN
        if not is_single_row
        # Since step 3 is skipped for single-row dataframes, the value below is chosen such that it
        # simulates the output of step 3 and becomes compatible with step 4.
        else TRANSPOSE_VALUE_COLUMN_FOR_SINGLE_ROW
    )
    new_transpose_value_quoted_identifier = (
        ordered_dataframe.generate_snowflake_quoted_identifiers(
            pandas_labels=[transpose_value_column],
        )[0]
    )
    # cast the column back to the desired data type output_data_type
    case_column = cast(case_column, output_data_type).as_(
        new_transpose_value_quoted_identifier
    )
    select_col_names = [transpose_name_quoted_snowflake_identifier]
    if not is_single_row:
        select_col_names += [transpose_index_snowflake_identifier]
    ordered_dataframe = ordered_dataframe.select(
        *select_col_names,
        case_column,
    )

    # Parse the json object unpivot name column because we will need to extract the row position and, in the case
    # of multi-level index, parse each level into a different index column.
    ordered_dataframe = append_columns(
        ordered_dataframe,
        transpose_object_name_quoted_snowflake_identifier,
        parse_json(transpose_name_quoted_snowflake_identifier),
    )

    return UnpivotResultInfo(
        ordered_dataframe,
        transpose_index_snowflake_identifier,
        new_transpose_value_quoted_identifier,
        transpose_name_quoted_snowflake_identifier,
        transpose_object_name_quoted_snowflake_identifier,
    )


def clean_up_transpose_result_index_and_labels(
    original_frame: InternalFrame,
    ordered_transposed_df: OrderedDataFrame,
    transpose_name_quoted_snowflake_identifier: str,
    transpose_object_name_quoted_snowflake_identifier: str,
) -> InternalFrame:
    """
    Creates an internal frame based on the original frame and the data transposed snowpark dataframe.  This
    cleans up and normalizes the labels and index values so they conform with expectations for pandas transpose.

    Example:
        If the original frame had:
            data column labels ('a', 'x'), ('a', 'y'), ('b', 'w'), ('b', 'z') and index column values (g, h, i)
        and transposed snowpark dataframe had:
            schema ('"TRANSPOSE_OBJ_NAME"',
                '"{""0"":""g"", ""row"":0}"', '"{""0"":""h"", ""row"":1}"', '"{""0"":""i"", ""row"":2}"')
            and values for TRANSPOSE_OBJ_NAME: [0, ["a", "x"]], [1, ["a", "y"]], [2, ["b", "w"]], [3, ["b", "z"]]
        then the dataframe index is split into multi-columns and labels are cleaned up.

        The resulting frame would have (transposed indexes):
            data column labels: (g, h, i) and index column values ('a', 'x'), ('a', 'y'), ('b', 'w'), ('b', 'z')
        and normalized snowpark dataframe:
            schema ('"row_position"', '"level"', '"level_1"', '"g"', '"h"' ,'"i"')
            and values (0, a, x), (1, a, y), (2, b, w), (3, b, z) for values __row_position, level, level_1

    Args:
        original_frame: The original InternalFrame for the transpose
        ordered_transposed_df: The transposed ordered dataframe

    Returns:
        The transposed InternalFrame.
    """
    # The remaining columns are the resulting output columns of the transpose, except for the TRANSPOSE_NAME_COLUMN
    # which becomes the new index of the resulting table.
    data_column_snowflake_quoted_identifiers = (
        ordered_transposed_df.projected_column_snowflake_quoted_identifiers
    )
    data_column_snowflake_quoted_identifiers.remove(
        transpose_name_quoted_snowflake_identifier
    )
    data_column_snowflake_quoted_identifiers.remove(
        transpose_object_name_quoted_snowflake_identifier
    )
    data_column_object_identifier_pairs = [
        (
            parse_object_construct_snowflake_quoted_identifier_and_extract_pandas_label(
                snowflake_quoted_identifier,
                len(original_frame.index_column_pandas_labels),
            ),
            snowflake_quoted_identifier,
        )
        for snowflake_quoted_identifier in data_column_snowflake_quoted_identifiers
    ]

    # Extract the position information that was previously serialized into the column names, then sort and
    # re-organize the column names to maintain the original ordering from the pre-transpose rows.
    data_column_object_identifier_pairs.sort(
        key=lambda obj_ident: obj_ident[0][1]["row"]
    )

    # Drop the identifiers associated with dummy column row:-1 generated from the dummy row in transpose.
    if len(data_column_object_identifier_pairs) > 0:
        if data_column_object_identifier_pairs[0][0][1]["row"] == -1:
            data_column_object_identifier_pairs.remove(
                data_column_object_identifier_pairs[0]
            )

    # If it's a single level, we store the label, otherwise we store tuple for each level.
    new_data_column_pandas_labels = [
        data_column_object_identifier[0]
        for data_column_object_identifier, _ in data_column_object_identifier_pairs
    ]

    new_data_column_snowflake_quoted_identifiers = [
        snowflake_quoted_identifier
        for _, snowflake_quoted_identifier in data_column_object_identifier_pairs
    ]

    # We need to split out the TRANSPOSE_OBJ_NAME_COLUMN with two cases:
    #
    # If it is a single index, the format will be [1, "employed"] and result in new columns with values:
    #       (row_position, 1), ("__level__", "employed")
    #
    # If it is a multi-index, the format will be [1, ["status", "employed"]] and result in new columns with values:
    #       (row_position, 1), ("__level_1__", "status"), ("__level_2__", "employed")
    new_index_column_pandas_labels: List[Hashable] = []
    new_index_column_snowflake_quoted_identifiers: List[str] = []
    for i, pandas_label in enumerate(original_frame.data_column_pandas_index_names):
        if is_all_label_components_none(pandas_label):
            index_label = LEVEL_LABEL
            if i >= 1:
                index_label += f"_{i}"
        else:
            index_label = pandas_label

        snowflake_quoted_identifier = (
            ordered_transposed_df.generate_snowflake_quoted_identifiers(
                pandas_labels=serialize_pandas_labels([index_label]),
                excluded=new_data_column_snowflake_quoted_identifiers
                + new_index_column_snowflake_quoted_identifiers,
            )[0]
        )

        new_index_column_pandas_labels.append(pandas_label)
        new_index_column_snowflake_quoted_identifiers.append(
            snowflake_quoted_identifier
        )

    # Extract the new row position and pandas label object from column
    # transpose_object_name_quoted_snowflake_identifier, which is an array column
    # with value [row_position, label object] like [0, "score"]. The label object
    # for multi-index can look like {"0": "A", "1": "B"} for panda label ("A", "B").

    # Generate the snowflake quoted identifier for extracted row position and pandas
    # label object columns.
    row_position_and_index_snowflake_quoted_identifier = (
        ordered_transposed_df.generate_snowflake_quoted_identifiers(
            pandas_labels=[ROW_POSITION_COLUMN_LABEL, INDEX_LABEL],
            excluded=new_data_column_snowflake_quoted_identifiers
            + new_index_column_snowflake_quoted_identifiers,
        )
    )
    pivot_with_index_select_list = [
        get(transpose_object_name_quoted_snowflake_identifier, i).as_(
            snowflake_quoted_identifier
        )
        for i, snowflake_quoted_identifier in enumerate(
            row_position_and_index_snowflake_quoted_identifier
        )
    ] + new_data_column_snowflake_quoted_identifiers

    ordered_transposed_df = ordered_transposed_df.select(pivot_with_index_select_list)

    row_position_snowflake_quoted_identifier = (
        row_position_and_index_snowflake_quoted_identifier[0]
    )
    index_snowflake_quoted_identifier = (
        row_position_and_index_snowflake_quoted_identifier[1]
    )
    # Handle the multi-index case by further parsing out each level to a separate level_# columns.
    if len(new_index_column_snowflake_quoted_identifiers) > 1:
        pivot_with_multi_index_select_list = (
            [row_position_snowflake_quoted_identifier]
            + [
                get(index_snowflake_quoted_identifier, i).as_(
                    snowflake_quoted_identifier
                )
                for i, snowflake_quoted_identifier in enumerate(
                    new_index_column_snowflake_quoted_identifiers
                )
            ]
            + new_data_column_snowflake_quoted_identifiers
        )

        ordered_transposed_df = ordered_transposed_df.select(
            pivot_with_multi_index_select_list
        )
    else:
        # If it is a single level then no more extraction is needed after separating the row position and index.
        new_index_column_snowflake_quoted_identifiers = [
            index_snowflake_quoted_identifier
        ]

    # Create new internal frame with resulting ordering column and transposed index values.
    ordered_transposed_df = ordered_transposed_df.sort(
        OrderingColumn(row_position_snowflake_quoted_identifier)
    )

    new_internal_frame = InternalFrame.create(
        ordered_dataframe=ordered_transposed_df,
        data_column_pandas_labels=new_data_column_pandas_labels,
        data_column_pandas_index_names=original_frame.index_column_pandas_labels,
        data_column_snowflake_quoted_identifiers=new_data_column_snowflake_quoted_identifiers,
        index_column_pandas_labels=new_index_column_pandas_labels,
        index_column_snowflake_quoted_identifiers=new_index_column_snowflake_quoted_identifiers,
    )

    # Rename the data column snowflake quoted identifiers to be closer to pandas labels, normalizing names
    # will remove information like row position that may have temporarily been included in column names to track
    # during earlier steps.
    new_internal_frame = (
        new_internal_frame.normalize_snowflake_quoted_identifiers_with_pandas_label()
    )

    return new_internal_frame
