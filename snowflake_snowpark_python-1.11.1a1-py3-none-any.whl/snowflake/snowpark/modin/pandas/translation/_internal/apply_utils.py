#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
import json
from typing import Any, Callable, List, Literal, Optional, Tuple

import pandas as native_pd
from pandas.api.types import is_scalar

from snowflake.snowpark._internal.udf_utils import get_types_from_type_hints
from snowflake.snowpark.functions import udf, udtf
from snowflake.snowpark.modin.pandas.translation._internal.utils import (
    TempObjectType,
    get_or_create_snowpark_session,
)
from snowflake.snowpark.modin.pandas.utils.core_utils import MODIN_UNNAMED_SERIES_LABEL
from snowflake.snowpark.types import (
    DataType,
    PandasDataFrameType,
    PandasSeriesType,
    StringType,
    VariantType,
)
from snowflake.snowpark.udf import UserDefinedFunction
from snowflake.snowpark.udtf import UserDefinedTableFunction

APPLY_LABEL_COLUMN_QUOTED_IDENTIFIER = '"LABEL"'
APPLY_VALUE_COLUMN_QUOTED_IDENTIFIER = '"VALUE"'


def check_return_variant_and_get_return_type(func: Callable) -> Tuple[bool, DataType]:
    """Check whether the function returns a variant in Snowflake, and get its return type."""
    return_type, _ = get_types_from_type_hints(func, TempObjectType.FUNCTION)
    if return_type is None or isinstance(
        return_type, (VariantType, PandasSeriesType, PandasDataFrameType)
    ):
        # By default, we assume it is a series-to-series function
        # However, vectorized UDF only allows returning one column
        # We will convert the result series to a list, which will be
        # returned as a Variant
        return_variant = True
    else:
        return_variant = False
    return return_variant, return_type


def create_udtf_for_apply_axis_1(
    func: Callable,
    raw: bool,
    result_type: str,
    args: tuple,
    column_index: native_pd.Index,
    input_types: List[DataType],
    **kwargs: Any,
) -> UserDefinedTableFunction:
    """
    Create the UDTF from the Python function for df.apply with axis=1.
    This UDTF returns two columns, label column and value column
    The label column maintains a json string from a dict, which contains
    a Pandas label in the current series, and its the occurrence. We need to
    record the occurrence to deduplicate the duplicate labels so the later pivot
    operation on the label column can create separate columns on duplicate labels.
    The value column maintains a value in the current series
    """
    # copy the variable/function from snowpark pandas module
    # it avoids creating a dependency of snowpark pandas module on UDF
    series_name = MODIN_UNNAMED_SERIES_LABEL
    handle_missing_value_copy = create_handle_missing_value_in_variant_func()

    class ApplyFunc:
        def end_partition(self, df):  # type: ignore[no-untyped-def] # pragma: no cover
            df.columns = column_index
            df = df.apply(
                func, axis=1, raw=raw, result_type=result_type, args=args, **kwargs
            )
            # When a dataframe is returned from `df.apply`,
            # `func` is a series-to-series function, e.g., `lambda x: x+1`
            # For example, the original dataframe is
            #    a  b  b
            # 0  0  1  2
            #
            # the result dataframe from `df.apply` is
            #    a  b  b
            # 0  1  2  3
            # After the transformation below, we will get a dataframe with two columns:
            #                   "LABEL"  "VALUE"
            # 0  {'count': 0, '0': 'a'}        1
            # 1  {'count': 0, '0': 'b'}        2
            # 2  {'count': 1, '0': 'b'}        3
            # where the value of `counts` indicates the time of occurrence
            # and the value of `0` indicates the result value after df.apply()
            if isinstance(df, native_pd.DataFrame):
                result = []
                for _, series in df.iterrows():

                    for i, (label, value) in enumerate(series.items()):
                        # If this is a tuple then we store each component with a 0-based
                        # lookup.  For example, (a,b,c) is stored as (0:a, 1:b, 2:c).
                        if isinstance(label, tuple):
                            obj_label = {k: v for k, v in enumerate(list(label))}
                        else:
                            obj_label = {0: label}
                        obj_label["names"] = series.index.names
                        obj_label["pos"] = i
                        result.append(
                            [
                                json.dumps(obj_label),
                                value,
                            ]
                        )
                # use object type so the result is json-serializable
                result = native_pd.DataFrame(
                    result, columns=["label", "value"], dtype=object
                )
            # When a series is returned from `df.apply`,
            # `func` is a series-to-scalar function, e.g., `np.sum`
            # For example, the original dataframe is
            #    a  b
            # 0  1  2
            # and the result series from `df.apply` is
            # 0    3
            # dtype: int64
            # After the transformation below, we will get a dataframe with two columns:
            #        "LABEL"                        "VALUE"
            # 0  {'0': MODIN_UNNAMED_SERIES_LABEL}        3
            elif isinstance(df, native_pd.Series):
                result = df.to_frame(name="value")
                result.insert(0, "label", json.dumps({"0": series_name}))
            else:
                raise TypeError(f"Unsupported data type {df} from df.apply")

            result["value"] = (
                result["value"].apply(handle_missing_value_copy).astype(object)
            )
            return result

    packages = list(get_or_create_snowpark_session().get_packages().values())
    func_udtf = udtf(
        ApplyFunc,
        output_schema=PandasDataFrameType(
            [StringType(), VariantType()],
            [
                APPLY_LABEL_COLUMN_QUOTED_IDENTIFIER,
                APPLY_VALUE_COLUMN_QUOTED_IDENTIFIER,
            ],
        ),
        input_types=[PandasDataFrameType(input_types)],
        # We have to use the current pandas version to ensure the behavior consistency
        packages=[native_pd] + packages,
    )

    return func_udtf


def create_udf_for_series_apply(
    func: Callable,
    return_type: DataType,
    input_type: DataType,
    na_action: Optional[Literal["ignore"]],
    args: Tuple[Any, ...],
    **kwargs: Any,
) -> UserDefinedFunction:
    if isinstance(return_type, VariantType):
        # copy the variable/function from snowpark pandas module
        # it avoids creating a dependency of snowpark pandas module on UDF
        handle_missing_value_copy = create_handle_missing_value_in_variant_func()

        def apply_func(x):  # type: ignore[no-untyped-def] # pragma: no cover
            result = []
            # When the return type is Variant, the return value must be json-serializable
            # Calling tolist() convert np.int*, np.bool*, etc. (which is not
            # json-serializable) to python native values
            for e in x.apply(func, args=args, **kwargs).tolist():
                result.append(handle_missing_value_copy(e))
            return result

    else:

        def apply_func(x):  # type: ignore[no-untyped-def] # pragma: no cover
            return x.apply(func, args=args, **kwargs)

    func_udf = udf(
        apply_func,
        return_type=PandasSeriesType(return_type),
        input_types=[PandasSeriesType(input_type)],
        strict=bool(na_action == "ignore"),
    )
    return func_udf


def create_handle_missing_value_in_variant_func() -> Callable:
    """
    Create a local copy of `handle_missing_value_in_variant` below.
    This function is used to avoid creating a dependency of Snowpark Pandas module on UDF.
    """

    def handle_missing_value_in_variant(value: Any) -> Any:
        """
        Returns the correct NULL value in a variant column when a UDF is applied.

        Snowflake supports two types of NULL values, JSON NULL and SQL NULL in variant data.
        In Snowflake Python UDF, a VARIANT JSON NULL is translated to Python None and A SQL NULL is
        translated to a Python object, which has the `is_sql_null` attribute.
        See details in
        https://docs.snowflake.com/en/user-guide/semistructured-considerations#null-values
        https://docs.snowflake.com/en/developer-guide/udf/python/udf-python-designing#null-values

        In Snowpark Pandas apply/applymap API with a variant column, we return JSON NULL if a Python
        None is returned in UDF (follow the same as Python UDF), and return SQL null for all other
        Pandas missing values (np.nan, pd.NA, pd.NaT). Note that pd.NA, pd.NaT are not
        json-serializable, so we need to return a json-serializable value anyway (None or SqlNullWrapper())
        """

        class SqlNullWrapper:
            def __init__(self) -> None:
                self.is_sql_null = True

        if is_scalar(value) and native_pd.isna(value):
            if value is None:
                return None
            else:
                return SqlNullWrapper()
        else:
            return value

    return handle_missing_value_in_variant
