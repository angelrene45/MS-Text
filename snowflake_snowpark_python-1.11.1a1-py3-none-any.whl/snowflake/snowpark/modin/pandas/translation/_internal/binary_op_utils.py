#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
from typing import Optional

from pandas._typing import Callable, Scalar

from snowflake.snowpark.column import Column as SnowparkColumn
from snowflake.snowpark.functions import col, concat, floor, iff, repeat, when
from snowflake.snowpark.modin.pandas.translation._internal.type_utils import (
    infer_object_type,
)
from snowflake.snowpark.modin.pandas.translation._internal.utils import pandas_lit
from snowflake.snowpark.modin.pandas.utils.error_message import ErrorMessage
from snowflake.snowpark.types import (
    DataType,
    NullType,
    StringType,
    _FractionalType,
    _IntegralType,
)

NAN_COLUMN = pandas_lit("nan").cast("float")

# set of supported binary operations that can be mapped to Snowflake
SUPPORTED_BINARY_OPERATIONS = {
    "truediv",
    "rtruediv",
    "floordiv",
    "rfloordiv",
    "mod",
    "rmod",
    "pow",
    "rpow",
    "__or__",
    "__ror__",
    "__and__",
    "__rand__",
    "add",
    "radd",
    "sub",
    "rsub",
    "mul",
    "rmul",
    "eq",
    "ne",
    "gt",
    "lt",
    "ge",
    "le",
}


def compute_modulo_between_snowpark_columns(
    first_operand: SnowparkColumn,
    first_datatype: DataType,
    second_operand: SnowparkColumn,
    second_datatype: DataType,
) -> SnowparkColumn:
    """
    Compute modulo between two Snowpark columns ``first_operand`` and ``second_operand``.
    Supports only numeric values for operands, raises NotImplementedError otherwise.
    Module may produce results different from native Pandas or Python.
    """
    # 0. if f or s is NULL, return NULL (Snowflake's rule)
    # 1. s == 0, return nan
    # 2. if s != 0, return f % s
    #
    #     Examples
    # --------
    # >>> a = pd.Series([7, 7, -7, -7])
    # >>> b = pd.Series([5, -5, 5, -5])
    # >>> a % b
    # 0    2.0
    # 1    2.0
    # 2   -2.0
    # 3   -2.0
    # dtype: float64

    # >>> a = pd.Series([8.9, -0.22, np.nan, -1.02, 3.15, 2.0])
    # >>> b = pd.Series([-2.3, -76.34, 5.3, 5.3, 8.12])
    # >>> a % b
    # 0    2.00
    # 1   -0.22
    # 2     NaN
    # 3   -1.02
    # 4    3.15
    # 5     NaN
    # dtype: float64

    # Behavior differences
    # --------------------
    # Python               Pandas 1.5            Snowflake
    #  7 %  5 =  2          7 %  5 =  2           7 %  5 =  2
    #  7 % -5 = -3          7 % -5 = -3           7 % -5 =  2
    # -7 %  5 =  3         -7 %  5 =  3          -7 %  5 = -2
    # -7 % -5 = -2         -7 % -5 = -2          -7 % -5 = -2
    #
    # NOTE: Some of the mod computations done by native Pandas 1.5 gives results that differ
    # from both Snowpark Pandas API and Python.
    # Snowpark Pandas API differs from native Pandas results whenever an operand with a negative
    # sign is used.

    is_first_operand_numeric_type = (
        isinstance(first_datatype, _IntegralType)
        or isinstance(first_datatype, _FractionalType)
        or isinstance(first_datatype, NullType)
    )

    is_second_operand_numeric_type = (
        isinstance(second_datatype, _IntegralType)
        or isinstance(second_datatype, _FractionalType)
        or isinstance(second_datatype, NullType)
    )

    if is_first_operand_numeric_type and is_second_operand_numeric_type:
        return (
            when(first_operand.is_null() | second_operand.is_null(), None)
            .when(second_operand == 0, NAN_COLUMN)
            .otherwise(first_operand % second_operand)
        )
    else:
        ErrorMessage.not_implemented(
            "Modulo does not support non-numeric types, consider using a UDF with apply instead."
        )


def compute_power_between_snowpark_columns(
    first_operand: SnowparkColumn,
    second_operand: SnowparkColumn,
    is_first_operand_integer_type: bool,
) -> SnowparkColumn:
    """
    Compute power between two Snowpark columns ``first_operand`` and ``second_operand``.
    """
    # 0. if f == 1 or s == 0, return 1 or 1.0 based on f's type (Pandas' behavior)
    # 1. if f or s is NULL, return NULL (Snowflake's behavior)
    # 2. if f is nan, or s is nan, or f < 0 and s can not be cast to int without loss (int(s) != s), return nan
    #    In Snowflake, if f < 0 and s is not an integer, an invalid floating point operation will be raised.
    #    E.g., pow(-7, -10.0) is valid, but pow(-7, -10.1) is invalid in snowflake.
    #    In pandas, pow(-7, -10.1) returns NaN.
    # 3. else return f ** s
    result = (
        when(
            (first_operand == 1) | (second_operand == 0),
            1 if is_first_operand_integer_type else 1.0,
        )
        .when(first_operand.is_null() | second_operand.is_null(), None)
        .when(
            (first_operand == NAN_COLUMN)
            | (second_operand == NAN_COLUMN)
            | (
                (first_operand < 0)
                # it checks whether the value can be cast int without loss
                & (second_operand.cast("int") != second_operand)
            ),
            NAN_COLUMN,
        )
        .otherwise(first_operand**second_operand)
    )
    return result


def is_binary_op_supported(op: str) -> bool:
    """
    check whether binary operation is mappable to Snowflake
    Args
        op: op as string

    Returns:
        True if binary operation can be mapped to Snowflake/Snowpark, else False
    """

    return op in SUPPORTED_BINARY_OPERATIONS


def compute_binary_op_between_snowpark_columns(
    op: str,
    first_operand: SnowparkColumn,
    first_datatype: Callable[[], DataType],
    second_operand: SnowparkColumn,
    second_datatype: Callable[[], DataType],
) -> SnowparkColumn:
    """
    Compute Pandas binary operation for two SnowparkColumns
    Args:
        op: Pandas operation
        first_operand: SnowparkColumn for lhs
        first_datatype: Callable for Snowpark Datatype for lhs, this is lazy so we can avoid pulling the value if
        it is not needed.
        second_operand: SnowparkColumn for rhs
        second_datatype: Callable for Snowpark DateType for rhs, this is lazy so we can avoid pulling the value if
        it is not needed.

    Returns:
        SnowparkColumn expr for translated Pandas operation
    """

    binary_op_result_column = None

    # some operators and the data types have to be handled specially to align with Pandas
    # However, it is difficult to fail early if the arithmetic operator is not compatible
    # with the data type, so we just let the server raise exception (e.g. a string minus a string).
    if op in ["truediv", "rtruediv", "floordiv", "rfloordiv"]:
        # rtruediv means b/a, rfloordiv means b//a in Python
        if op in ["rtruediv", "rfloordiv"]:
            first_operand, second_operand = (
                second_operand,
                first_operand,
            )

        binary_op_result_column = first_operand / second_operand

        if op in ["floordiv", "rfloordiv"]:
            binary_op_result_column = floor(binary_op_result_column)
    elif op in ["mod", "rmod"]:
        if op == "rmod":
            first_operand, second_operand = (
                second_operand,
                first_operand,
            )
        binary_op_result_column = compute_modulo_between_snowpark_columns(
            first_operand, first_datatype(), second_operand, second_datatype()
        )
    elif op in ["pow", "rpow"]:
        is_second_operand_integer_type = isinstance(second_datatype(), _IntegralType)
        if op == "rpow":
            first_operand, second_operand = (
                second_operand,
                first_operand,
            )
            is_first_operand_integer_type = is_second_operand_integer_type
        else:
            is_first_operand_integer_type = isinstance(first_datatype(), _IntegralType)
        binary_op_result_column = compute_power_between_snowpark_columns(
            first_operand,
            second_operand,
            is_first_operand_integer_type,
        )
    elif op in ["__or__", "__ror__"]:
        binary_op_result_column = first_operand | second_operand
    elif op in ["__and__", "__rand__"]:
        binary_op_result_column = first_operand & second_operand
    elif op in ["add", "radd", "mul", "rmul"]:

        # string/string case (only for add/radd)
        if isinstance(second_datatype(), StringType) and isinstance(
            first_datatype(), StringType
        ):
            if "add" == op:
                binary_op_result_column = concat(first_operand, second_operand)
            elif "radd" == op:
                binary_op_result_column = concat(second_operand, first_operand)

        # string/integer case (only for mul/rmul)
        if op in ["mul", "rmul"] and (
            (
                isinstance(second_datatype(), _IntegralType)
                and isinstance(first_datatype(), StringType)
            )
            or (
                isinstance(second_datatype(), StringType)
                and isinstance(first_datatype(), _IntegralType)
            )
        ):
            # Snowflake's repeat doesn't support negative number
            # but Pandas will return an empty string

            # swap first_operand with second_operand because REPEAT(<input>, <n>) expects <input> to be string
            if isinstance(first_datatype(), _IntegralType):
                first_operand, second_operand = second_operand, first_operand

            binary_op_result_column = iff(
                second_operand > pandas_lit(0),
                repeat(first_operand, second_operand),
                pandas_lit(""),
            )

    # If there is no special binary_op_result_column result, it means the operator and
    # the data type of the column don't need special handling. Then we get the overloaded
    # operator from Snowpark Column class, e.g., __add__ to perform binary operations.
    if binary_op_result_column is None:
        binary_op_result_column = getattr(first_operand, f"__{op}__")(second_operand)

    return binary_op_result_column


def compute_binary_op_between_snowpark_column_and_scalar(
    op: str,
    identifier: str,
    datatype: Callable[[], DataType],
    other: Scalar,
    fill_value: Optional[float] = None,
) -> SnowparkColumn:
    """
    Compute the binary operation between two Snowpark columns
    Args:
        op: the name of binary operation
        identifier: The quoted identifier for the Snowpark column
        datatype: Callable for Snowpark data type, this is lazy so we can avoid pulling the value if
        it is not needed.
        other: Scalar value
        fill_value: Optional[float] if None will be ignored, else perform coalesce with float before applying op.

    Returns:
        The result as a Snowpark column
    """
    first_operand = col(identifier)
    second_operand = pandas_lit(other)

    def second_datatype() -> DataType:
        return infer_object_type(other)

    return compute_binary_op_between_snowpark_columns(
        op, first_operand, datatype, second_operand, second_datatype
    )
