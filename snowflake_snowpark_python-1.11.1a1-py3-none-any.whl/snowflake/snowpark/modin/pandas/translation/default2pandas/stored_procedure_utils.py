#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

"""Modular houses default to pandas implementation with snowflake stored procedure"""

import logging
import os
from collections import namedtuple
from enum import Enum
from typing import Any, Callable, Dict, Tuple, Union

import cloudpickle as pickle
import pandas as native_pd

import snowflake.snowpark.modin.pandas as pd
from snowflake.snowpark._internal.analyzer.analyzer_utils import quote_name
from snowflake.snowpark._internal.utils import (
    TempObjectType,
    is_in_stored_procedure,
    random_name_for_temp_object,
)
from snowflake.snowpark.modin.pandas.translation._internal.frame import InternalFrame
from snowflake.snowpark.modin.pandas.translation._internal.ordered_dataframe import (
    DataFrameReference,
    OrderedDataFrame,
)
from snowflake.snowpark.modin.pandas.translation._internal.utils import (
    get_or_create_snowpark_session,
)
from snowflake.snowpark.session import Session

_logger = logging.getLogger(__name__)

# Because Snowpark Pandas API is not public and not part of Snowpark, it has to
# be uploaded to a stage as the dependency of fallback stored procedure
# We don't need it once Snowpark Pandas API is merged to snowpark
# current path of this file:
# `src/snowflake/snowpark/modin/pandas/translation/default2pandas/stored_procedure_utils.py`
# So we need to be back to `snowflake/snowpark`
# We can't go back to `snowflake/` directly, because `snowflake/` directory also contain
# `connector` directory, which can't be used inside stored proc (inside the stored proc, we
# use stored proc connector)
SNOWPARK_PANDAS_IMPORT: Union[str, Tuple[str, str]] = (
    os.path.dirname(
        os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        )
    ),
    "snowflake.snowpark",
)
# currently users can only upload a zip file to use Snowpark Pandas inside the stored proc
# so the current path of this file:
# snowflake.zip/snowflake/snowpark/modin/pandas/translation/default2pandas/stored_procedure_utils.py
# However, `snowflake.zip/snowflake` doesn't exist because Python UDFs use zipimport to import
# the dependency so this file is not unzipped. Therefore, we can use `snowflake.zip` directly
if is_in_stored_procedure():
    SNOWPARK_PANDAS_IMPORT = os.path.dirname(
        os.path.dirname(SNOWPARK_PANDAS_IMPORT[0])
    )  # pragma: no cover

FALLBACK_TAG = "FALLBACK"


class SnowparkPandasObjectType(Enum):
    """
    Enum for supported Snowpark Pandas object types.

    Those are Snowpark Pandas object that can be used as caller, args, keywords for
    the pandas operation. The caller is typically SnowflakeQueryCompiler; the
    Snowpark Pandas object that can occur in args or keywords can be SnowflakeQueryCompiler,
    SnowparkPandasDataFrame, and SnowparkPandasSeries. There is currently no need to support other
    Snowpark Pandas object like DataFrameGroupBy etc.
    """

    QUERY_COMPILER = 1  # SnowflakeQueryCompiler
    DATAFRAME = 2  # SnowparkPandasDataFrame
    SERIES = 3  # SnowparkPandasSeries


# namedtuple for the stored procedure pickle data for Snowpark Pandas object, which is used to
# restore the Snowpark Pandas object within or out of stored procedure
SnowparkPandasObjectPickleData = namedtuple(
    "SnowparkPandasObjectPickleData",
    [
        "object_type",  # type name for the Snowpark Pandas object
        "table_name",  # the temp table created out of the snowpark dataframe for the Snowpark Pandas object
        # internal frame properties
        "data_column_pandas_labels",
        "data_column_pandas_index_names",
        "data_column_snowflake_quoted_identifiers",
        "index_column_pandas_labels",
        "index_column_snowflake_quoted_identifiers",
        "ordering_columns",
        "row_position_snowflake_quoted_identifier",
    ],
)


class StoredProcedureDefault:
    @classmethod
    def _stage_and_extract_pickle_data(
        cls, object_type: SnowparkPandasObjectType, internal_frame: InternalFrame
    ) -> SnowparkPandasObjectPickleData:
        """
        Extract the pickle data for the internal frame and save the underlying Snowpark dataframe into
        a temporary table. The pickle data contains the temporary table name, object type name and
        properties of the internal frame.

        Args:
            object_type: SnowparkPandasObjectType. The object type for the Snowpark Pandas object type.
            internal_frame: InternalFrame. The internal frame representation of the Snowpark Pandas object.

        Returns:
            SnowparkPandasObjectPickleData, the pickle data for the Snowpark Pandas object.
        """
        # save the current snowpark df as a snowflake temporary table
        temp_table_name = random_name_for_temp_object(TempObjectType.TABLE)
        internal_frame.ordered_dataframe.write.save_as_table(
            temp_table_name, table_type="temporary"
        )

        # data structure used to pass data in or out of stored proc
        pickle_data = SnowparkPandasObjectPickleData(
            object_type=object_type.name,
            table_name=temp_table_name,
            data_column_pandas_labels=internal_frame.data_column_pandas_labels,
            data_column_pandas_index_names=internal_frame.data_column_pandas_index_names,
            data_column_snowflake_quoted_identifiers=internal_frame.data_column_snowflake_quoted_identifiers,
            index_column_pandas_labels=internal_frame.index_column_pandas_labels,
            index_column_snowflake_quoted_identifiers=internal_frame.index_column_snowflake_quoted_identifiers,
            ordering_columns=internal_frame.ordering_columns,
            row_position_snowflake_quoted_identifier=internal_frame.row_position_snowflake_quoted_identifier,
        )
        return pickle_data

    @classmethod
    def _recover_snowpark_pandas_object(
        cls, session: Session, pickle_data: SnowparkPandasObjectPickleData
    ) -> Union["SnowparkPandasDataFrame", "SnowparkPandasSeries", "SnowflakeQueryCompiler"]:  # type: ignore[name-defined] # noqa: F821
        """
        Recover the Snowpark Pandas object based on the SnowparkPandasObjectPickleData.

        Returns:
            Recovered Snowpark Pandas object, it can be a SnowparkPandasDataFrame, SnowparkPandasSeries
            or SnowflakeQueryCompiler based on the object type.
        """
        from snowflake.snowpark.modin.pandas.frontend.snow_dataframe import (
            SnowparkPandasDataFrame,
        )
        from snowflake.snowpark.modin.pandas.frontend.snow_series import (
            SnowparkPandasSeries,
        )
        from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
            SnowflakeQueryCompiler,
        )

        # create snowpark dataframe from a snowflake table
        ordered_dataframe = OrderedDataFrame(
            DataFrameReference(session.table(pickle_data.table_name)),
            ordering_columns=pickle_data.ordering_columns,
            row_position_snowflake_quoted_identifier=pickle_data.row_position_snowflake_quoted_identifier,
        )
        # create the internal frame representation based on the snowpark dataframe and pickle data
        internal_frame = InternalFrame.create(
            ordered_dataframe=ordered_dataframe,
            data_column_pandas_labels=pickle_data.data_column_pandas_labels,
            data_column_pandas_index_names=pickle_data.data_column_pandas_index_names,
            data_column_snowflake_quoted_identifiers=pickle_data.data_column_snowflake_quoted_identifiers,
            index_column_pandas_labels=pickle_data.index_column_pandas_labels,
            index_column_snowflake_quoted_identifiers=pickle_data.index_column_snowflake_quoted_identifiers,
        )
        # create a snowflake query compiler
        query_compiler = SnowflakeQueryCompiler(internal_frame)

        # recreate the Snowpark Pandas object based on the object type
        if pickle_data.object_type == SnowparkPandasObjectType.DATAFRAME.name:
            result = SnowparkPandasDataFrame(query_compiler=query_compiler)
        elif pickle_data.object_type == SnowparkPandasObjectType.SERIES.name:
            result = SnowparkPandasSeries(query_compiler=query_compiler)
        else:
            result = query_compiler

        return result

    @classmethod
    def _try_pickle_snowpark_pandas_objects(
        cls,
        obj: Any,
    ) -> Tuple[Any, Dict[str, SnowparkPandasObjectPickleData]]:
        """
        Try to extract Snowpark Pandas pickle data from `obj` and all nested objects, and replace
        the object with the name of the temporary table created for the Snowpark Pandas object.

        If the object is not a Snowpark Pandas object, return the original `obj`.

        Args:
            obj: object for extracting the pickle data.

        Returns:
            the new object converted after pickle data is extracted
            mapping between the temp table name and the corresponding pickle data

        """
        from snowflake.snowpark.modin.pandas.frontend.snow_dataframe import (
            SnowparkPandasDataFrame,
        )
        from snowflake.snowpark.modin.pandas.frontend.snow_series import (
            SnowparkPandasSeries,
        )
        from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
            SnowflakeQueryCompiler,
        )

        if isinstance(obj, SnowflakeQueryCompiler):
            # the frontend typically process the Snowpark Pandas object in arguments to
            # SnowflakeQueryCompiler. For example: df1.add(df2), the df2 will be processed
            # to df2._query_compiler when calling into SnowflakeQueryCompiler
            pickle_data = cls._stage_and_extract_pickle_data(
                SnowparkPandasObjectType.QUERY_COMPILER, obj._modin_frame
            )
            return pickle_data.table_name, {pickle_data.table_name: pickle_data}
        if isinstance(obj, SnowparkPandasDataFrame):
            pickle_data = cls._stage_and_extract_pickle_data(
                SnowparkPandasObjectType.DATAFRAME,
                obj._query_compiler._modin_frame,
            )
            return pickle_data.table_name, {pickle_data.table_name: pickle_data}
        if isinstance(obj, SnowparkPandasSeries):
            pickle_data = cls._stage_and_extract_pickle_data(
                SnowparkPandasObjectType.SERIES, obj._query_compiler._modin_frame
            )
            return pickle_data.table_name, {pickle_data.table_name: pickle_data}
        if isinstance(obj, (list, tuple)):
            obj_list = []
            pickle_data_dict = {}
            for o in obj:  # process each element of the list or tuple
                (new_obj, pickle_datas) = cls._try_pickle_snowpark_pandas_objects(o)
                obj_list.append(new_obj)
                pickle_data_dict.update(pickle_datas)

            return type(obj)(obj_list), pickle_data_dict
        if isinstance(obj, dict):
            key_dict = {}
            pickle_data_dict = {}
            for k, v in obj.items():  # process each entry in the dict
                (new_obj, pickle_datas) = cls._try_pickle_snowpark_pandas_objects(v)
                key_dict[k] = new_obj
                pickle_data_dict.update(pickle_datas)
            return key_dict, pickle_data_dict

        return obj, {}

    @classmethod
    def _try_recover_snowpark_pandas_objects(
        cls,
        session: Session,
        obj: Any,
        pickle_data_dict: Dict[str, SnowparkPandasObjectPickleData],
    ) -> Any:
        """
        Try to recover the Snowpark Pandas object from `obj` and all nested objects based on the
        pickle data mapping. The object is replaced with the recovered Snowpark Pandas object, if
        there is no corresponding pickle data, the original object remains.

        Args:
            session: snowflake session used to connect with snowflake server.
            obj: the obj we want to perform the recover process on.
            pickle_data_dict: mapping between the object name and corresponding pickle data

        returns:
            new object after the recover process
        """
        if isinstance(obj, str):
            # if the object have a corresponding entry in the pickle map, recovers
            # the Snowpark Pandas object, otherwise, return the original object
            if obj in pickle_data_dict:
                return cls._recover_snowpark_pandas_object(
                    session, pickle_data_dict[obj]
                )
            else:
                return obj
        if isinstance(obj, (list, tuple)):
            obj_list = []
            for o in obj:
                new_obj = cls._try_recover_snowpark_pandas_objects(
                    session, o, pickle_data_dict
                )
                obj_list.append(new_obj)

            return type(obj)(obj_list)
        if isinstance(obj, dict):
            key_dict = {}
            for k, v in obj.items():
                new_obj = cls._try_recover_snowpark_pandas_objects(
                    session, v, pickle_data_dict
                )
                key_dict[k] = new_obj
            return key_dict

        return obj

    @classmethod
    def register(
        cls,
        frame: InternalFrame,
        pandas_op: Callable,
        args: Any,
        kwargs: Any,
    ) -> "SnowflakeQueryCompiler":  # type: ignore[name-defined]  # noqa: F821
        """
        Register and run pandas operation using stored procedure. Proper pre-processing and post-processing
        of Snowpark Pandas object is applied on the caller object, input arguments and keyword mapping.

        Returns:
            SnowflakeQueryCompiler that is created out of the operation result. Note that all result of the
            pandas operation will be converted to dataframe format.

        """
        from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
            SnowflakeQueryCompiler,
        )

        def args_kwargs_str(args: Any, kwargs: Any) -> str:
            """
            Convert args and kwargs to a string representation.
            For a Snowpark Pandas DataFrame/Series, we just retrieve its type name and
            avoid calling `str()` (which triggers query execution) directly.
            """

            def arg_str(arg: Any) -> str:
                if isinstance(arg, (list, tuple)):
                    return ",".join([arg_str(e) for e in arg])
                elif isinstance(arg, dict):
                    return ",".join(f"{k}: {arg_str(v)}" for k, v in arg.items())
                elif isinstance(arg, (pd.DataFrame, pd.Series)):
                    return str(type(arg))
                return str(arg)

            return f"args=({arg_str(args)}) and kwargs={{{arg_str(kwargs)}}}"

        _logger.debug(
            f"Default to (native) Pandas fallback using stored_procedure for {pandas_op.__name__} "
            f"with {args_kwargs_str(args, kwargs)}"
        )

        # process caller object, caller object is always going to be snowflake query compiler
        caller_data = cls._stage_and_extract_pickle_data(
            SnowparkPandasObjectType.QUERY_COMPILER, internal_frame=frame
        )

        session = get_or_create_snowpark_session()

        (processed_args, args_pickle_data) = cls._try_pickle_snowpark_pandas_objects(
            args
        )
        (
            processed_kwargs,
            kwargs_pickle_data,
        ) = cls._try_pickle_snowpark_pandas_objects(kwargs)

        # default_to_pandas is a stored procedure that is executed within snowflake, which can not
        # be recognized by code coverage, mark all code of this function with pragma: no cover to
        # skip the code coverage check.
        def default_to_pandas(session: Session) -> bytes:
            # post process caller object
            caller_compiler = cls._recover_snowpark_pandas_object(
                session, caller_data
            )  # pragma: no cover
            # create pandas df from the compiler
            native_df = caller_compiler.to_pandas()  # pragma: no cover

            post_args = cls._try_recover_snowpark_pandas_objects(  # pragma: no cover
                session, processed_args, args_pickle_data
            )
            post_kwargs = cls._try_recover_snowpark_pandas_objects(  # pragma: no cover
                session, processed_kwargs, kwargs_pickle_data
            )

            # perform unsupported pandas.DataFrame operation
            df = pandas_op(native_df, *post_args, **post_kwargs)  # pragma: no cover

            # create a snowflake from a pandas df
            sf_compiler = SnowflakeQueryCompiler.from_pandas(df)  # pragma: no cover
            result_pickle_data = cls._stage_and_extract_pickle_data(  # pragma: no cover
                SnowparkPandasObjectType.QUERY_COMPILER, sf_compiler._modin_frame
            )

            return pickle.dumps(result_pickle_data)  # pragma: no cover

        sp_name = (
            f"{random_name_for_temp_object(TempObjectType.PROCEDURE)}{FALLBACK_TAG}"
        )

        if "snowflake-snowpark-python" not in session.get_packages():
            # need snowflake-snowpark-python to install required dependencies
            # e.g., pandas, stored procedure connector
            # we only need to add package once to skip the validation on the client side
            session.add_packages("snowflake-snowpark-python")

        packages = list(session.get_packages().values())
        if "pandas" not in packages:
            packages = [native_pd] + packages
        # register stored procedure
        default_to_pandas_sp = session.sproc.register(
            default_to_pandas,
            name=sp_name,
            imports=[SNOWPARK_PANDAS_IMPORT],
            source_code_display=False,
            # Use the current pandas version to ensure the behavior consistency
            packages=packages,
            # TODO: SNOW-940730 Use anonymous stored procedure to avoid procedure creation
            #  once the server side bug is fixed
        )

        # call stored proc
        encoded_pickle_data = default_to_pandas_sp()
        pickle_data = pickle.loads(encoded_pickle_data)

        # clean up temp tables and stored proc
        table_to_drop = (
            [caller_data.table_name]
            + list(args_pickle_data.keys())
            + list(kwargs_pickle_data.keys())
        )
        for table_name in table_to_drop:
            session._run_query(f"drop table if exists {quote_name(table_name)}")
        session._run_query(f"drop procedure if exists {sp_name}()")

        return cls._recover_snowpark_pandas_object(session, pickle_data)
