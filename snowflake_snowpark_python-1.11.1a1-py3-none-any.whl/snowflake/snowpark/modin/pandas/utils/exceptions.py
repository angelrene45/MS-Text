#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

"""This package contains all Snowpark Pandas exceptions."""
from enum import Enum

from snowflake.snowpark.exceptions import SnowparkClientException


class SnowparkPandasErrorCode(Enum):
    # Snowpark Pandas specific error starts with error code 3XXX
    GENERAL_SQL_EXCEPTION = 3000


# TODO (SNOW-840704): Wrap snowpark SQL exception with more details
#   Snowpark Pandas specific error starts with error code 3XXX
class SnowparkPandasException(SnowparkClientException):
    """
    Base Snowpark Pandas exception class.
    """

    pass
