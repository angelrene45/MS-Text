#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

from logging import getLogger
from typing import Set

logger = getLogger(__name__)

SET_DATAFRAME_ATTRIBUTE_WARNING = (
    "Snowpark Pandas API doesn't allow columns to be created via a new attribute name - see "
    + "https://pandas.pydata.org/pandas-docs/stable/indexing.html#attribute-access"
)


TUPLES_STORED_AS_ARRAY_DEFAULT_MESSAGE = (
    "Snowflake backend doesn't support tuples datatype. Tuple row labels are stored as"
    " ARRAY"
)


# TODO SNOW-828589: throw default to pandas warning here
class WarningMessage:
    printed_warnings: Set[int] = set()  # Set of hashes of printed warnings

    @classmethod
    def single_warning(cls, message: str) -> None:
        """Warning will only be printed out at the first time."""
        message_hash = hash(message)
        if message_hash in cls.printed_warnings:
            logger.debug(f"Single Warning: {message} was raised and suppressed.")
            return

        logger.debug(f"Single Warning: {message} was raised.")
        logger.warning(message, stacklevel=2)
        cls.printed_warnings.add(message_hash)

    @classmethod
    def ignored_argument(cls, operation: str, argument: str, message: str) -> None:
        cls.single_warning(
            f"The argument `{argument}` of `{operation}` has been ignored by Snowpark Pandas API:\n{message}."
        )

    # TODO SNOW-859965: Clean up ErrorMessage.mismatch_with_pandas in groupby.py
    @classmethod
    def mismatch_with_pandas(cls, operation: str, message: str) -> None:
        cls.single_warning(
            f"`{operation}` implementation has mismatches with pandas:\n{message}."
        )

    @classmethod
    def tuples_stored_as_array(
        cls, message: str = TUPLES_STORED_AS_ARRAY_DEFAULT_MESSAGE
    ) -> None:
        cls.single_warning(message)
