#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
from __future__ import annotations

from typing import Any, Iterable, Literal

import pandas as native_pd
from pandas._typing import IndexLabel

from snowflake.snowpark.dataframe import DataFrame as SnowparkDataFrame
from snowflake.snowpark.modin import pandas as pd  # noqa: F401
from snowflake.snowpark.modin.pandas.frontend.dataframe import DataFrame
from snowflake.snowpark.modin.pandas.frontend.snow_series import (  # noqa: F401
    SnowparkPandasSeries as Series,
)
from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
    SnowflakeQueryCompiler,
)
from snowflake.snowpark.modin.pandas.utils.core_utils import _inherit_docstrings
from snowflake.snowpark.modin.pandas.utils.error_message import ErrorMessage


@_inherit_docstrings(
    native_pd.DataFrame,
    # TODO SNOW-863577: remove those APIs from excluded list once we fully support them (without fallback)
    excluded=[
        native_pd.DataFrame.__init__,
        native_pd.DataFrame.applymap,
        native_pd.DataFrame.cov,
        native_pd.DataFrame.flags,
        native_pd.DataFrame.groupby,
        native_pd.DataFrame.memory_usage,
        native_pd.DataFrame.quantile,
        native_pd.DataFrame.reindex,
        native_pd.DataFrame.sum,
        native_pd.DataFrame.to_orc,
        native_pd.DataFrame.to_parquet,
        native_pd.DataFrame.to_stata,
        native_pd.DataFrame.to_xml,
    ],
    apilink="pandas.DataFrame",
)
class SnowparkPandasDataFrame(DataFrame):
    """
    Snowpark Pandas representation of ``pandas.DataFrame`` with a lazily-evaluated relational dataset.

    A DataFrame is considered lazy because it encapsulates the computation or query required to produce
    the final dataset. The computation is not performed until the datasets need to be displayed, or i/o
    methods like to_pandas, to_snowflake are called.

    Internally, the underlying data are stored as Snowflake table with rows and columns.

    Examples::
        Creating a Snowpark Pandas DataFrame from a dictionary::

            >>> d = {'col1': [1, 2], 'col2': [3, 4]}
            >>> df = pd.DataFrame(data=d)
            >>> df
               col1  col2
            0     1     3
            1     2     4

        Constructing DataFrame from numpy ndarray:

        >>> df2 = pd.DataFrame(np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]]),
        ...                    columns=['a', 'b', 'c'])
        >>> df2
           a  b  c
        0  1  2  3
        1  4  5  6
        2  7  8  9

        Constructing DataFrame from a numpy ndarray that has labeled columns:

        >>> data = np.array([(1, 2, 3), (4, 5, 6), (7, 8, 9)],
        ...                 dtype=[("a", "i4"), ("b", "i4"), ("c", "i4")])
        >>> df3 = pd.DataFrame(data, columns=['c', 'a'])
        ...
        >>> df3
           c  a
        0  3  1
        1  6  4
        2  9  7

        Constructing DataFrame from Series/DataFrame:

        >>> ser = pd.Series([1, 2, 3], index=["a", "b", "c"], name = "s")
        >>> df = pd.DataFrame(data=ser, index=["a", "c"])
        >>> df
           s
        a  1
        c  3
        >>> df1 = pd.DataFrame([1, 2, 3], index=["a", "b", "c"], columns=["x"])
        >>> df2 = pd.DataFrame(data=df1, index=["a", "c"])
        >>> df2
           x
        a  1
        c  3
    """

    # Settings this is a requirement across various Modin functions, if not set
    # modin crashes. However, it seems to be a legacy attribute.
    _cache = None

    # Snowflake specific methods
    # another way to integrate with Snowflake could be to use something similar
    # to @pd.api.extensions.register_series_accessor which is a native Pandas way to add new APIs to DataFrame/Series
    # objects via extensions (https://pandas.pydata.org/docs/reference/extensions.html), yet this is not supported
    # by Modin atm. We use instead subclassing, as we want to make clear that a Snowpark Pandas DataFrame is NOT a
    # pandas DataFrame.
    # Implementation note: Arguments names and types are kept consistent with pandas.DataFrame.to_sql
    def to_snowflake(
        self,
        name: str | Iterable[str],
        if_exists: Literal["fail", "replace", "append"] | None = "fail",
        index: bool = True,
        index_label: IndexLabel | None = None,
        table_type: Literal["", "temp", "temporary", "transient"] = "",
    ) -> None:
        """
        Save the Snowpark Pandas DataFrame as a Snowflake table.

        Args:
            name:
                Name of the SQL table or fully-qualified object identifier
            if_exists:
                How to behave if table already exists. default 'fail'
                - fail: Raise ValueError.
                - replace: Drop the table before inserting new values.
                - append: Insert new values to the existing table. The order of insertion is not guaranteed.
            index: default True
                If true, save DataFrame index columns as table columns.
            index_label:
                Column label for index column(s). If None is given (default) and index is True,
                then the index names are used. A sequence should be given if the DataFrame uses MultiIndex.
            table_type:
                The table type of table to be created. The supported values are: ``temp``, ``temporary``,
                and ``transient``. An empty string means to create a permanent table. Learn more about table
                types `here <https://docs.snowflake.com/en/user-guide/tables-temp-transient.html>`_.

        See also:
            - :func:`to_snowflake <snowflake.snowpark.modin.pandas.frontend.io.to_snowflake>`
            - :func:`Series.to_snowflake <snowflake.snowpark.modin.pandas.Series.to_snowflake>`
            - :func:`read_snowflake <snowflake.snowpark.modin.pandas.frontend.io.read_snowflake>`

        """
        self._query_compiler.to_snowflake(
            name, if_exists, index, index_label, table_type
        )

    def to_snowpark(
        self, index: bool = True, index_label: IndexLabel | None = None
    ) -> SnowparkDataFrame:
        """
        Convert the Snowpark Pandas DataFrame to a Snowpark DataFrame.
        Note that once converted to a Snowpark DataFrame, no ordering information will be preserved. You can call
        reset_index to generate a default index column that is the same as the row position before the call to_snowpark.

        Args:
            index: bool, default True.
                Whether to keep the index columns in the result Snowpark DataFrame. If True, the index columns
                will be the first set of columns. Otherwise, no index column will be included in the final Snowpark
                DataFrame.
            index_label: IndexLabel, default None.
                Column label(s) to use for the index column(s). If None is given (default) and index is True,
                then the original index column labels are used. A sequence should be given if the DataFrame uses
                MultiIndex, and the length of the given sequence should be the same as the number of index columns.

        Returns:
            Snowpark :class:`~snowflake.snowpark.dataframe.DataFrame`
                A Snowpark DataFrame contains the index columns if index=True and all data columns of the Snowpark Pandas
                DataFrame. The identifier for the Snowpark DataFrame will be the normalized quoted identifier with
                the same name as the Pandas label.

        Raises:
             ValueError if duplicated labels occur among the index and data columns.
             ValueError if the label used for a index or data column is None.

        See also:
            - :func:`to_snowpark <snowflake.snowpark.modin.pandas.frontend.io.to_snowpark>`
            - :func:`Series.to_snowpark <snowflake.snowpark.modin.pandas.Series.to_snowpark>`

        Note:
            The labels of the Snowpark Pandas DataFrame or index_label provided will be used as Normalized Snowflake
            Identifiers of the Snowpark DataFrame.
            For details about Normalized Snowflake Identifiers, please refer to the Note in :func:`~snowflake.snowpark.modin.pandas.frontend.io.read_snowflake`

        Examples::

            >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
            ...                               'Parrot', 'Parrot'],
            ...                    'Max Speed': [380., 370., 24., 26.]})
            >>> df
               Animal  Max Speed
            0  Falcon      380.0
            1  Falcon      370.0
            2  Parrot       24.0
            3  Parrot       26.0
            >>> snowpark_df = df.to_snowpark(index_label='Order')
            >>> snowpark_df.order_by('"Max Speed"').show()
            ------------------------------------
            |"Order"  |"Animal"  |"Max Speed"  |
            ------------------------------------
            |2        |Parrot    |24.0         |
            |3        |Parrot    |26.0         |
            |1        |Falcon    |370.0        |
            |0        |Falcon    |380.0        |
            ------------------------------------
            <BLANKLINE>
            >>> snowpark_df = df.to_snowpark(index=False)
            >>> snowpark_df.order_by('"Max Speed"').show()
            --------------------------
            |"Animal"  |"Max Speed"  |
            --------------------------
            |Parrot    |24.0         |
            |Parrot    |26.0         |
            |Falcon    |370.0        |
            |Falcon    |380.0        |
            --------------------------
            <BLANKLINE>
            >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
            ...                               'Parrot', 'Parrot'],
            ...                    'Max Speed': [380., 370., 24., 26.]}, index=pd.Index([3, 5, 6, 7], name="id"))
            >>> df      # doctest: +NORMALIZE_WHITESPACE
                Animal  Max Speed
            id
            3  Falcon      380.0
            5  Falcon      370.0
            6  Parrot       24.0
            7  Parrot       26.0
            >>> snowpark_df = df.to_snowpark()
            >>> snowpark_df.order_by('"id"').show()
            ---------------------------------
            |"id"  |"Animal"  |"Max Speed"  |
            ---------------------------------
            |3     |Falcon    |380.0        |
            |5     |Falcon    |370.0        |
            |6     |Parrot    |24.0         |
            |7     |Parrot    |26.0         |
            ---------------------------------
            <BLANKLINE>

            MultiIndex usage

            >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
            ...                               'Parrot', 'Parrot'],
            ...                    'Max Speed': [380., 370., 24., 26.]},
            ...                    index=pd.MultiIndex.from_tuples([('bar', 'one'), ('foo', 'one'), ('bar', 'two'), ('foo', 'three')], names=['first', 'second']))
            >>> df      # doctest: +NORMALIZE_WHITESPACE
                            Animal  Max Speed
            first second
            bar   one     Falcon      380.0
            foo   one     Falcon      370.0
            bar   two     Parrot       24.0
            foo   three   Parrot       26.0
            >>> snowpark_df = df.to_snowpark(index=True, index_label=['A', 'B'])
            >>> snowpark_df.order_by('"A"', '"B"').show()
            ----------------------------------------
            |"A"  |"B"    |"Animal"  |"Max Speed"  |
            ----------------------------------------
            |bar  |one    |Falcon    |380.0        |
            |bar  |two    |Parrot    |24.0         |
            |foo  |one    |Falcon    |370.0        |
            |foo  |three  |Parrot    |26.0         |
            ----------------------------------------
            <BLANKLINE>
            >>> snowpark_df = df.to_snowpark(index=False)
            >>> snowpark_df.order_by('"Max Speed"').show()
            --------------------------
            |"Animal"  |"Max Speed"  |
            --------------------------
            |Parrot    |24.0         |
            |Parrot    |26.0         |
            |Falcon    |370.0        |
            |Falcon    |380.0        |
            --------------------------
            <BLANKLINE>
        """
        return self._query_compiler.to_snowpark(index, index_label)

    def to_pandas(
        self,
        *,
        statement_params: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """
        Convert Snowpark Pandas DataFrame to Pandas DataFrame

        Args:
            statement_params: Dictionary of statement level parameters to be set while executing this action.

        Returns:
            Pandas DataFrame

        See also:
            - :func:`to_pandas <snowflake.snowpark.modin.pandas.frontend.io.to_pandas>`
            - :func:`Series.to_pandas <snowflake.snowpark.modin.pandas.Series.to_pandas>`

        Examples:

            >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
            ...                               'Parrot', 'Parrot'],
            ...                    'Max Speed': [380., 370., 24., 26.]})
            >>> df.to_pandas()
               Animal  Max Speed
            0  Falcon      380.0
            1  Falcon      370.0
            2  Parrot       24.0
            3  Parrot       26.0

            >>> df['Animal'].to_pandas()
            0    Falcon
            1    Falcon
            2    Parrot
            3    Parrot
            Name: Animal, dtype: object
        """
        return self._to_pandas(statement_params=statement_params, **kwargs)

    def memory_usage(self, index: bool = True, deep: bool = False) -> Any:
        """
        Memory Usage (Dummy Information)

        The memory usage of a snowflake dataframe is not fully implemented.
        This method returns a series like the pandas dataframe to maintain
        compatibility with code which calls this for logging purposes, but
        the values are 0.

        Args:
            index: return dummy index memory usage
            deep: ignored

        Returns:
            Series with zeros for each index and column in the dataframe

        Examples:

            >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
            ...                               'Parrot', 'Parrot'],
            ...                    'Max Speed': [380., 370., 24., 26.]})
            >>> df.memory_usage()
            Index        0
            Animal       0
            Max Speed    0
            dtype: int64

            >>> df.memory_usage(index=False)
            Animal       0
            Max Speed    0
            dtype: int64
        """
        columns = (["Index"] if index else []) + self._get_columns().array.tolist()
        return native_pd.Series([0] * len(columns), index=columns)

    def infer_objects(self) -> SnowflakeQueryCompiler:  # noqa: RT01, D200
        """
        Attempt to infer better dtypes for object columns.
        """
        ErrorMessage.not_implemented()  # pragma: no cover
        return self.__constructor__(query_compiler=self._query_compiler.infer_objects())

    def nunique(self, axis: int = 0, dropna: bool = True) -> Series:
        """
        Count number of distinct elements in specified axis.

        Return Series with number of distinct elements. Can ignore NaN
        values. Snowpark Pandas API does not distinguish between NaN values and treats them all as the same.

        Parameters
        ----------
        axis : {0 or 'index', 1 or 'columns'}, default 0
            The axis to use. 0 or 'index' for row-wise, 1 or 'columns' for
            column-wise.
        dropna : bool, default True
            Don't include NaN in the counts.

        Returns
        -------
        Series

        Examples
        --------
        >>> import snowflake.snowpark.modin.pandas as pd
        >>> df = pd.DataFrame({'A': [4, 5, 6], 'B': [4, 1, 1]})
        >>> df.nunique()
        A    3
        B    2
        dtype: int8

        >>> df.nunique(axis=1)
        0    1
        1    2
        2    2
        dtype: int8

        >>> df = pd.DataFrame({'A': [None, pd.NA, None], 'B': [1, 2, 1]})
        >>> df.nunique()
        A    0
        B    2
        dtype: int8

        >>> df.nunique(dropna=False)
        A    1
        B    2
        dtype: int8

        """
        return super().nunique(axis=axis, dropna=dropna)

    def isin(self, values: Any) -> SnowparkDataFrame:
        """not yet implemented, TODO: SNOW-926250"""
        ErrorMessage.not_implemented()
