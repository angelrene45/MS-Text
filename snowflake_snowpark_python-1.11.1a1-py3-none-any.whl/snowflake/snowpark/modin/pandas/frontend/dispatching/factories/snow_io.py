#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

# this module houses classes for IO and interacting with Snowflake engine
from typing import Iterable, List, Optional, Union

import pandas
from pandas._typing import IndexLabel

from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.baseio import BaseIO
from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
    SnowflakeQueryCompiler,
)


class PandasOnSnowflakeIO(BaseIO):
    # use here None, to use default Modin Dataframe class in snowflake.snowpark.modin.pandas.frontend.dataframe.DataFrame
    frame_cls = None
    query_compiler_cls = SnowflakeQueryCompiler

    # implementation note: if no function is present, it will get dispatched to BaseIO layer which in turn dispatches
    # to Pandas functions.

    @classmethod
    def from_pandas(cls, df: pandas.DataFrame):
        """invoke construction from Pandas DataFrame (io backup methods), df is a pandas.DataFrame living in main-memory
        Args:
            df: An existing (native) pandas DataFrame
        """
        return cls.query_compiler_cls.from_pandas(df, pandas.DataFrame)

    @classmethod
    def read_snowflake(
        cls,
        name: Union[str, Iterable[str]],
        index_col: Optional[Union[str, List[str]]] = None,
        columns: Optional[List[str]] = None,
    ):
        """
        See detailed docstring and examples in ``read_snowflake`` in frontend layer:
        src/snowflake/snowpark/modin/pandas/frontend/io.py
        """
        return cls.query_compiler_cls.from_snowflake(name, index_col, columns)

    @classmethod
    def to_snowflake(
        cls,
        name: Union[str, Iterable[str]],
        index: bool = True,
        overwrite: bool = False,
        **kwargs
    ):
        """
        Stores DataFrame into table. Index must be range-index, else storage will be refused.
        Args:
            name: table name where to store table in Snowflake
            index: whether to store index in one (or more columns if Multiindex) column
            overwrite: whether to replace existing table, else fails with exception
            **kwargs: other optional arguments to be passed, ignored for now.
        """
        return cls.query_compiler_cls.to_snowflake(name, index, overwrite)

    @classmethod
    def to_snowpark(cls, index: bool = True, index_label: Optional[IndexLabel] = None):
        """
         Convert the Snowpark Pandas Object(DataFrame or Series) to a Snowpark DataFrame.
         Note that once converted to a Snowpark Dataframe, no ordering information will be preserved. You can call
         reset_index to generate a default index column same as row position before call to_snowpark.

         Args:
             index: bool, default True.
                 Whether to keep the index columns in the result Snowpark DataFrame. If True, the index columns
                 will be the first set of columns. Otherwise, no index column will be included in the final Snowpark
                 DataFrame.
             index_label: IndexLabel, default None.
                 Column label(s) to use for the index column(s). If None is given (default) and index is True,
                 then the original index column labels are used. A sequence should be given if the Snowpark Pandas
                 DataFrame or Series uses MultiIndex, and the length of the given sequence should be the same as
                 the number of index columns.

         Returns:
             :class:`~snowflake.snowpark.dataframe.DataFrame`
                 A Snowpark DataFrame contains the index columns if index=True and all data columns of the Snowpark Pandas
                 DataFrame or Series.

        Note:
             The labels of the Snowpark Pandas DataFrame/Series or index_label provided will be used as Normalized Snowflake
             Identifiers of the Snowpark DataFrame.
             For details about Normalized Snowflake Identifiers, please refer to the Note in :func:`~snowflake.snowpark.modin.pandas.frontend.io.read_snowflake`
        """
        return cls.query_compiler_cls.to_snowpark(
            index, index_label
        )  # pragma: no cover
