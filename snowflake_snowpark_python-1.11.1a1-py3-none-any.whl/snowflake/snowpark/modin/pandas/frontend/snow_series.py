#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
from typing import Any, Dict, Iterable, Literal, Optional, Union

import pandas as native_pd
from pandas._typing import IndexLabel

from snowflake.snowpark.dataframe import DataFrame as SnowparkDataFrame
from snowflake.snowpark.modin import pandas as pd  # noqa: F401
from snowflake.snowpark.modin.pandas._typing import ListLike
from snowflake.snowpark.modin.pandas.frontend.series import Series
from snowflake.snowpark.modin.pandas.utils.core_utils import _inherit_docstrings
from snowflake.snowpark.modin.pandas.utils.error_message import ErrorMessage


@_inherit_docstrings(
    native_pd.Series,
    # TODO SNOW-863577: remove excluded list once all APIs have been completed
    excluded=[
        native_pd.Series.__init__,
        native_pd.Series.flags,
        native_pd.Series.info,
        native_pd.Series.prod,
        native_pd.Series.product,
        native_pd.Series.reindex,
        native_pd.Series.memory_usage,
    ],
    apilink="pandas.Series",
)
class SnowparkPandasSeries(Series):
    """
    Snowpark Pandas representation of `pandas.Series` with a lazily-evaluated relational dataset.

    A Series is considered lazy because it encapsulates the computation or query required to produce
    the final dataset. The computation is not performed until the datasets need to be displayed, or i/o
    methods like to_pandas, to_snowflake are called.

    Internally, the underlying data are stored as Snowflake table with rows and columns.

    Examples
    --------
    Constructing Series from a dictionary with an Index specified

    >>> d = {'a': 1, 'b': 2, 'c': 3}
    >>> ser = pd.Series(data=d, index=['a', 'b', 'c'])
    >>> ser
    a    1
    b    2
    c    3
    dtype: int8

    The keys of the dictionary match with the Index values, hence the Index
    values have no effect.

    >>> d = {'a': 1, 'b': 2, 'c': 3}
    >>> ser = pd.Series(data=d, index=['x', 'y', 'z'])
    >>> ser
    x   NaN
    y   NaN
    z   NaN
    dtype: float64
    """

    _cache = None

    def to_snowflake(
        self,
        name: Union[str, Iterable[str]],
        if_exists: Optional[Literal["fail", "replace", "append"]] = "fail",
        index: bool = True,
        index_label: Optional[IndexLabel] = None,
        table_type: Literal["", "temp", "temporary", "transient"] = "",
    ) -> None:
        """
        Save the Snowpark Pandas Series as a Snowflake table.

        Args:
            name:
                Name of the SQL table or fully-qualified object identifier
            if_exists:
                How to behave if table already exists. default 'fail'
                - fail: Raise ValueError.
                - replace: Drop the table before inserting new values.
                - append: Insert new values to the existing table. The order of insertion is not guaranteed.
            index: default True
                If true, save Series index columns as table columns.
            index_label:
                Column label for index column(s). If None is given (default) and index is True,
                then the index names are used. A sequence should be given if the DataFrame uses MultiIndex.
            table_type:
                The table type of table to be created. The supported values are: ``temp``, ``temporary``,
                and ``transient``. An empty string means to create a permanent table. Learn more about table
                types `here <https://docs.snowflake.com/en/user-guide/tables-temp-transient.html>`_.

        See Also:
            - :func:`to_snowflake <snowflake.snowpark.modin.pandas.frontend.io.to_snowflake>`
            - :func:`DataFrame.to_snowflake <snowflake.snowpark.modin.pandas.DataFrame.to_snowflake>`
            - :func:`read_snowflake <snowflake.snowpark.modin.pandas.frontend.io.read_snowflake>`

        """
        self._query_compiler.to_snowflake(
            name, if_exists, index, index_label, table_type
        )

    def to_snowpark(
        self, index: bool = True, index_label: Optional[IndexLabel] = None
    ) -> SnowparkDataFrame:
        """
        Convert the Snowpark Pandas Series to a Snowpark DataFrame.
        Note that once converted to a Snowpark DataFrame, no ordering information will be preserved. You can call
        reset_index to generate a default index column that is the same as the row position before the call to_snowpark.

        Args:
            index: bool, default True.
                Whether to keep the index columns in the result Snowpark DataFrame. If True, the index columns
                will be the first set of columns. Otherwise, no index column will be included in the final Snowpark
                DataFrame.
            index_label: IndexLabel, default None.
                Column label(s) to use for the index column(s). If None is given (default) and index is True,
                then the original index column labels are used. A sequence should be given if the DataFrame uses
                MultiIndex, and the length of the given sequence should be the same as the number of index columns.

        Returns:
           Snowpark :class:`~snowflake.snowpark.dataframe.DataFrame`
                A Snowpark DataFrame contains the index columns if index=True and all data columns of the Snowpark Pandas
                DataFrame. The identifier for the Snowpark DataFrame will be the normalized quoted identifier with
                the same name as the Pandas label.

        Raises:
             ValueError if duplicated labels occur among the index and data columns.
             ValueError if the label used for a index or data column is None.

        See also:
            - :func:`to_snowpark <snowflake.snowpark.modin.pandas.frontend.io.to_snowpark>`
            - :func:`Series.to_snowpark <snowflake.snowpark.modin.pandas.Series.to_snowpark>`

        Note:
            The labels of the Snowpark Pandas DataFrame or index_label provided will be used as Normalized Snowflake
            Identifiers of the Snowpark DataFrame.
            For details about Normalized Snowflake Identifiers, please refer to the Note in :func:`~snowflake.snowpark.modin.pandas.frontend.io.read_snowflake`

        Examples::

            >>> ser = pd.Series([390., 350., 30., 20.],
            ...                 index=['Falcon', 'Falcon', 'Parrot', 'Parrot'],
            ...                 name="Max Speed")
            >>> ser
            Falcon    390.0
            Falcon    350.0
            Parrot     30.0
            Parrot     20.0
            Name: Max Speed, dtype: float64
            >>> snowpark_df = ser.to_snowpark(index_label="Animal")
            >>> snowpark_df.order_by('"Max Speed"').show()
            --------------------------
            |"Animal"  |"Max Speed"  |
            --------------------------
            |Parrot    |20.0         |
            |Parrot    |30.0         |
            |Falcon    |350.0        |
            |Falcon    |390.0        |
            --------------------------
            <BLANKLINE>
            >>> snowpark_df = ser.to_snowpark(index=False)
            >>> snowpark_df.order_by('"Max Speed"').show()
            ---------------
            |"Max Speed"  |
            ---------------
            |20.0         |
            |30.0         |
            |350.0        |
            |390.0        |
            ---------------
            <BLANKLINE>

            MultiIndex usage
            >>> ser = pd.Series([390., 350., 30., 20.],
            ...                 index=pd.MultiIndex.from_tuples([('bar', 'one'), ('foo', 'one'), ('bar', 'two'), ('foo', 'three')], names=['first', 'second']),
            ...                 name="Max Speed")
            >>> ser
            first  second
            bar    one       390.0
            foo    one       350.0
            bar    two        30.0
            foo    three      20.0
            Name: Max Speed, dtype: float64
            >>> snowpark_df = ser.to_snowpark(index=True, index_label=['A', 'B'])
            >>> snowpark_df.order_by('"A"', '"B"').show()
            -----------------------------
            |"A"  |"B"    |"Max Speed"  |
            -----------------------------
            |bar  |one    |390.0        |
            |bar  |two    |30.0         |
            |foo  |one    |350.0        |
            |foo  |three  |20.0         |
            -----------------------------
            <BLANKLINE>
            >>> snowpark_df = ser.to_snowpark(index=False)
            >>> snowpark_df.order_by('"Max Speed"').show()
            ---------------
            |"Max Speed"  |
            ---------------
            |20.0         |
            |30.0         |
            |350.0        |
            |390.0        |
            ---------------
            <BLANKLINE>
        """
        return self._query_compiler.to_snowpark(index, index_label)

    def to_pandas(
        self,
        *,
        statement_params: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ) -> Series:
        """
        Convert Snowpark Pandas Series to Pandas Series

        Args:
            statement_params: Dictionary of statement level parameters to be set while executing this action.

        See Also:
            - :func:`to_pandas <snowflake.snowpark.modin.pandas.frontend.io.to_pandas>`
            - :func:`DataFrame.to_pandas <snowflake.snowpark.modin.pandas.DataFrame.to_pandas>`

        Returns:
            Pandas Series

        >>> s = pd.Series(['Falcon', 'Falcon',
        ...                 'Parrot', 'Parrot'],
        ...                 name = 'Animal')
        >>> s.to_pandas()
        0    Falcon
        1    Falcon
        2    Parrot
        3    Parrot
        Name: Animal, dtype: object
        """
        return self._to_pandas(statement_params=statement_params, **kwargs)

    def memory_usage(self, index: bool = True, deep: bool = False) -> int:
        """
        Return zero bytes for memory_usage
        """
        return 0

    def infer_objects(self) -> "SnowparkPandasSeries":  # noqa: RT01, D200
        """
        Attempt to infer better dtypes for object columns.
        """
        ErrorMessage.not_implemented()  # pragma: no cover
        return self.__constructor__(query_compiler=self._query_compiler.infer_objects())

    def nunique(self, dropna: bool = True) -> int:
        """
        Return number of unique elements in the series.

        Excludes NA values by default. Snowpark Pandas API does not distinguish between different NaN types like None,
        pd.NA or np.nan and treats them as the same

        Parameters
        ----------
        dropna : bool, default True
            Don't include NaN in the count.

        Returns
        -------
        int

        Examples
        --------
        >>> import snowflake.snowpark.modin.pandas as pd
        >>> import numpy as np
        >>> s = pd.Series([1, 3, 5, 7, 7])
        >>> s
        0    1
        1    3
        2    5
        3    7
        4    7
        dtype: int8

        >>> s.nunique()
        4

        >>> s = pd.Series([pd.NaT, np.nan, pd.NA, None, 1])
        >>> s.nunique()
        1

        >>> s.nunique(dropna=False)
        2

        """
        return super().nunique(dropna=dropna)

    def isin(
        self, values: Union[ListLike, "SnowparkPandasSeries"]
    ) -> "SnowparkPandasSeries":
        """
        Whether elements in Series are contained in `values`.

        Return a boolean Series showing whether each element in the Series
        matches an element in the passed sequence of `values`.

        Caution
        -------
        Snowpark Pandas deviates from Pandas here with respect to NA values: when the value is considered NA or
        values contains at least one NA, None is returned instead of a boolean value.

        Parameters
        ----------
        values : list-like or Series
            The sequence of values to test. Passing in a single string will
            raise a ``TypeError``. Instead, turn a single string into a
            list of one element.

        Returns
        -------
        Series
            Series of booleans indicating if each element is in values.

        Examples
        --------
        >>> s = pd.Series(['lama', 'cow', 'lama', 'beetle', 'lama',
        ...                'hippo'], name='animal')
        >>> s.isin(['cow', 'lama'])
        0     True
        1     True
        2     True
        3    False
        4     True
        5    False
        Name: animal, dtype: bool

        To invert the boolean values, use the ``~`` operator:

        >>> ~s.isin(['cow', 'lama'])
        0    False
        1    False
        2    False
        3     True
        4    False
        5     True
        Name: animal, dtype: bool

        Passing a single string as ``s.isin('lama')`` will raise an error. Use
        a list of one element instead:

        >>> s.isin(['lama'])
        0     True
        1    False
        2     True
        3    False
        4     True
        5    False
        Name: animal, dtype: bool

        Strings and integers are distinct and are therefore not comparable:

        Snowflake considers '1' and 1 to be equal, as an implicit cast can be performed to turn one into the other.

        >>> pd.Series([1]).isin(['1'])
        0    True
        dtype: bool
        >>> pd.Series([1.1]).isin(['1.1'])
        0    True
        dtype: bool

        >>> pd.Series([1, 2, None]).isin([2])
        0    False
        1     True
        2     None
        dtype: object
        """

        return super().isin(values)
