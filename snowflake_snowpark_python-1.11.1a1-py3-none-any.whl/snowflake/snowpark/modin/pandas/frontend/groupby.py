#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

# Licensed to Modin Development Team under one or more contributor license agreements.
# See the NOTICE file distributed with this work for additional information regarding
# copyright ownership.  The Modin Development Team licenses this file to you under the
# Apache License, Version 2.0 (the "License"); you may not use this file except in
# compliance with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under
# the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific language
# governing permissions and limitations under the License.

# Code in this file may constitute partial or total reimplementation, or modification of
# existing code originally distributed by the Modin project, under the Apache License,
# Version 2.0.

"""Implement GroupBy public API as pandas does."""

from textwrap import dedent
from typing import Any, Callable, Dict, List, Literal, Optional

import numpy as np  # noqa: F401
import pandas
import pandas.core.groupby
from pandas._libs.lib import no_default
from pandas._typing import AggFuncType, IndexLabel
from pandas.core.dtypes.common import is_dict_like, is_list_like, is_numeric_dtype
from pandas.errors import SpecificationError
from pandas.util._decorators import doc

# following import are used in doctest
from snowflake.snowpark.modin import pandas as pd  # noqa: F401

# Snowpark Pandas API version
from snowflake.snowpark.modin.pandas.frontend.snow_series import (
    SnowparkPandasSeries as Series,
)
from snowflake.snowpark.modin.pandas.frontend.utils import (
    raise_if_native_pandas_objects,
    validate_and_try_convert_agg_func_arg_func_to_str,
    warning_if_engine_args_is_set,
)
from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
    SnowflakeQueryCompiler,
)
from snowflake.snowpark.modin.pandas.utils.core_utils import (
    _inherit_docstrings,
    hashable,
)
from snowflake.snowpark.modin.pandas.utils.error_message import ErrorMessage
from snowflake.snowpark.modin.pandas.utils.warning_message import WarningMessage

_DEFAULT_BEHAVIOUR = {
    "__class__",
    "__getitem__",
    "__init__",
    "__iter__",
    "_as_index",
    "_axis",
    "_by",
    "_check_index_name",
    "_columns",
    "_df",
    "_groups_cache",
    "_idx_name",
    "_index",
    "_indices_cache",
    "_internal_by",
    "_internal_by_cache",
    "_iter",
    "_kwargs",
    "_level",
    "_pandas_class",
    "_query_compiler",
    "_sort",
    "_squeeze",
    "_wrap_aggregation",
}


_groupby_agg_method_engine_template = """
Compute {fname} of group values.

Parameters
----------
numeric_only : bool, default {no}
    Include only float, int, boolean columns.
    From pandas 2.0.0, numeric_only no longer accepts ``None``.

min_count : int, default {mc}
    The required number of valid values to perform the operation. If fewer
    than ``min_count`` non-NA values are present the result will be NA.

engine : str, default None {e}
    * ``'cython'`` : Runs rolling apply through C-extensions from cython.
    * ``'numba'`` : Runs rolling apply through JIT compiled code from numba.
        Only available when ``raw`` is set to ``True``.
    * ``None`` : Defaults to ``'cython'`` or globally setting ``compute.use_numba``

    **This parameter is ignored in Snowpark Pandas. The execution engine will always be Snowflake.**

engine_kwargs : dict, default None {ek}
    * For ``'cython'`` engine, there are no accepted ``engine_kwargs``
    * For ``'numba'`` engine, the engine can accept ``nopython``, ``nogil``
        and ``parallel`` dictionary keys. The values must either be ``True`` or
        ``False``. The default ``engine_kwargs`` for the ``'numba'`` engine is
        ``{{'nopython': True, 'nogil': False, 'parallel': False}}`` and will be
        applied to both the ``func`` and the ``apply`` groupby aggregation.

    **This parameter is ignored in Snowpark Pandas. The execution engine will always be Snowflake.**

Returns
-------
:class:`~snowflake.snowpark.modin.pandas.frontend.snow_series.SnowparkPandasSeries` or :class:`~snowflake.snowpark.modin.pandas.frontend.snow_dataframe.SnowparkPandasDataFrame`
    Computed {fname} of values within each group.

Examples
--------
{example}
"""

_agg_template = """
Aggregate using one or more operations over the specified axis.

Parameters
----------
func : function, str, list, or dict
    Function to use for aggregating the data. If a function, must either
    work when passed a {klass} or when passed to {klass}.apply.

    Accepted combinations are:

    - function
    - string function name
    - list of functions and/or function names, e.g. ``[np.sum, 'mean']``
    - dict of axis labels -> functions, function names or list of such.

*args
    Positional arguments to pass to func.
engine : str, default None
    * ``'cython'`` : Runs the function through C-extensions from cython.
    * ``'numba'`` : Runs the function through JIT compiled code from numba.
    * ``None`` : Defaults to ``'cython'`` or globally setting ``compute.use_numba``

    **This parameter is ignored in Snowpark Pandas. The execution engine will always be Snowflake.**

engine_kwargs : dict, default None
    * For ``'cython'`` engine, there are no accepted ``engine_kwargs``
    * For ``'numba'`` engine, the engine can accept ``nopython``, ``nogil``
      and ``parallel`` dictionary keys. The values must either be ``True`` or
      ``False``. The default ``engine_kwargs`` for the ``'numba'`` engine is
      ``{{'nopython': True, 'nogil': False, 'parallel': False}}`` and will be
      applied to the function

    **This parameter is ignored in Snowpark Pandas. The execution engine will always be Snowflake.**

**kwargs
    keyword arguments to be passed into func.

Returns
-------
{klass}

{examples}"""


def _groupby_method_not_implemented_error(method: str):
    message = f"{method} is not implemented for GroupBy"
    ErrorMessage.not_implemented(message)


@_inherit_docstrings(pandas.core.groupby.DataFrameGroupBy)
class DataFrameGroupBy:
    _pandas_class = pandas.core.groupby.DataFrameGroupBy

    def __init__(
        self,
        df,
        by,
        axis,
        level,
        as_index,
        sort,
        group_keys,
        squeeze,
        idx_name,
        **kwargs,
    ) -> None:
        self._axis = axis
        self._idx_name = idx_name
        self._df = df
        self._df._query_compiler.validate_groupby(by, axis, level)
        self._query_compiler = self._df._query_compiler
        self._columns = self._query_compiler.columns
        self._by = by
        self._level = level
        self._kwargs = {
            "level": level,
            "sort": sort,
            "as_index": as_index,
            "group_keys": group_keys,
        }
        self._squeeze = squeeze
        self._kwargs.update(kwargs)

    def __getattr__(self, key):
        """
        Alter regular attribute access, looks up the name in the columns.

        Parameters
        ----------
        key : str
            Attribute name.

        Returns
        -------
        The value of the attribute.
        """
        try:
            return object.__getattribute__(self, key)
        except AttributeError as err:
            if key in self._columns:
                return self.__getitem__(key)
            raise err

    @property
    def ngroups(self):
        return self._query_compiler.groupby_ngroups(
            by=self._by,
            axis=self._axis,
            groupby_kwargs=self._kwargs,
        )

    def skew(self, *args, **kwargs):
        _groupby_method_not_implemented_error("skew")

    def ffill(self, limit=None):
        _groupby_method_not_implemented_error("ffill")

    def sem(self, ddof=1):
        _groupby_method_not_implemented_error("sem")

    def value_counts(
        self,
        subset=None,
        normalize: bool = False,
        sort: bool = True,
        ascending: bool = False,
        dropna: bool = True,
    ):
        _groupby_method_not_implemented_error("value_counts")

    def mean(
        self,
        numeric_only: bool = False,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
    ):
        """
        Compute mean of groups, excluding missing values.

        Parameters
        ----------
        numeric_only : bool, default False
            Include only float, int, boolean columns.

        engine : str, default None
            * ``'cython'`` : Runs the operation through C-extensions from cython.
            * ``'numba'`` : Runs the operation through JIT compiled code from numba.
            * ``None`` : Defaults to ``'cython'`` or globally setting ``compute.use_numba``

            Note that this parameter is ignored in Snowpark Pandas, and the execution engine will always
            be Snowflake.

        engine_kwargs : dict, default None
            * For ``'cython'`` engine, there are no accepted ``engine_kwargs``
            * For ``'numba'`` engine, the engine can accept ``nopython``, ``nogil``
                and ``parallel`` dictionary keys. The values must either be ``True`` or
                ``False``. The default ``engine_kwargs`` for the ``'numba'`` engine is
                ``{{'nopython': True, 'nogil': False, 'parallel': False}}``

            Note that this parameter is ignored in Snowpark Pandas, and the execution engine will always
            be Snowflake. Same as the engine parameter.

        Returns
        -------
        SnowparkPandasSeries or SnowparkPandasDataFrame

        Examples
        --------
        >>> df = pd.DataFrame({'A': [1, 1, 2, 1, 2],
        ...                    'B': [np.nan, 2, 3, 4, 5],
        ...                    'C': [1, 2, 1, 1, 2]}, columns=['A', 'B', 'C'])

        Groupby one column and return the mean of the remaining columns in
        each group.

        >>> df.groupby('A').mean()      # doctest: +NORMALIZE_WHITESPACE
             B         C
        A
        1  3.0  1.333333
        2  4.0  1.500000

        Groupby two columns and return the mean of the remaining column.

        >>> df.groupby(['A', 'B']).mean()   # doctest: +NORMALIZE_WHITESPACE
               C
        A B
        1 2.0  2.000000
          4.0  1.000000
        2 3.0  1.000000
          5.0  2.000000

        Groupby one column and return the mean of only particular column in
        the group.

        >>> df.groupby('A')['B'].mean()
        A
        1    3.0
        2    4.0
        Name: B, dtype: float64
        """
        warning_if_engine_args_is_set("groupby_mean", engine, engine_kwargs)
        return self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=numeric_only,
            agg_func="mean",
            agg_kwargs=dict(numeric_only=numeric_only),
        )

    def any(self, skipna=True):
        _groupby_method_not_implemented_error("any")

    @property
    def plot(self):  # pragma: no cover
        _groupby_method_not_implemented_error("plot")

    def ohlc(self):
        _groupby_method_not_implemented_error("ohlc")

    def __bytes__(self):
        """
        Convert DataFrameGroupBy object into a python2-style byte string.

        Returns
        -------
        bytearray
            Byte array representation of `self`.

        Notes
        -----
        Deprecated and removed in pandas and will be likely removed in Modin.
        """
        _groupby_method_not_implemented_error("__bytes__")

    @property
    def tshift(self):
        _groupby_method_not_implemented_error("tshift")

    _groups_cache = no_default

    # TODO: since python 3.9:
    # @cached_property
    @property
    def groups(self):
        _groupby_method_not_implemented_error("groups")

    @doc(
        _groupby_agg_method_engine_template,
        fname="min",
        no=False,
        mc=-1,
        e=None,
        ek=None,
        example=dedent(
            """\
        For SeriesGroupBy:

        >>> lst = ['a', 'a', 'b', 'b']
        >>> ser = pd.Series([1, 2, 3, 4], index=lst)
        >>> ser
        a    1
        a    2
        b    3
        b    4
        dtype: int8
        >>> ser.groupby(level=0).min()
        a    1
        b    3
        dtype: int8

        For DataFrameGroupBy:

        >>> data = [[1, 8, 2], [1, 2, 5], [2, 5, 8], [2, 6, 9]]
        >>> df = pd.DataFrame(data, columns=["a", "b", "c"],
        ...                   index=["tiger", "leopard", "cheetah", "lion"])
        >>> df
                 a  b  c
        tiger    1  8  2
        leopard  1  2  5
        cheetah  2  5  8
        lion     2  6  9
        >>> df.groupby("a").min()
           b  c
        a
        1  2  2
        2  5  8"""
        ),
    )
    def min(
        self,
        numeric_only: bool = False,
        min_count: int = -1,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
    ):
        warning_if_engine_args_is_set("groupby_min", engine, engine_kwargs)
        return self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=numeric_only,
            agg_func="min",
            agg_kwargs=dict(min_count=min_count, numeric_only=numeric_only),
        )

    def idxmax(self):
        _groupby_method_not_implemented_error("idxmax")

    @property
    def ndim(self):
        """
        Return 2.

        Returns
        -------
        int
            Returns 2.

        Notes
        -----
        Deprecated and removed in pandas and will be likely removed in Modin.
        """
        return 2  # ndim is always 2 for DataFrames

    def shift(self, periods=1, freq=None, axis=0, fill_value=None):
        _groupby_method_not_implemented_error("shift")

    def nth(self, n, dropna=None):
        _groupby_method_not_implemented_error("nth")

    def cumsum(self, axis=0, *args, **kwargs):
        _groupby_method_not_implemented_error("cumsum")

    _indices_cache = no_default

    # TODO: since python 3.9:
    # @cached_property
    @property
    def indices(self):
        _groupby_method_not_implemented_error("indices")

    def pct_change(self, *args, **kwargs):
        _groupby_method_not_implemented_error("pct_change")

    def filter(self, func, dropna=True, *args, **kwargs):
        _groupby_method_not_implemented_error("filter")

    def cummax(self, axis=0, **kwargs):
        _groupby_method_not_implemented_error("cummax")

    def apply(self, func, *args, **kwargs):
        _groupby_method_not_implemented_error("apply")

    @property
    def dtypes(self):
        _groupby_method_not_implemented_error("dtypes")

    def first(self, **kwargs):
        _groupby_method_not_implemented_error("first")

    def backfill(self, limit=None):
        _groupby_method_not_implemented_error("backfill")

    _internal_by_cache = no_default

    # TODO: since python 3.9:
    # @cached_property
    @property
    def _internal_by(self):
        """
        Get only those components of 'by' that are column labels of the source frame.

        Returns
        -------
        tuple of labels
        """
        if self._internal_by_cache is not no_default:
            return self._internal_by_cache

        by_list = self._by if is_list_like(self._by) else [self._by]

        internal_by = tuple(
            by for by in by_list if hashable(by) and by in self._columns
        )

        self._internal_by_cache = internal_by
        return internal_by

    def __getitem__(self, key):
        """
        Implement indexing operation on a DataFrameGroupBy object.

        Parameters
        ----------
        key : list or str
            Names of columns to use as subset of original object.

        Returns
        -------
        DataFrameGroupBy or SeriesGroupBy
            Result of indexing operation.

        Raises
        ------
        NotImplementedError
            Column lookups on GroupBy when selected column overlaps with the by columns.

            we currently do not support select data columns that overlaps with by columns, like
            df.groupby("A")["A", "C"], where column "A" occurs in both the groupby and column selection.
            This is because in regular groupby, one by column cannot be mapped to multiple columns,
            for example with a dataframe have columns=['A', 'B', 'A'], where 'A' corresponds to two columns,
            df.groupby('A') will raise an error. However, with getitem, the new columns selected
            is treated differently and they can be duplicate of the by column. For example: it is valid to
            have df.groupby("A")["A", "A", "C"] even though the result dataframe after colum select have
            multiple column "A".
            In order to handle this correctly, we need to record the columns selected and move the actual column
            selection to query backend. Proper fallback with column selection is also required.
            Since there is no such usage in our current known usage pattern, and Modin does not support this case.
            We raise a NotImplementedError, and deffer the support to later.
            TODO (SNOW-894942): Handle getitem overlap with groupby column
        """
        if self._axis == 1:
            raise ValueError("Cannot subset columns when using axis=1")

        # These parameters are common for building the resulted Series or DataFrame groupby object
        kwargs = {
            **self._kwargs.copy(),
            "by": self._by,
            "axis": self._axis,
            "idx_name": self._idx_name,
            "squeeze": self._squeeze,
        }
        # The rules of type deduction for the resulted object is the following:
        #   1. If `key` is a list-like or `as_index is False`, then the resulted object is a DataFrameGroupBy
        #   2. Otherwise, the resulted object is SeriesGroupBy
        #   3. Result type does not depend on the `by` origin
        # Examples:
        #   - drop: any, as_index: any, __getitem__(key: list_like) -> DataFrameGroupBy
        #   - drop: any, as_index: False, __getitem__(key: any) -> DataFrameGroupBy
        #   - drop: any, as_index: True, __getitem__(key: label) -> SeriesGroupBy
        if is_list_like(key):
            make_dataframe = True
        else:
            if self._as_index:
                make_dataframe = False
            else:
                make_dataframe = True
            key = [key]

        column_index = self._df.columns
        # validate that all keys are labels belong to the data column of the df
        for label in key:
            if not (label in column_index):
                raise KeyError(f"Columns not found: '{label}'")

        # internal_by records all label in by that belongs to the data columns
        internal_by = frozenset(self._internal_by)
        if len(internal_by.intersection(key)) != 0:
            message = (
                "Data column selection with overlap of 'by' columns is not yet supported, "
                "please duplicate the overlapped by columns and rename it to a different name"
            )
            ErrorMessage.not_implemented(message=message)

        # select the union of the internal bys and select keys. Here we find all integer
        # positions for all the selected columns, and then call iloc to select all columns.
        # This is because loc currently doesn't support select with multiindex, once iloc and
        # dataframe getitem is supported, this can be replaced with df[list(internal_by) + list(key)]
        # TODO (SNOW-896342): update self._df.iloc[:, ilocs_list] to use df[list(internal_by) + list(key)]
        #           once dataframe getitem is supported.
        _, by_ilocs = column_index._get_indexer_strict(list(internal_by), "columns")
        _, key_ilocs = column_index._get_indexer_strict(list(key), "columns")
        ilocs_list = list(by_ilocs) + list(key_ilocs)

        if len(key_ilocs) > 1:
            make_dataframe = True

        if make_dataframe:
            return DataFrameGroupBy(
                self._df.iloc[:, ilocs_list],
                **kwargs,
            )
        else:
            return SeriesGroupBy(
                self._df.iloc[:, ilocs_list],
                **kwargs,
            )

    def cummin(self, axis=0, **kwargs):
        _groupby_method_not_implemented_error("cummin")

    def bfill(self, limit=None):
        _groupby_method_not_implemented_error("bfill")

    def idxmin(self):
        _groupby_method_not_implemented_error("idxmin")

    def prod(self, numeric_only=None, min_count=0):
        _groupby_method_not_implemented_error("prod")

    def std(
        self,
        ddof: int = 1,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
        numeric_only: bool = False,
    ):
        """
        Compute standard deviation of groups, excluding missing values.

        For multiple groupings, the result index will be a MultiIndex.

        Parameters
        ----------
        ddof : int, default 1.
            Degrees of freedom.
            When ddof is 0/1, the operation is executed with Snowflake. Otherwise, it falls back with
            native pandas using stored procedure.


        engine : str, default None
            In pandas engine can be configured as ``'cython'`` or ``'numba'`` , and ``None`` defaults to
            ``'cython'`` or globally setting ``compute.use_numba``.
            This parameter is ignored in Snowpark Pandas API. The execution engine will always be snowflake. (Same as
            var)

        engine_kwargs : dict, default None
            Configuration keywords for the configured execution egine.
            Same as engine parameter, this parameter is ignored in Snowpark Pandas API. (Same as var)

        numeric_only : bool, default False
            Include only `float`, `int` or `boolean` data columns.

        Returns
        -------
        Series or DataFrame
        Standard deviation of values within each group.

        Examples
        --------
        For SeriesGroupBy:
        >>> lst = ['a', 'a', 'a', 'b', 'b', 'b', 'c']
        >>> ser = pd.Series([7, 2, 8, 4, 3, 3, 1], index=lst)
        >>> ser
        a    7
        a    2
        a    8
        b    4
        b    3
        b    3
        c    1
        dtype: int8
        >>> ser.groupby(level=0).std()
        a    3.21455
        b    0.57735
        c        NaN
        dtype: float64
        >>> ser.groupby(level=0).std(ddof=0)
        a    2.624669
        b    0.471404
        c    0.000000
        dtype: float64

        Note that if the number of elements in a group is less or equal to the ddof, the result for the
        group will be NaN/None. For example, the value for group c is NaN when we call ser.groupby(level=0).std(),
        and the default ddof is 1.

        For DataFrameGroupBy:

        >>> data = {'a': [1, 3, 5, 7, 7, 8, 3], 'b': [1, 4, 8, 4, 4, 2, 1]}
        >>> df = pd.DataFrame(data, index=pd.Index(['dog', 'dog', 'dog',
        ...                   'mouse', 'mouse', 'mouse', 'mouse'], name='c'))
        >>> df      # doctest: +NORMALIZE_WHITESPACE
               a  b
        c
        dog    1  1
        dog    3  4
        dog    5  8
        mouse  7  4
        mouse  7  4
        mouse  8  2
        mouse  3  1
        >>> df.groupby('c').std()       # doctest: +NORMALIZE_WHITESPACE
                      a         b
        c
        dog    2.000000  3.511885
        mouse  2.217356  1.500000
        >>> data = {'a': [1, 3, 5, 7, 7, 8, 3], 'b': ['c', 'e', 'd', 'a', 'a', 'b', 'e']}
        >>> df = pd.DataFrame(data, index=pd.Index(['dog', 'dog', 'dog',
        ...                   'mouse', 'mouse', 'mouse', 'mouse'], name='c'))
        >>> df      # doctest: +NORMALIZE_WHITESPACE
               a  b
        c
        dog    1  c
        dog    3  e
        dog    5  d
        mouse  7  a
        mouse  7  a
        mouse  8  b
        mouse  3  e
        >>> df.groupby('c').std(numeric_only=True)       # doctest: +NORMALIZE_WHITESPACE
                      a
        c
        dog    2.000000
        mouse  2.217356
        """
        warning_if_engine_args_is_set("groupby_std", engine, engine_kwargs)
        return self._wrap_aggregation(
            qc_method=SnowflakeQueryCompiler.groupby_agg,
            numeric_only=numeric_only,
            agg_func="std",
            agg_kwargs=dict(ddof=ddof, numeric_only=numeric_only),
        )

    _agg_examples_dataframe_doc = dedent(
        """
    Examples
    --------
    >>> df = pd.DataFrame(
    ...     {
    ...         "A": [1, 1, 2, 2],
    ...         "B": [1, 2, 3, 4],
    ...         "C": [0.362838, 0.227877, 1.267767, -0.562860],
    ...     }
    ... )

    >>> df
       A  B         C
    0  1  1  0.362838
    1  1  2  0.227877
    2  2  3  1.267767
    3  2  4 -0.562860

    The aggregation is for each column.

    >>> df.groupby('A').agg('min')  # doctest: +NORMALIZE_WHITESPACE
       B         C
    A
    1  1  0.227877
    2  3 -0.562860

    Multiple aggregations

    >>> df.groupby('A').agg(['min', 'max']) # doctest: +NORMALIZE_WHITESPACE
        B             C
      min max       min       max
    A
    1   1   2  0.227877  0.362838
    2   3   4 -0.562860  1.267767

    Select a column for aggregation

    >>> df.groupby('A').B.agg(['min', 'max'])   # doctest: +NORMALIZE_WHITESPACE
       min  max
    A
    1    1    2
    2    3    4

    User-defined function for aggregation

    >>> df.groupby('A').agg({'B': ['min', 'max'], 'C': 'sum'})  # doctest: +NORMALIZE_WHITESPACE
        B             C
      min max       sum
    A
    1   1   2  0.590715
    2   3   4  0.704907
    """
    )

    @doc(
        _agg_template,
        examples=_agg_examples_dataframe_doc,
        klass="SnowparkPandasDataFrame",
    )
    def aggregate(
        self,
        func: Optional[AggFuncType] = None,
        *args: Any,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
        **kwargs: Any,
    ):
        warning_if_engine_args_is_set("groupby_aggregate", engine, engine_kwargs)
        if self._axis != 0 and (is_dict_like(func) or is_list_like(func)):
            # This is the same as pandas for func that is a list or dict
            ErrorMessage.not_implemented(
                "axis other than 0 is not supported"
            )  # pragma: no cover

        func = validate_and_try_convert_agg_func_arg_func_to_str(
            agg_func=func, obj=self, allow_duplication=True
        )

        if isinstance(func, str):
            # Using "getattr" here masks possible AttributeError which we throw
            # in __getattr__, so we should call __getattr__ directly instead.
            agg_func = self.__getattr__(func)
            if callable(agg_func):
                return agg_func(*args, **kwargs)

        # when the aggregation function passed in is list like always return a Dataframe regardless
        # it is SeriesGroupBy or DataFrameGroupBy
        is_result_dataframe = (self.ndim == 2) or is_list_like(func)
        result = self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=False,
            agg_func=func,
            agg_args=args,
            agg_kwargs=kwargs,
            how="axis_wise",
            is_result_dataframe=is_result_dataframe,
        )
        return result

    agg = aggregate

    def last(self, **kwargs):
        _groupby_method_not_implemented_error("last")

    def mad(self, **kwargs):
        _groupby_method_not_implemented_error("mad")

    def rank(self, **kwargs):
        _groupby_method_not_implemented_error("rank")

    @property
    def corrwith(self):
        _groupby_method_not_implemented_error("corrwith")

    def pad(self, limit=None):
        _groupby_method_not_implemented_error("pad")

    @doc(
        _groupby_agg_method_engine_template,
        fname="max",
        no=False,
        mc=-1,
        e=None,
        ek=None,
        example=dedent(
            """\
        For SeriesGroupBy:

        >>> lst = ['a', 'a', 'b', 'b']
        >>> ser = pd.Series([1, 2, 3, 4], index=lst)
        >>> ser
        a    1
        a    2
        b    3
        b    4
        dtype: int8
        >>> ser.groupby(level=0).max()
        a    2
        b    4
        dtype: int8

        For DataFrameGroupBy:

        >>> data = [[1, 8, 2], [1, 2, 5], [2, 5, 8], [2, 6, 9]]
        >>> df = pd.DataFrame(data, columns=["a", "b", "c"],
        ...                   index=["tiger", "leopard", "cheetah", "lion"])
        >>> df
                 a  b  c
        tiger    1  8  2
        leopard  1  2  5
        cheetah  2  5  8
        lion     2  6  9
        >>> df.groupby("a").max()
           b  c
        a
        1  8  5
        2  6  9"""
        ),
    )
    def max(
        self,
        numeric_only: bool = False,
        min_count: int = -1,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
    ):
        warning_if_engine_args_is_set("groupby_max", engine, engine_kwargs)
        return self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=numeric_only,
            agg_func="max",
            agg_kwargs=dict(min_count=min_count, numeric_only=numeric_only),
        )

    def var(
        self,
        ddof: int = 1,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
        numeric_only: bool = False,
    ):
        """
        Compute variance of groups, excluding missing values.

        For multiple groupings, the result index will be a MultiIndex.

        Parameters
        ----------
        ddof : int, default 1
            Degrees of freedom.
            When ddof is 0/1, the operation is executed with Snowflake. Otherwise, it falls back with
            native pandas using stored procedure.

        engine : str, default None
            In pandas engine can be configured as ``'cython'`` or ``'numba'`` , and ``None`` defaults to
            ``'cython'`` or globally setting ``compute.use_numba``.
            This parameter is ignored in Snowpark Pandas API. The execution engine will always be snowflake. (Same as
            std)

        engine_kwargs : dict, default None
            Configuration keywords for the configured execution egine.
            Same as engine parameter, this parameter is ignored in Snowpark Pandas API.  (Same as std)

        numeric_only : bool, default False
            Include only `float`, `int` or `boolean` data columns.

        Returns
        -------
        Series or DataFrame
            Variance of values within each group.

        Examples
        --------
        For SeriesGroupBy:
        >>> lst = ['a', 'a', 'a', 'b', 'b', 'b', 'c']
        >>> ser = pd.Series([7, 2, 8, 4, 3, 3, 1], index=lst)
        >>> ser
        a    7
        a    2
        a    8
        b    4
        b    3
        b    3
        c    1
        dtype: int8
        >>> ser.groupby(level=0).var()
        a    10.333333
        b     0.333333
        c         None
        dtype: object
        >>> ser.groupby(level=0).var(ddof=0)
        a    6.888889
        b    0.222222
        c    0.000000
        dtype: object

        Note that if the number of elements in a group is less or equal to the ddof, the result for the
        group will be NaN/None. For example, the value for group c is NaN when we call ser.groupby(level=0).var(),
        and the default ddof is 1.

        For DataFrameGroupBy:

        >>> data = {'a': [1, 3, 5, 7, 7, 8, 3], 'b': [1, 4, 8, 4, 4, 2, 1]}
        >>> df = pd.DataFrame(data, index=pd.Index(['dog', 'dog', 'dog',
        ...                   'mouse', 'mouse', 'mouse', 'mouse'], name='c'))
        >>> df      # doctest: +NORMALIZE_WHITESPACE
               a  b
        c
        dog    1  1
        dog    3  4
        dog    5  8
        mouse  7  4
        mouse  7  4
        mouse  8  2
        mouse  3  1
        >>> df.groupby('c').var()       # doctest: +NORMALIZE_WHITESPACE
                      a          b
        c
        dog    4.000000  12.333333
        mouse  4.916667   2.250000
        >>> data = {'a': [1, 3, 5, 7, 7, 8, 3], 'b': ['c', 'e', 'd', 'a', 'a', 'b', 'e']}
        >>> df = pd.DataFrame(data, index=pd.Index(['dog', 'dog', 'dog',
        ...                   'mouse', 'mouse', 'mouse', 'mouse'], name='c'))
        >>> df      # doctest: +NORMALIZE_WHITESPACE
               a  b
        c
        dog    1  c
        dog    3  e
        dog    5  d
        mouse  7  a
        mouse  7  a
        mouse  8  b
        mouse  3  e
        >>> df.groupby('c').var(numeric_only=True)       # doctest: +NORMALIZE_WHITESPACE
                      a
        c
        dog    4.000000
        mouse  4.916667
        """
        warning_if_engine_args_is_set("groupby_var", engine, engine_kwargs)

        return self._wrap_aggregation(
            qc_method=SnowflakeQueryCompiler.groupby_agg,
            numeric_only=numeric_only,
            agg_func="var",
            agg_kwargs=dict(ddof=ddof, numeric_only=numeric_only),
        )

    def get_group(self, name, obj=None):
        _groupby_method_not_implemented_error("get_group")

    def __len__(self):
        _groupby_method_not_implemented_error("__len__")

    def all(self, skipna=True):
        _groupby_method_not_implemented_error("all")

    def size(self):
        _groupby_method_not_implemented_error("size")

    @doc(
        _groupby_agg_method_engine_template,
        fname="sum",
        no=False,
        mc=0,
        e=None,
        ek=None,
        example=dedent(
            """\
        For SeriesGroupBy:

        >>> lst = ['a', 'a', 'b', 'b']
        >>> ser = pd.Series([1, 2, 3, 4], index=lst)
        >>> ser
        a    1
        a    2
        b    3
        b    4
        dtype: int8
        >>> ser.groupby(level=0).sum()
        a    3
        b    7
        dtype: int8

        For DataFrameGroupBy:

        >>> data = [[1, 8, 2], [1, 2, 5], [2, 5, 8], [2, 6, 9]]
        >>> df = pd.DataFrame(data, columns=["a", "b", "c"],
        ...                   index=["tiger", "leopard", "cheetah", "lion"])
        >>> df
                 a  b  c
        tiger    1  8  2
        leopard  1  2  5
        cheetah  2  5  8
        lion     2  6  9
        >>> df.groupby("a").sum()
            b   c
        a
        1  10   7
        2  11  17"""
        ),
    )
    def sum(
        self,
        numeric_only=False,
        min_count=0,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
    ):
        warning_if_engine_args_is_set("groupby_sum", engine, engine_kwargs)
        return self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=numeric_only,
            agg_func="sum",
            agg_kwargs=dict(min_count=min_count, numeric_only=numeric_only),
        )

    def describe(self, **kwargs):
        _groupby_method_not_implemented_error("describe")

    def boxplot(
        self,
        grouped,
        subplots=True,
        column=None,
        fontsize=None,
        rot=0,
        grid=True,
        ax=None,
        figsize=None,
        layout=None,
        **kwargs,
    ):
        _groupby_method_not_implemented_error("boxplot")

    def ngroup(self, ascending=True):
        _groupby_method_not_implemented_error("ngroup")

    def nunique(self, dropna=True):
        _groupby_method_not_implemented_error("nunique")

    def resample(self, rule, *args, **kwargs):
        _groupby_method_not_implemented_error("resample")

    def sample(self, n=None, frac=None, replace=False, weights=None, random_state=None):
        _groupby_method_not_implemented_error("sample")

    def median(self, numeric_only: bool = False):
        """
        Compute median of groups, excluding missing values.

        For multiple groupings, the result index will be a MultiIndex.

        Parameters
        ----------
        numeric_only : bool, default False
            Include only float, int, boolean columns.

        Returns
        -------
        SnowparkPandasSeries or SnowparkPandasDataFrame
            Median of values within each group.

        Examples
        --------
        For SeriesGroupBy:

        >>> lst = ['a', 'a', 'a', 'b', 'b', 'b']
        >>> ser = pd.Series([7, 2, 8, 4, 3, 3], index=lst)
        >>> ser
        a    7
        a    2
        a    8
        b    4
        b    3
        b    3
        dtype: int8
        >>> ser.groupby(level=0).median()
        a    7.000
        b    3.000
        dtype: object

        For DataFrameGroupBy:

        >>> data = {'a': [1, 3, 5, 7, 7, 8, 3], 'b': [1, 4, 8, 4, 4, 2, 1]}
        >>> df = pd.DataFrame(data, index=['dog', 'dog', 'dog',
        ...                   'mouse', 'mouse', 'mouse', 'mouse'])
        >>> df
               a  b
        dog    1  1
        dog    3  4
        dog    5  8
        mouse  7  4
        mouse  7  4
        mouse  8  2
        mouse  3  1
        >>> df.groupby(level=0).median()
                   a      b
        dog    3.000  4.000
        mouse  7.000  3.000
        """
        return self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=numeric_only,
            agg_func="median",
            agg_kwargs=dict(numeric_only=numeric_only),
        )

    def head(self, n=5):
        _groupby_method_not_implemented_error("head")

    def cumprod(self, axis=0, *args, **kwargs):
        _groupby_method_not_implemented_error("cumprod")

    def __iter__(self):
        return self._iter.__iter__()

    def cov(self):
        _groupby_method_not_implemented_error("cov")

    def transform(self, func, *args, **kwargs):
        _groupby_method_not_implemented_error("transform")

    def corr(self, **kwargs):
        _groupby_method_not_implemented_error("corr")

    def fillna(self, *args, **kwargs):
        _groupby_method_not_implemented_error("fillna")

    def count(self):
        """
        Compute count of group, excluding missing values.

        Returns
        -------
        A :class:`SnowparkPandasSeries` or :class:`SnowparkPandasDataFrame`
            Count of values within each group.

        Examples
        --------
        For SeriesGroupBy:

            >>> lst = ['a', 'a', 'b']
            >>> ser = pd.Series([1, 2, np.nan], index=lst)
            >>> ser
            a    1.0
            a    2.0
            b    NaN
            dtype: float64
            >>> ser.groupby(level=0).count()
            a    2
            b    0
            dtype: int64

        For DataFrameGroupBy:

            >>> data = [[1, np.nan, 3], [1, np.nan, 6], [7, 8, 9]]
            >>> df = pd.DataFrame(data, columns=["a", "b", "c"],
            ...                   index=["cow", "horse", "bull"])
            >>> df
                   a    b  c
            cow    1  NaN  3
            horse  1  NaN  6
            bull   7  8.0  9
            >>> df.groupby("a").count()     # doctest: +NORMALIZE_WHITESPACE
               b  c
            a
            1  0  2
            7  1  1
        """
        result = self._wrap_aggregation(
            qc_method=type(self._query_compiler).groupby_agg,
            numeric_only=False,
            agg_func="count",
        )
        return result

    def pipe(self, func, *args, **kwargs):
        _groupby_method_not_implemented_error("pipe")

    def cumcount(self, ascending=True):
        _groupby_method_not_implemented_error("cumcount")

    def tail(self, n=5):
        _groupby_method_not_implemented_error("tail")

    # expanding and rolling are unique cases and need to likely be handled
    # separately. They do not appear to be commonly used.
    def expanding(self, *args, **kwargs):
        _groupby_method_not_implemented_error("expanding")

    def rolling(self, *args, **kwargs):
        _groupby_method_not_implemented_error("rolling")

    def hist(self):
        _groupby_method_not_implemented_error("hist")

    def quantile(self, q=0.5, interpolation="linear"):
        return self._wrap_aggregation(
            type(self._query_compiler).groupby_agg,
            numeric_only=False,
            agg_func="quantile",
            agg_kwargs=dict(q=q, interpolation=interpolation),
        )

    def diff(self):
        _groupby_method_not_implemented_error("diff")

    def take(self, *args, **kwargs):
        _groupby_method_not_implemented_error("take")

    @property
    def _index(self):
        """
        Get index value.

        Returns
        -------
        pandas.Index
            Index value.
        """
        return self._query_compiler.index

    @property
    def _sort(self):
        """
        Get sort parameter value.

        Returns
        -------
        bool
            Value of sort parameter used to create DataFrameGroupBy object.
        """
        return self._kwargs.get("sort")

    @property
    def _as_index(self):
        """
        Get as_index parameter value.

        Returns
        -------
        bool
            Value of as_index parameter used to create DataFrameGroupBy object.
        """
        return self._kwargs.get("as_index")

    @property
    def _iter(self):
        """
        Construct a tuple of (group_id, DataFrame) tuples to allow iteration over groups.

        Returns
        -------
        generator
            Generator expression of GroupBy object broken down into tuples for iteration.
        """
        _groupby_method_not_implemented_error("_iter")

    def _wrap_aggregation(
        self,
        qc_method: Callable,
        numeric_only: bool = False,
        agg_args: List[Any] = None,
        agg_kwargs: Dict[str, Any] = None,
        is_result_dataframe: Optional[bool] = None,
        **kwargs: Any,
    ):
        """
        Perform common metadata transformations and apply groupby functions.

        Parameters
        ----------
        qc_method : callable
            The query compiler method to call.
        numeric_only : {None, True, False}, default: None
            Specifies whether to aggregate non numeric columns:
                - True: include only numeric columns (including categories that holds a numeric dtype)
                - False: include all columns
                - None: infer the parameter, ``False`` if there are no numeric types in the frame,
                  ``True`` otherwise.
        agg_args : list-like, optional
            Positional arguments to pass to the aggregation function.
        agg_kwargs : dict-like, optional
            Keyword arguments to pass to the aggregation function.
        is_result_dataframe: bool optional
            whether the result of aggregation is a dataframe or series. If None, is_result_dataframe will be
            False for SeriesGroupBy, and True for DataFrameGroupBy.
        **kwargs : dict
            Keyword arguments to pass to the specified query compiler's method.

        Returns
        -------
        DataFrame or Series
            Returns the same type as `self._df`.
        """
        agg_args = tuple() if agg_args is None else agg_args
        agg_kwargs = dict() if agg_kwargs is None else agg_kwargs

        is_series_groupby = self.ndim == 1
        if is_series_groupby:
            # when ndim is 1, it is SeriesGroupBy. SeriesGroupBy does not implement numeric_only
            # parameter even if it accepts the parameter, and the aggregation is handled the
            # same as numeric_only is False.
            if numeric_only and not is_numeric_dtype(self._query_compiler.dtypes[0]):
                # Pandas throws an NotImplementedError when the numeric_only is True, but the
                # series dtype is not numeric
                ErrorMessage.not_implemented(
                    "SeriesGroupBy does not implement numeric_only"
                )
            numeric_only = False

        if numeric_only is None:
            # according to pandas doc, before 1.5.3 customer can configure numeric_only as None,
            # which automatically drops the invalid columns. From 2.0.0, numeric_only as None will
            # not be allowed anymore.
            message = (
                "numeric_only=None is deprecated. In a future version, either specify numeric_only=True or False, "
                "or select only columns which should be valid for the function."
            )
            WarningMessage.single_warning(message)

        if is_result_dataframe is None:
            is_result_dataframe = not is_series_groupby
        result_type = pd.DataFrame if is_result_dataframe else pd.Series
        result = result_type(
            query_compiler=qc_method(
                self._query_compiler,
                by=self._by,
                axis=self._axis,
                groupby_kwargs=self._kwargs,
                agg_args=agg_args,
                agg_kwargs=agg_kwargs,
                numeric_only=numeric_only,
                is_series_groupby=is_series_groupby,
                **kwargs,
            )
        )
        return result

    def _check_index_name(self, result):
        """
        Check the result of groupby aggregation on the need of resetting index name.

        Parameters
        ----------
        result : DataFrame
            Group by aggregation result.

        Returns
        -------
        DataFrame
        """
        if self._by is not None:
            # pandas does not name the index for this case
            result._query_compiler.set_index_name(None)
        return result


@_inherit_docstrings(pandas.core.groupby.SeriesGroupBy)
class SeriesGroupBy(DataFrameGroupBy):
    _pandas_class = pandas.core.groupby.SeriesGroupBy

    @property
    def ndim(self):
        """
        Return 1.

        Returns
        -------
        int
            Returns 1.

        Notes
        -----
        Deprecated and removed in pandas and will be likely removed in Modin.
        """
        return 1  # ndim is always 1 for Series

    @property
    def _iter(self):
        """
        Construct a tuple of (group_id, Series) tuples to allow iteration over groups.

        Returns
        -------
        generator
            Generator expression of GroupBy object broken down into tuples for iteration.
        """
        _groupby_method_not_implemented_error("_iter")

    @property
    def is_monotonic_decreasing(self):
        _groupby_method_not_implemented_error("is_monotonic_decreasing")

    @property
    def is_monotonic_increasing(self):
        _groupby_method_not_implemented_error("is_monotonic_increasing")

    _agg_series_examples_doc = dedent(
        """
    Examples
    --------
    >>> s = pd.Series([1, 2, 3, 4], index=pd.Index([1, 2, 1, 2]))

    >>> s
    1    1
    2    2
    1    3
    2    4
    dtype: int8

    >>> s.groupby(level=0).agg('min')
    1    1
    2    2
    dtype: int8

    >>> s.groupby(level=0).agg(['min', 'max'])
       min  max
    1    1    3
    2    2    4
    """
    )

    @doc(_agg_template, examples=_agg_series_examples_doc, klass="SnowparkPandasSeries")
    def aggregate(
        self,
        func: Optional[AggFuncType] = None,
        *args: Any,
        engine: Optional[Literal["cython", "numba"]] = None,
        engine_kwargs: Optional[Dict[str, bool]] = None,
        **kwargs: Any,
    ):
        if is_dict_like(func):
            raise SpecificationError(
                "Value for func argument in dict format is not allowed for SeriesGroupBy."
            )

        return super().aggregate(
            func, *args, engine=engine, engine_kwargs=engine_kwargs, **kwargs
        )

    agg = aggregate

    def nlargest(self, n=5, keep="first"):
        _groupby_method_not_implemented_error("nlargest")

    def nsmallest(self, n=5, keep="first"):
        _groupby_method_not_implemented_error("nsmallest")

    def unique(self):
        _groupby_method_not_implemented_error("unique")


def validate_groupby_args(
    by: Any,
    level: Optional[IndexLabel],
    squeeze: bool,
    observed: bool,
) -> None:
    """
    Common validation and checks for the groupby arguments that are used by both SeriesGroupBy
    and DataFrameGroupBy.

    Raises:
        TypeError if native pandas series is used as by item, or if both level and by are None
    Warns:
        If squeeze is configured that this is a parameter going to be deprecated in 2.0
        If observed is True, this parameter is ignored because CategoryDType is not supported with Snowpark Pandas API
    """
    # check if pandas.Series is used as by item, no native pandas series or dataframe
    # object is allowed.
    raise_if_native_pandas_objects(by)
    if not isinstance(by, Series) and is_list_like(by):
        for o in by:
            raise_if_native_pandas_objects(o)

    # the squeeze parameter tries to reduce the result dimension if possible, such as reduce
    # dataframe with single row to series. For example: with original dataframe
    #   A	B
    # 0	0	0
    # 1	1	0
    # 2	2	0
    # once call df.groupby('B', squeeze=True).apply(max), the result becomes a series like following
    # B
    # 0  A    6
    #    B    0
    if squeeze is not no_default:
        WarningMessage.ignored_argument(
            operation="groupby",
            argument="squeeze",
            message="The `squeeze` parameter is ignored in Snowpark Pandas API since it will be deprecated in Pandas' "
            "future version.",
        )

    if level is None and by is None:
        raise TypeError("You have to supply one of 'by' and 'level'")

    if observed:
        WarningMessage.ignored_argument(
            operation="groupby",
            argument="observed",
            message="CategoricalDType is not yet supported with Snowpark Pandas API, the observed parameter is ignored.",
        )
