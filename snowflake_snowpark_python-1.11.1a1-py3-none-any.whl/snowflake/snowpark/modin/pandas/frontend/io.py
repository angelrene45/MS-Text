#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#

# Licensed to Modin Development Team under one or more contributor license agreements.
# See the NOTICE file distributed with this work for additional information regarding
# copyright ownership.  The Modin Development Team licenses this file to you under the
# Apache License, Version 2.0 (the "License"); you may not use this file except in
# compliance with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under
# the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific language
# governing permissions and limitations under the License.

# Code in this file may constitute partial or total reimplementation, or modification of
# existing code originally distributed by the Modin project, under the Apache License,
# Version 2.0.

"""
Implement I/O public API as pandas does.

Almost all docstrings for public and magic methods should be inherited from pandas
for better maintability.
Manually add documentation for methods which are not presented in pandas.
"""

from __future__ import annotations

import csv
import inspect
import pathlib
import pickle
from collections import OrderedDict
from typing import (
    IO,
    Any,
    AnyStr,
    Callable,
    Hashable,
    Iterable,
    Iterator,
    Literal,
    Pattern,
    Sequence,
)

import pandas
from pandas._libs.lib import NoDefault, no_default
from pandas._typing import (
    CompressionOptions,
    ConvertersArg,
    CSVEngine,
    DtypeArg,
    FilePath,
    IndexLabel,
    IntStrT,
    ParseDatesArg,
    ReadBuffer,
    ReadCsvBuffer,
    StorageOptions,
    XMLParsers,
)
from pandas.core.dtypes.common import is_list_like
from pandas.io.parsers import TextFileReader
from pandas.io.parsers.readers import _c_parser_defaults

from snowflake.snowpark.dataframe import DataFrame as SnowparkDataFrame

# add this line to enable doc tests to run
from snowflake.snowpark.modin import pandas as pd  # noqa: F401
from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
    FactoryDispatcher,
)

# use these import statements here to use original Modin DataFrame/Series
# from .dataframe import DataFrame
# from .series import Series
# yet, we want to identify as Snowpark Pandas API
from snowflake.snowpark.modin.pandas.frontend.snow_dataframe import (
    SnowparkPandasDataFrame as DataFrame,
)
from snowflake.snowpark.modin.pandas.frontend.snow_series import (
    SnowparkPandasSeries as Series,
)
from snowflake.snowpark.modin.pandas.translation._internal.telemetry import (
    snowpark_pandas_telemetry_standalone_function_decorator,
)
from snowflake.snowpark.modin.pandas.translation.compiler.snowflake_query_compiler import (
    SnowflakeQueryCompiler,
)
from snowflake.snowpark.modin.pandas.utils.core_utils import (
    error_not_implemented_parameter,
    should_parse_header,
    translate_pandas_default,
    warn_not_supported_parameter,
)
from snowflake.snowpark.modin.pandas.utils.error_message import ErrorMessage


def _read(**kwargs):
    """
    Read csv file from local disk.

    Parameters
    ----------
    **kwargs : dict
        Keyword arguments in pandas.read_csv.

    Returns
    -------
    modin.pandas.DataFrame
    """

    squeeze = kwargs.pop("squeeze", False)

    # the following are basically dispatches always to an IO class
    # links: https://github.com/modin-project/modin/blob/843b0cf02df9ff76f32cc75749203762633ffb27/modin/core/execution/dispatching/factories/factories.py
    # and check the PandasOnUnidistFactory
    pd_obj = FactoryDispatcher.read_csv(**kwargs)
    # This happens when `read_csv` returns a TextFileReader object for iterating through
    if isinstance(pd_obj, TextFileReader):
        reader = pd_obj.read
        pd_obj.read = lambda *args, **kwargs: DataFrame(
            query_compiler=reader(*args, **kwargs)
        )
        return pd_obj
    result = DataFrame(query_compiler=pd_obj)
    if squeeze:
        return result.squeeze(axis=1)
    return result


# TODO: SNOW-944596: implement read_xml using Snowflake COPY INTO SQL command
# @_inherit_docstrings(pandas.read_xml, apilink="pandas.read_xml")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_xml(
    path_or_buffer: FilePath | ReadBuffer[bytes] | ReadBuffer[str],
    xpath: str = "./*",
    namespaces: dict[str, str] | None = None,
    elems_only: bool = False,
    attrs_only: bool = False,
    names: Sequence[str] | None = None,
    dtype: DtypeArg | None = None,
    converters: ConvertersArg | None = None,
    parse_dates: ParseDatesArg | None = None,
    encoding: str | None = "utf-8",
    parser: XMLParsers = "lxml",
    stylesheet: FilePath | ReadBuffer[bytes] | ReadBuffer[str] | None = None,
    iterparse: dict[str, list[str]] | None = None,
    compression: CompressionOptions = "infer",
    storage_options: StorageOptions = None,
) -> DataFrame:
    ErrorMessage.not_implemented()

    return DataFrame(
        pandas.read_xml(
            path_or_buffer,
            xpath=xpath,
            namespaces=namespaces,
            elems_only=elems_only,
            attrs_only=attrs_only,
            names=names,
            dtype=dtype,
            converters=converters,
            parse_dates=parse_dates,
            encoding=encoding,
            parser=parser,
            stylesheet=stylesheet,
            iterparse=iterparse,
            compression=compression,
            storage_options=storage_options,
        )
    )


@snowpark_pandas_telemetry_standalone_function_decorator
def read_snowflake(
    name: str | Iterable[str],
    index_col: str | list[str] | None = None,
    columns: list[str] | None = None,
) -> DataFrame:
    """
    Read a Snowflake table to a Snowpark Pandas DataFrame.

    Args:
        name: A table name or fully-qualified object identifier. It follows the same syntax in
            https://docs.snowflake.com/developer-guide/snowpark/reference/python/api/snowflake.snowpark.Session.table.html
        index_col: A column name or a list of column names to use as index.
        columns: A list of column names to select from the table. If not specified, select all columns.

    See also:
        - :func:`to_snowflake <snowflake.snowpark.modin.pandas.frontend.io.to_snowflake>`

    Notes:
        Transformations applied to the returned Snowpark Pandas Dataframe do not affect the underlying Snowfalke table
        (or object). Use
        - :func:`snowflake.snowpark.modin.pandas.to_snowpark <snowflake.snowpark.modin.pandas.frontend.io.to_snowflake>`
        to write the Snowpark Pandas DataFrame back to a Snowpark table.

    Examples:

        Let's create a Snowflake table using SQL first for demonstrating the behavior of
        ``index_col`` and ``columns``:

        >>> table_name = "RESULT"
        >>> create_result = session.sql(f"create temp table {table_name} (A int, B int, C int)").collect()
        >>> insert_result = session.sql(f"insert into {table_name} values(1, 2, 3)").collect()
        >>> session.table(table_name).show()
        -------------------
        |"A"  |"B"  |"C"  |
        -------------------
        |1    |2    |3    |
        -------------------
        <BLANKLINE>

        - When ``index_col`` and ``columns`` are both not specified, a Snowpark Pandas DataFrame
          will have a default index from 0 to n-1, where n is the number of rows in the table,
          and have all columns in the Snowflake table as data columns.

          >>> import snowflake.snowpark.modin.pandas as pd
          >>> pd.read_snowflake(table_name)   # doctest: +NORMALIZE_WHITESPACE
             A  B  C
          0  1  2  3

        - When ``index_col`` is specified and ``columns`` is not specified, ``index_col``
          will be used as index columns in Snowpark Pandas DataFrame and rest of columns in the
          Snowflake table will be data columns. Note that duplication is allowed and
          duplicate pandas labels are maintained.

          >>> pd.read_snowflake(table_name, index_col="A")   # doctest: +NORMALIZE_WHITESPACE
             B  C
          A
          1  2  3

          >>> pd.read_snowflake(table_name, index_col=["A", "B"])   # doctest: +NORMALIZE_WHITESPACE
               C
          A B
          1 2  3

          >>> pd.read_snowflake(table_name, index_col=["A", "A", "B"])  # doctest: +NORMALIZE_WHITESPACE
                 C
          A A B
          1 1 2  3

        - When ``index_col`` is not specified and ``columns`` is specified, a Snowpark Pandas DataFrame
          will have a default index from 0 to n-1 and ``columns`` as data columns.

          >>> pd.read_snowflake(table_name, columns=["A"])  # doctest: +NORMALIZE_WHITESPACE
             A
          0  1

          >>> pd.read_snowflake(table_name, columns=["A", "B"])  # doctest: +NORMALIZE_WHITESPACE
             A  B
          0  1  2

          >>> pd.read_snowflake(table_name, columns=["A", "A", "B"])  # doctest: +NORMALIZE_WHITESPACE
             A  A  B
          0  1  1  2

        - When ``index_col`` and ``columns`` are specified, ``index_col``
          will be used as index columns and ``columns`` will be used as data columns.
          ``index_col`` doesn't need to be a part of ``columns``.

          >>> pd.read_snowflake(table_name, index_col=["A"], columns=["B", "C"])  # doctest: +NORMALIZE_WHITESPACE
             B  C
          A
          1  2  3

          >>> pd.read_snowflake(table_name, index_col=["A", "B"], columns=["A", "B"])  # doctest: +NORMALIZE_WHITESPACE
               A  B
          A B
          1 2  1  2

     Note:
        The names/labels used for the parameters of the Snowpark Pandas IO functions such as index_col, columns are Normalized
        Snowflake Identifiers (The Snowflake stored and resolved Identifiers). The Normalized Snowflake Identifiers
        are also used as default Pandas label after constructing a Snowpark Pandas DataFrame out of the Snowflake
        table or Snowpark DataFrame. Following are the rules about how Normalized Snowflake Identifiers are generated:

            - When the column identifier in Snowflake/Snowpark DataFrame is an unquoted object identifier,
              it is stored and resolved as uppercase characters (e.g. `id` is stored and resolved as `ID`),
              the valid input is an uppercase string. For example, for the column identifier ``A`` or ``a``, the
              stored and resolved identifier is ``A``, and the valid input for the parameters can only be ``A``,
              and the corresponding Pandas label in Snowpark Pandas DataFrame is ``A``. ``a`` and ``"A"`` are both invalid.

            - When the column identifier in Snowflake/Snowpark DataFrame is a quoted object identifier, the case
              of the identifier is preserved when storing and resolving the identifier
              (e.g. `"id"` is stored and resolved as `id`), the valid input is case-sensitive string.
              For example, for the column identifier ``"a"``, the valid input for the parameter can only be
              ``a``, and the corresponding Pandas label in Snowpark Pandas DataFrame is ``a``.
              ``"a"`` is invalid. For the column identifier ``"A"``, the valid input for the parameter can only be
              ``A``, and the corresponding Pandas label in Snowpark Pandas DataFrame is ``A``, and``"A"`` is invalid.

        See `Snowflake Identifier Requirements <https://docs.snowflake.com/en/sql-reference/identifiers-syntax>`_ for
        more details about Snowflake Identifiers.

        To see what are the Normalized Snowflake Identifiers for columns of a Snowpark DataFrame, you can call
        dataframe.show() to see all column names, which is the Normalized identifier.

        To see what are the Normalized Snowflake Identifiers for columns of a Snowflake table, you can call SQL query
        `SELECT * FROM TABLE` or `DESCRIBE TABLE` to see the column names.
    """
    _, _, _, f_locals = inspect.getargvalues(inspect.currentframe())
    # mangle_dupe_cols has no effect starting in pandas 1.5. Exclude it from
    # kwargs so pandas doesn't spuriously warn people not to use it.
    f_locals.pop("mangle_dupe_cols", None)

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(
        query_compiler=FactoryDispatcher.read_snowflake(
            name, index_col=index_col, columns=columns
        )
    )


def _snowpark_pandas_obj_check(obj: DataFrame | Series):
    if not isinstance(obj, (DataFrame, Series)):
        raise TypeError("obj must be a Snowpark Pandas DataFrame or Series")


@snowpark_pandas_telemetry_standalone_function_decorator
def to_pandas(
    obj: DataFrame | Series,
    *,
    statement_params: dict[str, str] | None = None,
    **kwargs: Any,
) -> DataFrame | Series:
    """
    Convert Snowpark Pandas DataFrame or Series to Pandas DataFrame or Series

    Args:
        obj: The object to be converted to native Pandas. It must be either a Snowpark Pandas DataFrame or Series
        statement_params: Dictionary of statement level parameters to be set while executing this action.

    Returns:
        Pandas DataFrame or Series

    See also:
        - :func:`DataFrame.to_pandas <snowflake.snowpark.modin.pandas.DataFrame.to_pandas>`
        - :func:`Series.to_pandas <snowflake.snowpark.modin.pandas.Series.to_pandas>`

    Examples:

        >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
        ...                               'Parrot', 'Parrot'],
        ...                    'Max Speed': [380., 370., 24., 26.]})
        >>> pd.to_pandas(df)
           Animal  Max Speed
        0  Falcon      380.0
        1  Falcon      370.0
        2  Parrot       24.0
        3  Parrot       26.0

        >>> pd.to_pandas(df['Animal'])
        0    Falcon
        1    Falcon
        2    Parrot
        3    Parrot
        Name: Animal, dtype: object
    """
    _snowpark_pandas_obj_check(obj)
    return obj.to_pandas(statement_params=statement_params, *kwargs)


@snowpark_pandas_telemetry_standalone_function_decorator
def to_snowflake(
    obj: DataFrame | Series,
    name: str | Iterable[str],
    if_exists: Literal["fail", "replace", "append"] | None = "fail",
    index: bool = True,
    index_label: IndexLabel | None = None,
    table_type: Literal["", "temp", "temporary", "transient"] = "",
) -> None:
    """
    Save the Snowpark Pandas DataFrame or Series as a Snowflake table.

    Args:
        obj: Either a Snowpark Pandas DataFrame or Series
        name:
            Name of the SQL table or fully-qualified object identifier
        if_exists:
            How to behave if table already exists. default 'fail'
            - fail: Raise ValueError.
            - replace: Drop the table before inserting new values.
            - append: Insert new values to the existing table. The order of insertion is not guaranteed.
        index: default True
            If true, save DataFrame index columns as table columns.
        index_label:
            Column label for index column(s). If None is given (default) and index is True,
            then the index names are used. A sequence should be given if the DataFrame uses MultiIndex.
        table_type:
            The table type of table to be created. The supported values are: ``temp``, ``temporary``,
            and ``transient``. An empty string means to create a permanent table. Learn more about table
            types `here <https://docs.snowflake.com/en/user-guide/tables-temp-transient.html>`_.

    See also:
        - :func:`DataFrame.to_snowflake <snowflake.snowpark.modin.pandas.DataFrame.to_snowflake>`
        - :func:`Series.to_snowflake <snowflake.snowpark.modin.pandas.Series.to_snowflake>`
        - :func:`read_snowflake <snowflake.snowpark.modin.pandas.frontend.io.read_snowflake>`
    """
    _snowpark_pandas_obj_check(obj)

    return obj._query_compiler.to_snowflake(
        name, if_exists, index, index_label, table_type
    )


@snowpark_pandas_telemetry_standalone_function_decorator
def to_snowpark(
    obj: DataFrame | Series, index: bool = True, index_label: IndexLabel | None = None
) -> SnowparkDataFrame:
    """
    Convert the Snowpark Pandas DataFrame or Series to a Snowpark DataFrame.
    Note that once converted to a Snowpark DataFrame, no ordering information will be preserved. You can call
    reset_index to generate a default index column that is the same as the row position before the call to_snowpark.

    Args:
        obj: The object to be converted to Snowpark DataFrame. It must be either a Snowpark Pandas DataFrame or Series
        index: bool, default True.
            Whether to keep the index columns in the result Snowpark DataFrame. If True, the index columns
            will be the first set of columns. Otherwise, no index column will be included in the final Snowpark
            DataFrame.
        index_label: IndexLabel, default None.
            Column label(s) to use for the index column(s). If None is given (default) and index is True,
            then the original index column labels are used. A sequence should be given if the DataFrame uses
            MultiIndex, and the length of the given sequence should be the same as the number of index columns.

    Returns:
        :class:`~snowflake.snowpark.dataframe.DataFrame`
            A Snowpark DataFrame contains the index columns if index=True and all data columns of the Snowpark Pandas
            DataFrame. The identifier for the Snowpark DataFrame will be the normalized quoted identifier with
            the same name as the Pandas label.

    Raises:
         ValueError if duplicated labels occur among the index and data columns.
         ValueError if the label used for a index or data column is None.

    See also:
        - :func:`Snowpark.DataFrame.to_snowpark_pandas <snowflake.snowpark.DataFrame.to_snowpark_pandas>`
        - :func:`DataFrame.to_snowpark <snowflake.snowpark.modin.pandas.DataFrame.to_snowpark>`
        - :func:`Series.to_snowpark <snowflake.snowpark.modin.pandas.Series.to_snowpark>`

    Note:
        The labels of the Snowpark Pandas DataFrame or index_label provided will be used as Normalized Snowflake
        Identifiers of the Snowpark DataFrame.
        For details about Normalized Snowflake Identifiers, please refer to the Note in :func:`~snowflake.snowpark.modin.pandas.frontend.io.read_snowflake`

    Examples::

        >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
        ...                               'Parrot', 'Parrot'],
        ...                    'Max Speed': [380., 370., 24., 26.]})
        >>> df
           Animal  Max Speed
        0  Falcon      380.0
        1  Falcon      370.0
        2  Parrot       24.0
        3  Parrot       26.0
        >>> snowpark_df = pd.to_snowpark(df, index_label='Order')
        >>> snowpark_df.order_by('"Max Speed"').show()
        ------------------------------------
        |"Order"  |"Animal"  |"Max Speed"  |
        ------------------------------------
        |2        |Parrot    |24.0         |
        |3        |Parrot    |26.0         |
        |1        |Falcon    |370.0        |
        |0        |Falcon    |380.0        |
        ------------------------------------
        <BLANKLINE>
        >>> snowpark_df = pd.to_snowpark(df, index=False)
        >>> snowpark_df.order_by('"Max Speed"').show()
        --------------------------
        |"Animal"  |"Max Speed"  |
        --------------------------
        |Parrot    |24.0         |
        |Parrot    |26.0         |
        |Falcon    |370.0        |
        |Falcon    |380.0        |
        --------------------------
        <BLANKLINE>
        >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
        ...                               'Parrot', 'Parrot'],
        ...                    'Max Speed': [380., 370., 24., 26.]}, index=pd.Index([3, 5, 6, 7], name="id"))
        >>> df      # doctest: +NORMALIZE_WHITESPACE
            Animal  Max Speed
        id
        3  Falcon      380.0
        5  Falcon      370.0
        6  Parrot       24.0
        7  Parrot       26.0
        >>> snowpark_df = pd.to_snowpark(df)
        >>> snowpark_df.order_by('"id"').show()
        ---------------------------------
        |"id"  |"Animal"  |"Max Speed"  |
        ---------------------------------
        |3     |Falcon    |380.0        |
        |5     |Falcon    |370.0        |
        |6     |Parrot    |24.0         |
        |7     |Parrot    |26.0         |
        ---------------------------------
        <BLANKLINE>

        MultiIndex usage

        >>> df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
        ...                               'Parrot', 'Parrot'],
        ...                    'Max Speed': [380., 370., 24., 26.]},
        ...                    index=pd.MultiIndex.from_tuples([('bar', 'one'), ('foo', 'one'), ('bar', 'two'), ('foo', 'three')], names=['first', 'second']))
        >>> df      # doctest: +NORMALIZE_WHITESPACE
                        Animal  Max Speed
        first second
        bar   one     Falcon      380.0
        foo   one     Falcon      370.0
        bar   two     Parrot       24.0
        foo   three   Parrot       26.0
        >>> snowpark_df = pd.to_snowpark(df, index=True, index_label=['A', 'B'])
        >>> snowpark_df.order_by('"A"', '"B"').show()
        ----------------------------------------
        |"A"  |"B"    |"Animal"  |"Max Speed"  |
        ----------------------------------------
        |bar  |one    |Falcon    |380.0        |
        |bar  |two    |Parrot    |24.0         |
        |foo  |one    |Falcon    |370.0        |
        |foo  |three  |Parrot    |26.0         |
        ----------------------------------------
        <BLANKLINE>
        >>> snowpark_df = pd.to_snowpark(df, index=False)
        >>> snowpark_df.order_by('"Max Speed"').show()
        --------------------------
        |"Animal"  |"Max Speed"  |
        --------------------------
        |Parrot    |24.0         |
        |Parrot    |26.0         |
        |Falcon    |370.0        |
        |Falcon    |380.0        |
        --------------------------
        <BLANKLINE>
        >>> snowpark_df = pd.to_snowpark(df["Animal"], index=False)
        >>> snowpark_df.order_by('"Animal"').show()
        ------------
        |"Animal"  |
        ------------
        |Falcon    |
        |Falcon    |
        |Parrot    |
        |Parrot    |
        ------------
        <BLANKLINE>
    """
    _snowpark_pandas_obj_check(obj)

    return obj._query_compiler.to_snowpark(index, index_label)


@snowpark_pandas_telemetry_standalone_function_decorator
def read_csv(
    filepath_or_buffer: FilePath,
    sep: str | NoDefault | None = no_default,
    delimiter: str | None = None,
    header: int | Sequence[int] | Literal["infer"] | None = "infer",
    names: Sequence[Hashable] | None | NoDefault = no_default,
    index_col: IndexLabel | Literal[False] | None = None,
    usecols: list[Hashable] | Callable | None = None,
    squeeze: bool | None = None,
    prefix: str | NoDefault.no_default = None,
    mangle_dupe_cols: bool | None = None,
    dtype: DtypeArg | None = None,
    engine: CSVEngine | None = None,
    converters: dict[Hashable, Callable] | None = None,
    true_values: list[Any] | None = None,
    false_values: list[Any] | None = None,
    skip_initial_space: bool | None = None,
    skiprows: int | None = 0,
    skipfooter: int | None = None,
    nrows: int | None = None,
    na_values: Sequence[Hashable] | None = None,
    keep_default_na: bool | None = None,
    na_filter: bool | None = None,
    verbose: bool | None = None,
    skip_blank_lines: bool | None = None,
    parse_dates: None
    | bool
    | Sequence[int]
    | Sequence[Sequence[int]]
    | dict[str, Sequence[int]] = None,
    infer_datetime_format: bool | None = None,
    keep_date_col: bool | None = None,
    date_parser: Callable | None = None,
    dayfirst: bool | None = None,
    cache_dates: bool | None = None,
    iterator: bool = None,
    chunksize: int | None = None,
    compression: Literal[
        "infer", "gzip", "bz2", "brotli", "zstd", "deflate", "raw_deflate", "none"
    ] = "infer",
    thousands: str | None = None,
    decimal: str | None = None,
    lineterminator: str | None = None,
    quotechar: str = '"',
    quoting: int | None = None,
    doublequote: bool = None,
    escapechar: str | None = None,
    comment: str | None = None,
    encoding: str | None = None,
    encoding_errors: str | None = None,
    dialect: str | csv.Dialect | None = None,
    error_bad_lines: bool | None = None,
    warn_bad_lines: bool | None = None,
    on_bad_lines: str = None,
    delim_whitespace: bool | None = None,
    low_memory: bool | None = None,
    memory_map: bool | None = None,
    float_precision: Literal["high", "legacy"] | None = None,
    storage_options: StorageOptions = None,
) -> DataFrame:
    """
    Read csv file(s) into a Snowpark Pandas DataFrame. This API can read
    files stored locally or on a Snowflake stage.

    Snowpark Pandas stages files (unless they're already staged)
    and then reads them using Snowflake's CSV reader.

    Parameters
    ----------
    filepath_or_buffer : str
        Local file location or staged file location to read from. Staged file locations
        starts with a '@' symbol. To read a local file location with a name starting with `@`,
        escape it using a `\\@`. For more info on staged files, `read here
        <https://docs.snowflake.com/en/sql-reference/sql/create-stage>`_.
    sep : str, default ','
        Delimiter to use to separate fields in an input file. Delimiters can be
        multiple characters in Snowpark Pandas.
    delimiter : str, default ','
        Alias for sep.
    header : int, list of int, None, default 'infer'
        Row number(s) to use as the column names, and the start of the
        data.  Default behavior is to infer the column names: if no names
        are passed the behavior is identical to ``header=0`` and column
        names are inferred from the first line of the file, if column
        names are passed explicitly then the behavior is identical to
        ``header=None``. Explicitly pass ``header=0`` to be able to
        replace existing names. If a non-zero integer or a list of integers is passed,
        a ``NotImplementedError`` will be raised.
    names : array-like, optional
        List of column names to use. If the file contains a header row,
        then you should explicitly pass ``header=0`` to override the column names.
        Duplicates in this list are not allowed.
    index_col: int, str, sequence of int / str, or False, optional, default ``None``
        Column(s) to use as the row labels of the ``DataFrame``, either given as
        string name or column index. If a sequence of int / str is given, a
        MultiIndex is used.

        Note: ``index_col=False`` can be used to force pandas to *not* use the first
        column as the index, e.g. when you have a malformed file with delimiters at
        the end of each line.
    usecols : list-like or callable, optional
        Return a subset of the columns. If list-like, all elements must either
        be positional (i.e. integer indices into the document columns) or strings
        that correspond to column names provided either by the user in `names` or
        inferred from the document header row(s). If ``names`` are given, the document
        header row(s) are not taken into account. For example, a valid list-like
        `usecols` parameter would be ``[0, 1, 2]`` or ``['foo', 'bar', 'baz']``.
        Element order is ignored, so ``usecols=[0, 1]`` is the same as ``[1, 0]``.
        To instantiate a DataFrame from ``data`` with element order preserved use
        ``pd.read_csv(data, usecols=['foo', 'bar'])[['foo', 'bar']]`` for columns
        in ``['foo', 'bar']`` order or
        ``pd.read_csv(data, usecols=['foo', 'bar'])[['bar', 'foo']]``
        for ``['bar', 'foo']`` order.

        If callable, the callable function will be evaluated against the column
        names, returning names where the callable function evaluates to True. An
        example of a valid callable argument would be ``lambda x: x.upper() in
        ['AAA', 'BBB', 'DDD']``.
    dtype : Type name or dict of column -> type, optional
        Data type for data or columns. E.g. {{'a': np.float64, 'b': np.int32,
        'c': 'Int64'}}
        Use `str` or `object` together with suitable `na_values` settings
        to preserve and not interpret dtype.
        If converters are specified, they will be applied INSTEAD
        of dtype conversion.
    squeeze : bool, default False
        This parameter is not supported and will raise an error.
    prefix : str, optional
        This parameter is not supported and will raise an error.
    mangle_dupe_cols : bool, default True
        This parameter is not supported and will raise an error.
    engine : {{'c', 'python', 'pyarrow'}}, optional
        This parameter is not supported and will raise an error.
    converters : dict, optional
       This parameter is not supported and will raise an error.
    true_values : list, optional
        This parameter is not supported and will raise an error.
    false_values : list, optional
        This parameter is not supported and will raise an error.
    skiprows: list-like, int or callable, optional
        Line numbers to skip (0-indexed) or number of lines to skip (int)
        at the start of the file.
    skipfooter : int, default 0
        This parameter is not supported and will raise an error.
    nrows : int, optional
        This parameter is not supported and will raise an error.
    na_values : scalar, str, list-like, or dict, optional
        Additional strings to recognize as NA/NaN.
    keep_default_na : bool, default True
       This parameter is not supported and will raise an error.
    na_filter : bool, default True
        This parameter is not supported and will raise an error.
    verbose : bool, default False
        This parameter is not supported and will raise an error.
    skip_blank_lines : bool, default True
        If True, skip over blank lines rather than interpreting as NaN values.
    parse_dates : bool or list of int or names or list of lists or dict, default False
        This parameter is not supported and will raise an error.
    infer_datetime_format : bool, default False
        This parameter is not supported and will raise an error.
    keep_date_col : bool, default False
        This parameter is not supported and will raise an error.s
    date_parser : function, optional
        This parameter is not supported and will raise an error.
    dayfirst : bool, default False
        This parameter is not supported and will raise an error.
    cache_dates : bool, default True
        This parameter is not supported and will raise an error.
    iterator : bool, default False
        This parameter is not supported and will raise an error.
    chunksize : int, optional
        This parameter is not supported and will raise an error.
    compression: str, default 'infer'
        String (constant) that specifies the current compression algorithm for the
        data files to be loaded. Snowflake uses this option to detect how already-compressed
        data files were compressed so that the compressed data in the files
        can be extracted for loading.
        `List of Snowflake standard compressions
        <https://docs.snowflake.com/en/sql-reference/sql/copy-into-table#format-type-options-formattypeoptions>`_ .
    thousands : str, optional
        This parameter is not supported and will raise an error.
    decimal : str, default '.'
        This parameter is not supported and will raise an error.
    lineterminator : str (length 1), optional
        This parameter is not supported and will raise an error.
    quotechar : str (length 1), optional
        The character used to denote the start and end of a quoted item. Quoted
        items can include the delimiter and it will be ignored.
    quoting : int or csv.QUOTE_* instance, default 0
        This parameter is not supported and will raise an error.
    doublequote : bool, default ``True``
        This parameter is not supported and will raise an error.
    escapechar : str (length 1), optional
        One-character string used to escape other characters.
    comment : str, optional
        This parameter is not supported and will raise an error.
    encoding : str, default 'utf-8'
        Encoding to use for UTF when reading/writing (ex. 'utf-8'). `List of Snowflake
        standard encodings <https://docs.snowflake.com/en/sql-reference/sql/copy-into-tables>`_ .
    encoding_errors : str, optional, default "strict"
        This parameter is not supported and will raise an error.
    dialect : str or csv.Dialect, optional
        This parameter is not supported and will raise an error.
    error_bad_lines : bool, optional, default ``None``
        This parameter is not supported and will raise an error.
    warn_bad_lines : bool, optional, default ``None``
        This parameter is not supported and will raise an error.
    on_bad_lines : {{'error', 'warn', 'skip'}} or callable, default 'error'
        This parameter is not supported and will raise an error.
    delim_whitespace : bool, default False
        This parameter is not supported and will raise an error.
    low_memory : bool, default True
        This parameter is not supported and will raise an error.
    memory_map : bool, default False
        This parameter is not supported and will raise an error.
    float_precision : str, optional
        This parameter is not supported and will raise an error.

    Returns
    -------
    SnowparkPandasDataFrame.

    Raises
    ------
    NotImplementedError if a parameter is not supported.

    Notes
    -----
    Both local files and files staged on Snowflake can be passed into
    ``filepath_or_buffer``. A single file or a folder that matches
    a set of files can be passed into ``filepath_or_buffer``. The order of rows in the
    dataframe may be different than the order of records in an input file. When reading
    multiple files, there is no deterministic order in which the files are read.

    Examples
    --------
    Read local csv file.

    >>> import csv
    >>> import tempfile
    >>> temp_dir = tempfile.TemporaryDirectory()
    >>> temp_dir_name = temp_dir.name
    >>> with open(f'{temp_dir_name}/data.csv', 'w') as f:
    ...     writer = csv.writer(f)
    ...     writer.writerows([['c1','c2','c3'], [1,2,3], [4,5,6], [7,8,9]])
    >>> import snowflake.snowpark.modin.pandas as pd
    >>> df = pd.read_csv(f'{temp_dir_name}/data.csv')
    >>> df
       c1  c2  c3
    0   1   2   3
    1   4   5   6
    2   7   8   9

    Read staged csv file.

    >>> _ = session.sql("create or replace temp stage mytempstage").collect()
    >>> _ = session.file.put(f'{temp_dir_name}/data.csv', '@mytempstage/myprefix')
    >>> df2 = pd.read_csv('@mytempstage/myprefix/data.csv')
    >>> df2
       c1  c2  c3
    0   1   2   3
    1   4   5   6
    2   7   8   9

    Read csv files from a local folder.

    >>> with open(f'{temp_dir_name}/data2.csv', 'w') as f:
    ...     writer = csv.writer(f)
    ...     writer.writerows([['c1','c2','c3'], [1,2,3], [4,5,6], [7,8,9]])
    >>> df3 = pd.read_csv(f'{temp_dir_name}')
    >>> df3
       c1  c2  c3
    0   1   2   3
    1   4   5   6
    2   7   8   9
    3   1   2   3
    4   4   5   6
    5   7   8   9

    Read csv files from a staged location.

    >>> _ = session.file.put(f'{temp_dir_name}/data2.csv', '@mytempstage/myprefix')
    >>> df4 = pd.read_csv('@mytempstage/myprefix')
    >>> df4
       c1  c2  c3
    0   1   2   3
    1   4   5   6
    2   7   8   9
    3   1   2   3
    4   4   5   6
    5   7   8   9

    >>> temp_dir.cleanup()
    """
    error_not_implemented_parameter("verbose", verbose)
    error_not_implemented_parameter("dayfirst", dayfirst)
    error_not_implemented_parameter("date_parser", date_parser)
    error_not_implemented_parameter("keep_date_col", keep_date_col)
    error_not_implemented_parameter("parse_dates", parse_dates)
    error_not_implemented_parameter("iterator", iterator)
    error_not_implemented_parameter("na_filter", na_filter)
    error_not_implemented_parameter("skipfooter", skipfooter)
    error_not_implemented_parameter("nrows", nrows)
    error_not_implemented_parameter("thousands", thousands)
    error_not_implemented_parameter("decimal", decimal)
    error_not_implemented_parameter("lineterminator", lineterminator)
    error_not_implemented_parameter("dialect", dialect)
    error_not_implemented_parameter("quoting", quoting)
    error_not_implemented_parameter("doublequote", doublequote)
    error_not_implemented_parameter("encoding_errors", encoding_errors)
    error_not_implemented_parameter("comment", comment)
    error_not_implemented_parameter("converters", converters)
    error_not_implemented_parameter("true_values", true_values)
    error_not_implemented_parameter("false_values", false_values)
    error_not_implemented_parameter("keep_default_na", keep_default_na)
    error_not_implemented_parameter("delim_whitespace", delim_whitespace)
    error_not_implemented_parameter("error_bad_lines", error_bad_lines)
    error_not_implemented_parameter("warn_bad_lines", warn_bad_lines)
    error_not_implemented_parameter("skip_initial_space", skip_initial_space)
    error_not_implemented_parameter("squeeze", squeeze)
    error_not_implemented_parameter("prefix", prefix)
    error_not_implemented_parameter("mangle_dupe_cols", mangle_dupe_cols)
    error_not_implemented_parameter("on_bad_lines", on_bad_lines)

    fn_name = "pd.read_csv"
    warn_not_supported_parameter("engine", engine, fn_name)
    warn_not_supported_parameter("cache_dates", cache_dates, fn_name)
    warn_not_supported_parameter(
        "infer_datetime_format", infer_datetime_format, fn_name
    )
    warn_not_supported_parameter("chunksize", chunksize, fn_name)
    warn_not_supported_parameter("memory_map", memory_map, fn_name)
    warn_not_supported_parameter("storage_options", storage_options, fn_name)
    warn_not_supported_parameter("low_memory", low_memory, fn_name)
    warn_not_supported_parameter("float_precision", float_precision, fn_name)

    if not isinstance(filepath_or_buffer, str):
        raise NotImplementedError(
            "filepath_or_buffer must be a path to a file or folder stored locally or on a Snowflake stage."
        )

    sep = translate_pandas_default(sep)
    names = translate_pandas_default(names)

    if sep is not None and delimiter is not None:
        raise ValueError("Specified a sep and a delimiter; you can only specify one.")

    if sep is None:
        sep = delimiter if delimiter is not None else ","

    # Distributed implementation is not supported for non-first row header or multi-index headers.
    if (
        isinstance(header, list)
        or (isinstance(header, int) and header != 0)
        or (skiprows != 0 and header is not None)
    ):
        error_not_implemented_parameter("header", header)

    parse_header = should_parse_header(header, names)

    if names is not None:
        if not is_list_like(names, allow_sets=False):
            raise ValueError("Names should be an ordered collection.")

        if len(set(names)) != len(names):
            raise ValueError("Duplicate names are not allowed.")

    if compression == "infer":
        compression = "auto"

    if usecols is not None:
        if not is_list_like(usecols) and not isinstance(usecols, Callable):
            raise ValueError(
                "'usecols' must either be list-like of all strings, all integers or a callable."
            )
        elif is_list_like(usecols):
            if len(usecols) == 0:
                return pd.DataFrame()

            usecols_is_all_int = all([isinstance(column, int) for column in usecols])
            usecols_is_all_str = all([isinstance(column, str) for column in usecols])

            if not usecols_is_all_int and not usecols_is_all_str:
                raise ValueError(
                    "'usecols' must either be list-like of all strings, all integers or a callable."
                )
            usecols = list(usecols)

        # Case where usecols is Callable is handled in SnowflakeQueryCompiler.from_file.

    if index_col:
        if isinstance(index_col, (int, str)):
            index_col = [index_col]
        elif isinstance(index_col, (tuple, list)):
            for column in index_col:
                if not isinstance(column, (int, str)):
                    raise TypeError(
                        f"list indices must be integers or slices, not {type(column).__name__}"
                    )
        else:
            raise TypeError(
                f"list indices must be integers or slices, not {type(index_col).__name__}"
            )

    return pd.DataFrame(
        query_compiler=SnowflakeQueryCompiler.from_file(
            "csv",
            filepath_or_buffer,
            field_delimiter=sep,
            skip_blank_lines=skip_blank_lines,
            null_if=na_values,
            compression=compression,
            escape=escapechar,
            skip_header=skiprows,
            encoding=encoding,
            field_optionally_enclosed_by=quotechar,
            parse_header=parse_header,
            names=names,
            index_col=index_col,
            usecols=usecols,
            dtype=dtype,
        )
    )


# @_inherit_docstrings(pandas.read_table, apilink="pandas.read_table")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_table(
    filepath_or_buffer: FilePath | ReadCsvBuffer[bytes] | ReadCsvBuffer[str],
    sep: str | None | NoDefault = no_default,
    delimiter: str | None | NoDefault = None,
    # Column and Index Locations and Names
    header: int | Sequence[int] | None | Literal["infer"] = "infer",
    names: Sequence[Hashable] | None | NoDefault = no_default,
    index_col: IndexLabel | Literal[False] | None = None,
    usecols=None,
    squeeze: bool | None = None,
    prefix: str | NoDefault = no_default,
    mangle_dupe_cols: bool = True,
    # General Parsing Configuration
    dtype: DtypeArg | None = None,
    engine: CSVEngine | None = None,
    converters=None,
    true_values=None,
    false_values=None,
    skipinitialspace: bool = False,
    skiprows=None,
    skipfooter: int = 0,
    nrows: int | None = None,
    # NA and Missing Data Handling
    na_values=None,
    keep_default_na: bool = True,
    na_filter: bool = True,
    verbose: bool = False,
    skip_blank_lines: bool = True,
    # Datetime Handling
    parse_dates=False,
    infer_datetime_format: bool = False,
    keep_date_col: bool = False,
    date_parser=None,
    dayfirst: bool = False,
    cache_dates: bool = True,
    # Iteration
    iterator: bool = False,
    chunksize: int | None = None,
    # Quoting, Compression, and File Format
    compression: CompressionOptions = "infer",
    thousands: str | None = None,
    decimal: str = ".",
    lineterminator: str | None = None,
    quotechar: str = '"',
    quoting: int = csv.QUOTE_MINIMAL,
    doublequote: bool = True,
    escapechar: str | None = None,
    comment: str | None = None,
    encoding: str | None = None,
    encoding_errors: str | None = "strict",
    dialect: str | csv.Dialect | None = None,
    # Error Handling
    error_bad_lines: bool | None = None,
    warn_bad_lines: bool | None = None,
    on_bad_lines=None,
    # Internal
    delim_whitespace=False,
    low_memory=_c_parser_defaults["low_memory"],
    memory_map: bool = False,
    float_precision: str | None = None,
    storage_options: StorageOptions = None,
) -> DataFrame | TextFileReader:
    ErrorMessage.not_implemented()
    # ISSUE #2408: parse parameter shared with pandas read_csv and read_table and update with provided args
    _pd_read_table_signature = {
        val.name for val in inspect.signature(pandas.read_table).parameters.values()
    }
    _, _, _, f_locals = inspect.getargvalues(inspect.currentframe())
    if f_locals.get("sep", sep) is False or f_locals.get("sep", sep) is no_default:
        f_locals["sep"] = "\t"
    # mangle_dupe_cols has no effect starting in pandas 1.5. Exclude it from
    # kwargs so pandas doesn't spuriously warn people not to use it.
    f_locals.pop("mangle_dupe_cols", None)
    kwargs = {k: v for k, v in f_locals.items() if k in _pd_read_table_signature}
    return _read(**kwargs)


@snowpark_pandas_telemetry_standalone_function_decorator
def read_parquet(
    path,
    engine: str | None = None,
    columns: list[str] | None = None,
    storage_options: StorageOptions = None,
    use_nullable_dtypes: bool | None = None,
    **kwargs,
) -> DataFrame:
    """
    Read parquet file(s) into a Snowpark Pandas DataFrame. This API can read
    files stored locally or on a Snowflake stage.

    Snowpark Pandas stages files (unless they're already staged)
    and then reads them using Snowflake's parquet reader.

    Parameters
    ----------
    path : str
        Local file location or staged file location to read from. Staged file locations
        starts with a '@' symbol. To read a local file location with a name starting with `@`,
        escape it using a `\\@`. For more info on staged files, `read here
        <https://docs.snowflake.com/en/sql-reference/sql/create-stage>`_.

    engine : {{'auto', 'pyarrow', 'fastparquet'}}, default 'auto'
        This parameter is not supported and will be ignored.

    storage_options : StorageOptions, default None
        This parameter is not supported and will be ignored.

    columns : list, default None
        If not None, only these columns will be read from the file.

    use_nullable_dtypes : bool, default False
        This parameter is not supported and will raise an error.

    **kwargs : Any, default None
        This parameter is not supported and will be ignored.

    Returns
    -------
    SnowparkPandasDataFrame.

    Raises
    ------
    NotImplementedError if a parameter is not supported.

    Notes
    -----
    Both local files and files staged on Snowflake can be passed into
    ``path``. A single file or a folder that matches
    a set of files can be passed into ``path``. The order of rows in the
    dataframe may be different from the order of records in an input file. When reading
    multiple files, there is no deterministic order in which the files are read.

    Examples
    --------

    Read local parquet file.

    >>> import pandas as native_pd
    >>> import tempfile
    >>> temp_dir = tempfile.TemporaryDirectory()
    >>> temp_dir_name = temp_dir.name

    >>> df = native_pd.DataFrame(
    ...     {"foo": range(3), "bar": range(5, 8)}
    ...    )
    >>> df
       foo  bar
    0    0    5
    1    1    6
    2    2    7
    >>> _ = df.to_parquet(f'{temp_dir_name}/snowpark-pandas.parquet')
    >>> restored_df = pd.read_parquet(f'{temp_dir_name}/snowpark-pandas.parquet')
    >>> restored_df
       foo  bar
    0    0    5
    1    1    6
    2    2    7
    >>> restored_bar = pd.read_parquet(f'{temp_dir_name}/snowpark-pandas.parquet', columns=["bar"])
    >>> restored_bar
       bar
    0    5
    1    6
    2    7

    Read staged parquet file.
    >>> _ = session.sql("create or replace temp stage mytempstage").collect()
    >>> _ = session.file.put(f'{temp_dir_name}/snowpark-pandas.parquet', '@mytempstage/myprefix')
    >>> df2 = pd.read_parquet('@mytempstage/myprefix/snowpark-pandas.parquet')
    >>> df2
       foo  bar
    0    0    5
    1    1    6
    2    2    7

    Read parquet files from a local folder.
    >>> _ = df.to_parquet(f'{temp_dir_name}/snowpark-pandas2.parquet')
    >>> df3 = pd.read_parquet(f'{temp_dir_name}')
    >>> df3
       foo  bar
    0    0    5
    1    1    6
    2    2    7
    3    0    5
    4    1    6
    5    2    7

    Read parquet files from a staged location.

    >>> _ = session.file.put(f'{temp_dir_name}/snowpark-pandas2.parquet', '@mytempstage/myprefix')
    >>> df3 = pd.read_parquet('@mytempstage/myprefix')
    >>> df3
       foo  bar
    0    0    5
    1    1    6
    2    2    7
    3    0    5
    4    1    6
    5    2    7
    """
    if not isinstance(path, str):
        raise NotImplementedError(
            "'path' must be a path to a file or folder stored locally or on a Snowflake stage."
        )

    error_not_implemented_parameter("use_nullable_dtypes", use_nullable_dtypes)

    fn_name = "pd.read_parquet"
    warn_not_supported_parameter("engine", engine, fn_name)
    warn_not_supported_parameter("storage_options", storage_options, fn_name)

    kwargs = kwargs if kwargs else None
    warn_not_supported_parameter("parquet_kwargs", kwargs, fn_name)

    if columns is not None:
        if not isinstance(columns, list):
            raise ValueError("'columns' must either be list of all strings.")

        columns_is_all_str = all([isinstance(column, str) for column in columns])

        if not columns_is_all_str:
            raise ValueError("'columns' must either be list of all strings.")

    return pd.DataFrame(
        query_compiler=SnowflakeQueryCompiler.from_file(
            "parquet", path, usecols=columns
        )
    )


@snowpark_pandas_telemetry_standalone_function_decorator
def read_json(
    path_or_buf: FilePath,
    orient: str | None = None,
    typ: Literal["frame", "series"] | None = None,
    dtype: DtypeArg | None = None,
    convert_axes=None,
    convert_dates: bool | list[str] = None,
    keep_default_dates: bool | None = None,
    numpy: bool | None = None,
    precise_float: bool | None = None,
    date_unit: str | None = None,
    encoding: str | None = None,
    encoding_errors: str | None = None,
    lines: bool | None = None,
    chunksize: int | None = None,
    compression: Literal[
        "infer", "gzip", "bz2", "brotli", "zstd", "deflate", "raw_deflate", "none"
    ] = "infer",
    nrows: int | None = None,
    storage_options: StorageOptions = None,
) -> DataFrame:
    """
    Read new-line delimited json file(s) into a Snowpark Pandas DataFrame. This API can read
    files stored locally or on a Snowflake stage.

    Snowpark Pandas first stages files (unless they're already staged)
    and then reads them using Snowflake's JSON reader.

    Parameters
    ----------
    path_or_buf : str
        Local file location or staged file location to read from. Staged file locations
        starts with a '@' symbol. To read a local file location with a name starting with `@`,
        escape it using a `\\@`. For more info on staged files, `read here
        <https://docs.snowflake.com/en/sql-reference/sql/create-stage>`_.

    orient : str
        This parameter is not supported and will raise an error.

    typ : {{'frame', 'series'}}, default 'frame'
        This parameter is not supported and will raise an error.

    dtype : bool or dict, default None
        This parameter is not supported and will raise an error.

    convert_axes : bool, default None
        This parameter is not supported and will raise an error.

    convert_dates : bool or list of str, default True
        This parameter is not supported and will raise an error.

    keep_default_dates : bool, default True
        This parameter is not supported and will raise an error.

    numpy : bool, default False
        This parameter is not supported and will be ignored.

    precise_float : bool, default False
        This parameter is not supported and will be ignored.

    date_unit : str, default None
        This parameter is not supported and will raise an error.

    encoding : str, default is 'utf-8'
        Encoding to use for UTF when reading/writing (ex. 'utf-8'). `List of Snowflake
        standard encodings <https://docs.snowflake.com/en/sql-reference/sql/copy-into-tables>`_ .

    encoding_errors : str, optional, default "strict"
        This parameter is not supported and will raise an error.

    lines : bool, default False
        This parameter is not supported and will raise an error.

    chunksize : int, optional
        This parameter is not supported and will raise an error.

    compression : str, default 'infer'
        String (constant) that specifies the current compression algorithm for the
        data files to be loaded. Snowflake uses this option to detect how already-compressed
        data files were compressed so that the compressed data in the files
        can be extracted for loading.
        `List of Snowflake standard compressions
        <https://docs.snowflake.com/en/sql-reference/sql/copy-into-table#format-type-options-formattypeoptions>`_ .

    nrows : int, optional
        This parameter is not supported and will raise an error.

    storage_options : dict, optional
        This parameter is not supported and will be ignored.

    Returns
    -------
    SnowparkPandasDataFrame

    Raises
    ------
    NotImplementedError if a parameter is not supported.

    Notes
    -----
    Both local files and files staged on Snowflake can be passed into
    ``path_or_buf``. A single file or a folder that matches
    a set of files can be passed into ``path_or_buf``. There is no deterministic order
    in which the files are read.

    Examples
    --------

    Read local json file.

    >>> import tempfile
    >>> import json
    >>> temp_dir = tempfile.TemporaryDirectory()
    >>> temp_dir_name = temp_dir.name

    >>> data = {'A': "snowpark!", 'B': 3, 'C': [5, 6]}
    >>> with open(f'{temp_dir_name}/snowpark_pandas.json', 'w') as f:
    ...     json.dump(data, f)

    >>> import snowflake.snowpark.modin.pandas as pd
    >>> df = pd.read_json(f'{temp_dir_name}/snowpark_pandas.json')
    >>> df
               A  B       C
    0  snowpark!  3  [5, 6]

    Read staged json file.

    >>> _ = session.sql("create or replace temp stage mytempstage").collect()
    >>> _ = session.file.put(f'{temp_dir_name}/snowpark_pandas.json', '@mytempstage/myprefix')
    >>> df2 = pd.read_json('@mytempstage/myprefix/snowpark_pandas.json')
    >>> df2
               A  B       C
    0  snowpark!  3  [5, 6]

    Read json files from a local folder.

    >>> with open(f'{temp_dir_name}/snowpark_pandas2.json', 'w') as f:
    ...     json.dump(data, f)
    >>> df3 = pd.read_json(f'{temp_dir_name}')
    >>> df3
               A  B       C
    0  snowpark!  3  [5, 6]
    1  snowpark!  3  [5, 6]

    Read json files from a staged location.

    >>> _ = session.file.put(f'{temp_dir_name}/snowpark_pandas2.json', '@mytempstage/myprefix')
    >>> df4 = pd.read_json('@mytempstage/myprefix')
    >>> df4
               A  B       C
    0  snowpark!  3  [5, 6]
    1  snowpark!  3  [5, 6]
    """

    if not isinstance(path_or_buf, str):
        raise NotImplementedError(
            "'path' must be a path to a file or folder stored locally or on a Snowflake stage."
        )

    error_not_implemented_parameter("orient", orient)
    error_not_implemented_parameter("typ", typ)
    error_not_implemented_parameter("dtype", dtype)
    error_not_implemented_parameter("convert_axes", convert_axes)
    error_not_implemented_parameter("convert_dates", convert_dates)
    error_not_implemented_parameter("keep_default_dates", keep_default_dates)
    error_not_implemented_parameter("precise_float", precise_float)
    error_not_implemented_parameter("date_unit", date_unit)
    error_not_implemented_parameter("encoding_errors", encoding_errors)
    error_not_implemented_parameter("lines", lines)
    error_not_implemented_parameter("chunksize", chunksize)
    error_not_implemented_parameter("nrows", nrows)

    fn_name = "pd.read_json"
    warn_not_supported_parameter("numpy", numpy, fn_name)
    warn_not_supported_parameter("storage_options", storage_options, fn_name)

    if compression == "infer":
        compression = "auto"

    return DataFrame(
        query_compiler=SnowflakeQueryCompiler.from_file(
            "json",
            path_or_buf,
            compression=compression,
            encoding=encoding,
        )
    )


# @_inherit_docstrings(pandas.read_gbq, apilink="pandas.read_gbq")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_gbq(
    query: str,
    project_id: str | None = None,
    index_col: str | None = None,
    col_order: list[str] | None = None,
    reauth: bool = False,
    auth_local_webserver: bool = True,
    dialect: str | None = None,
    location: str | None = None,
    configuration: dict[str, Any] | None = None,
    credentials=None,
    use_bqstorage_api: bool | None = None,
    max_results: int | None = None,
    progress_bar_type: str | None = None,
) -> DataFrame:
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())
    kwargs.update(kwargs.pop("kwargs", {}))

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_gbq(**kwargs))


# @_inherit_docstrings(pandas.read_html, apilink="pandas.read_html")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_html(
    io,
    match: str | Pattern = ".+",
    flavor: str | None = None,
    header: int | Sequence[int] | None = None,
    index_col: int | Sequence[int] | None = None,
    skiprows: int | Sequence[int] | slice | None = None,
    attrs: dict[str, str] | None = None,
    parse_dates: bool = False,
    thousands: str | None = ",",
    encoding: str | None = None,
    decimal: str = ".",
    converters: dict | None = None,
    na_values: Iterable[object] | None = None,
    keep_default_na: bool = True,
    displayed_only: bool = True,
    extract_links: Literal[None, "header", "footer", "body", "all"] = None,
) -> list[DataFrame]:  # noqa: PR01, RT01, D200
    """
    Read HTML tables into a ``DataFrame`` object.
    """
    ErrorMessage.not_implemented("")

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(
        query_compiler=FactoryDispatcher.read_html(
            io,
            match=match,
            flavor=flavor,
            header=header,
            index_col=index_col,
            skiprows=skiprows,
            attrs=attrs,
            parse_dates=parse_dates,
            thousands=thousands,
            encoding=encoding,
            decimal=decimal,
            converters=converters,
            na_values=na_values,
            keep_default_na=keep_default_na,
            displayed_only=displayed_only,
            extract_links=extract_links,
        )
    )


# @_inherit_docstrings(pandas.read_clipboard, apilink="pandas.read_clipboard")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_clipboard(sep=r"\s+", **kwargs):  # pragma: no cover  # noqa: PR01, RT01, D200
    """
    Read text from clipboard and pass to read_csv.
    """
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())
    kwargs.update(kwargs.pop("kwargs", {}))

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_clipboard(**kwargs))


# @_inherit_docstrings(pandas.read_excel, apilink="pandas.read_excel")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_excel(
    io,
    sheet_name: str | int | list[IntStrT] | None = 0,
    header: int | Sequence[int] | None = 0,
    names: list[str] | None = None,
    index_col: int | Sequence[int] | None = None,
    usecols: int
    | str
    | Sequence[int]
    | Sequence[str]
    | Callable[[str], bool]
    | None = None,
    squeeze: bool | None = None,
    dtype: DtypeArg | None = None,
    engine: Literal["xlrd", "openpyxl", "odf", "pyxlsb"] | None = None,
    converters: dict[str, Callable] | dict[int, Callable] | None = None,
    true_values: Iterable[Hashable] | None = None,
    false_values: Iterable[Hashable] | None = None,
    skiprows: Sequence[int] | int | Callable[[int], object] | None = None,
    nrows: int | None = None,
    na_values=None,
    keep_default_na: bool = True,
    na_filter: bool = True,
    verbose: bool = False,
    parse_dates: list | dict | bool = False,
    date_parser: Callable | None = None,
    thousands: str | None = None,
    decimal: str = ".",
    comment: str | None = None,
    skipfooter: int = 0,
    convert_float: bool | None = None,
    mangle_dupe_cols: bool = True,
    storage_options: StorageOptions = None,
) -> DataFrame | dict[IntStrT, DataFrame]:
    ErrorMessage.not_implemented()
    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())
    # mangle_dupe_cols has no effect starting in pandas 1.5. Exclude it from
    # kwargs so pandas doesn't spuriously warn people not to use it.
    kwargs.pop("mangle_dupe_cols", None)

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    intermediate = FactoryDispatcher.read_excel(**kwargs)
    if isinstance(intermediate, (OrderedDict, dict)):
        parsed = type(intermediate)()
        for key in intermediate.keys():
            parsed[key] = DataFrame(query_compiler=intermediate.get(key))
        return parsed
    else:
        return DataFrame(query_compiler=intermediate)


# @_inherit_docstrings(pandas.read_hdf, apilink="pandas.read_hdf")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_hdf(
    path_or_buf,
    key=None,
    mode: str = "r",
    errors: str = "strict",
    where=None,
    start: int | None = None,
    stop: int | None = None,
    columns=None,
    iterator=False,
    chunksize: int | None = None,
    **kwargs,
):  # noqa: PR01, RT01, D200
    """
    Read data from the store into DataFrame.
    """
    ErrorMessage.not_implemented()
    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())
    kwargs.update(kwargs.pop("kwargs", {}))

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_hdf(**kwargs))


# @_inherit_docstrings(pandas.read_feather, apilink="pandas.read_feather")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_feather(
    path,
    columns: Sequence[Hashable] | None = None,
    use_threads: bool = True,
    storage_options: StorageOptions = None,
):
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_feather(**kwargs))


# @_inherit_docstrings(pandas.read_stata)
@snowpark_pandas_telemetry_standalone_function_decorator
def read_stata(
    filepath_or_buffer,
    convert_dates: bool = True,
    convert_categoricals: bool = True,
    index_col: str | None = None,
    convert_missing: bool = False,
    preserve_dtypes: bool = True,
    columns: Sequence[str] | None = None,
    order_categoricals: bool = True,
    chunksize: int | None = None,
    iterator: bool = False,
    compression: CompressionOptions = "infer",
    storage_options: StorageOptions = None,
) -> DataFrame | pandas.io.stata.StataReader:
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_stata(**kwargs))


# @_inherit_docstrings(pandas.read_sas, apilink="pandas.read_sas")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_sas(
    filepath_or_buffer,
    format: str | None = None,
    index: Hashable | None = None,
    encoding: str | None = None,
    chunksize: int | None = None,
    iterator: bool = False,
    compression: CompressionOptions = "infer",
) -> DataFrame | pandas.io.sas.sasreader.ReaderBase:  # noqa: PR01, RT01, D200
    """
    Read SAS files stored as either XPORT or SAS7BDAT format files.
    """
    ErrorMessage.not_implemented("")

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(
        query_compiler=FactoryDispatcher.read_sas(
            filepath_or_buffer=filepath_or_buffer,
            format=format,
            index=index,
            encoding=encoding,
            chunksize=chunksize,
            iterator=iterator,
            compression=compression,
        )
    )


# @_inherit_docstrings(pandas.read_pickle, apilink="pandas.read_pickle")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_pickle(
    filepath_or_buffer,
    compression: CompressionOptions = "infer",
    storage_options: StorageOptions = None,
):
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_pickle(**kwargs))


# @_inherit_docstrings(pandas.read_sql, apilink="pandas.read_sql")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_sql(
    sql,
    con,
    index_col=None,
    coerce_float=True,
    params=None,
    parse_dates=None,
    columns=None,
    chunksize=None,
):  # noqa: PR01, RT01, D200
    """
    Read SQL query or database table into a DataFrame.
    """
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    if kwargs.get("chunksize") is not None:
        df_gen = pandas.read_sql(**kwargs)
        return (
            DataFrame(query_compiler=FactoryDispatcher.from_pandas(df)) for df in df_gen
        )
    return DataFrame(query_compiler=FactoryDispatcher.read_sql(**kwargs))


# @_inherit_docstrings(pandas.read_fwf, apilink="pandas.read_fwf")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_fwf(
    filepath_or_buffer: str | pathlib.Path | IO[AnyStr],
    colspecs="infer",
    widths=None,
    infer_nrows=100,
    **kwds,
):  # noqa: PR01, RT01, D200
    """
    Read a table of fixed-width formatted lines into DataFrame.
    """
    ErrorMessage.not_implemented("")

    from pandas.io.parsers.base_parser import parser_defaults

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())
    kwargs.update(kwargs.pop("kwds", {}))
    target_kwargs = parser_defaults.copy()
    target_kwargs.update(kwargs)
    pd_obj = FactoryDispatcher.read_fwf(**target_kwargs)
    # When `read_fwf` returns a TextFileReader object for iterating through
    if isinstance(pd_obj, TextFileReader):
        reader = pd_obj.read
        pd_obj.read = lambda *args, **kwargs: DataFrame(
            query_compiler=reader(*args, **kwargs)
        )
        return pd_obj
    return DataFrame(query_compiler=pd_obj)


# @_inherit_docstrings(pandas.read_sql_table, apilink="pandas.read_sql_table")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_sql_table(
    table_name,
    con,
    schema=None,
    index_col=None,
    coerce_float=True,
    parse_dates=None,
    columns=None,
    chunksize=None,
):  # noqa: PR01, RT01, D200
    """
    Read SQL database table into a DataFrame.
    """
    ErrorMessage.not_implemented("")

    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_sql_table(**kwargs))


# @_inherit_docstrings(pandas.read_sql_query, apilink="pandas.read_sql_query")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_sql_query(
    sql,
    con,
    index_col: str | list[str] | None = None,
    coerce_float: bool = True,
    params: list[str] | dict[str, str] | None = None,
    parse_dates: list[str] | dict[str, str] | None = None,
    chunksize: int | None = None,
    dtype: DtypeArg | None = None,
) -> DataFrame | Iterator[DataFrame]:
    _, _, _, kwargs = inspect.getargvalues(inspect.currentframe())
    ErrorMessage.not_implemented()
    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(query_compiler=FactoryDispatcher.read_sql_query(**kwargs))


# @_inherit_docstrings(pandas.to_pickle)
@snowpark_pandas_telemetry_standalone_function_decorator
def to_pickle(
    obj: Any,
    filepath_or_buffer,
    compression: CompressionOptions = "infer",
    protocol: int = pickle.HIGHEST_PROTOCOL,
    storage_options: StorageOptions = None,
) -> None:
    ErrorMessage.not_implemented("")

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    if isinstance(obj, DataFrame):
        obj = obj._query_compiler
    return FactoryDispatcher.to_pickle(
        obj,
        filepath_or_buffer=filepath_or_buffer,
        compression=compression,
        protocol=protocol,
        storage_options=storage_options,
    )


# @_inherit_docstrings(pandas.read_spss, apilink="pandas.read_spss")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_spss(
    path: str | pathlib.Path,
    usecols: Sequence[str] | type(None) = None,
    convert_categoricals: bool = True,
):  # noqa: PR01, RT01, D200
    """
    Load an SPSS file from the file path, returning a DataFrame.
    """
    ErrorMessage.not_implemented("")

    from snowflake.snowpark.modin.pandas.frontend.dispatching.factories.dispatcher import (
        FactoryDispatcher,
    )

    return DataFrame(
        query_compiler=FactoryDispatcher.read_spss(path, usecols, convert_categoricals)
    )


# @_inherit_docstrings(pandas.json_normalize, apilink="pandas.json_normalize")
@snowpark_pandas_telemetry_standalone_function_decorator
def json_normalize(
    data: dict | list[dict],
    record_path: str | list | None = None,
    meta: str | list[str | list[str]] | None = None,
    meta_prefix: str | None = None,
    record_prefix: str | None = None,
    errors: str | None = "raise",
    sep: str = ".",
    max_level: int | None = None,
) -> DataFrame:  # noqa: PR01, RT01, D200
    """
    Normalize semi-structured JSON data into a flat table.
    """
    ErrorMessage.not_implemented()
    return DataFrame(
        pandas.json_normalize(
            data, record_path, meta, meta_prefix, record_prefix, errors, sep, max_level
        )
    )


# @_inherit_docstrings(pandas.read_orc, apilink="pandas.read_orc")
@snowpark_pandas_telemetry_standalone_function_decorator
def read_orc(
    path, columns: list[str] | None = None, **kwargs
) -> DataFrame:  # noqa: PR01, RT01, D200
    """
    Load an ORC object from the file path, returning a DataFrame.
    """
    ErrorMessage.not_implemented("")

    return DataFrame(pandas.read_orc(path, columns, **kwargs))


# @_inherit_docstrings(pandas.HDFStore)
class HDFStore(pandas.HDFStore):  # noqa: PR01, D200
    """
    Dict-like IO interface for storing pandas objects in PyTables.
    """

    _return_modin_dataframe = True

    def __getattribute__(self, item):
        default_behaviors = ["__init__", "__class__"]
        method = super().__getattribute__(item)
        if item not in default_behaviors:
            if callable(method):

                def return_handler(*args, **kwargs):
                    """
                    Replace the default behavior of methods with inplace kwarg.

                    Returns
                    -------
                    A Modin DataFrame in place of a pandas DataFrame, or the same
                    return type as pandas.HDFStore.

                    Notes
                    -----
                    This function will replace all of the arguments passed to
                    methods of HDFStore with the pandas equivalent. It will convert
                    Modin DataFrame to pandas DataFrame, etc. Currently, pytables
                    does not accept Modin DataFrame objects, so we must convert to
                    pandas.
                    """
                    from snowflake.snowpark.modin.pandas.utils import to_pandas

                    args = [
                        to_pandas(arg) if isinstance(arg, DataFrame) else arg
                        for arg in args
                    ]
                    kwargs = {
                        k: to_pandas(v) if isinstance(v, DataFrame) else v
                        for k, v in kwargs.items()
                    }
                    obj = super(HDFStore, self).__getattribute__(item)(*args, **kwargs)
                    if self._return_modin_dataframe and isinstance(
                        obj, pandas.DataFrame
                    ):
                        return DataFrame(obj)
                    return obj

                # We replace the method with `return_handler` for inplace operations
                method = return_handler
        return method


# @_inherit_docstrings(pandas.ExcelFile)
class ExcelFile(pandas.ExcelFile):  # noqa: PR01, D200
    """
    Class for parsing tabular excel sheets into DataFrame objects.
    """

    def __getattribute__(self, item):
        default_behaviors = ["__init__", "__class__"]
        method = super().__getattribute__(item)
        if item not in default_behaviors:
            if callable(method):

                def return_handler(*args, **kwargs):
                    """
                    Replace the default behavior of methods with inplace kwarg.

                    Returns
                    -------
                    A Modin DataFrame in place of a pandas DataFrame, or the same
                    return type as pandas.ExcelFile.

                    Notes
                    -----
                    This function will replace all of the arguments passed to
                    methods of ExcelFile with the pandas equivalent. It will convert
                    Modin DataFrame to pandas DataFrame, etc.
                    """
                    from snowflake.snowpark.modin.pandas.utils import to_pandas

                    args = [
                        to_pandas(arg) if isinstance(arg, DataFrame) else arg
                        for arg in args
                    ]
                    kwargs = {
                        k: to_pandas(v) if isinstance(v, DataFrame) else v
                        for k, v in kwargs.items()
                    }
                    obj = super(ExcelFile, self).__getattribute__(item)(*args, **kwargs)
                    if isinstance(obj, pandas.DataFrame):
                        return DataFrame(obj)
                    return obj

                # We replace the method with `return_handler` for inplace operations
                method = return_handler
        return method


__all__ = [
    "ExcelFile",
    "HDFStore",
    "json_normalize",
    "read_clipboard",
    "read_csv",
    "read_excel",
    "read_feather",
    "read_fwf",
    "read_gbq",
    "read_hdf",
    "read_html",
    "read_json",
    "read_orc",
    "read_parquet",
    "read_pickle",
    "read_sas",
    "read_spss",
    "read_sql",
    "read_sql_query",
    "read_sql_table",
    "read_stata",
    "read_table",
    "read_xml",
    "to_pickle",
    "read_snowflake",
]
